/**
 * @file src/telegram/bot.js
 * Docs: README.md §"Telegram Bot Interface" + "Command Reference" · docs/DEPLOYMENT_ORACLE.md Step 7
 *
 * Re-implements the original telegram_ui/telegram_bot.js command set using the Telegram Bot API
 * directly over fetch() (long polling) — no npm packages.
 *
 * Commands (original):  /start /status /positions /balance /start_trading /stop_trading /performance /settings /help
 * Added for safety:     /resume /close_all /set <key> <value> /strategy <name> on|off  and confirmation buttons.
 *
 * SECURITY MODEL (tree of thought)
 *   ✗ "anyone who finds the bot can control it"      → the original README never mentions an allowlist.
 *   ✓ ALLOWLIST: only numeric Telegram user IDs listed in TELEGRAM_CHAT_ID are served; everyone else is
 *     ignored silently (and logged). Private chats only — group chats are ignored.
 *   ✓ SETUP MODE: if TELEGRAM_CHAT_ID is empty, the bot answers ONLY "/id" (your numeric ID) so you can
 *     fill the allowlist; it executes nothing.
 *   ✓ REPLAY GUARD: update offset is persisted and messages older than 120 s are ignored, so a restart can
 *     never replay an old "/start_trading".
 *   ✓ CONFIRMATIONS: starting live-money trading and closing all positions need a button press within 60 s.
 */
import crypto from 'node:crypto';
import path from 'node:path';
import { sleep } from '../util/ratelimit.js';
import { readJson, writeJsonAtomic } from '../util/atomic.js';
import { SETTINGS_SCHEMA, STRATEGY_NAMES } from '../config.js';
import { fmtUsd } from '../util/money.js';

export const esc = (s) => String(s ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

const MENU = {
  inline_keyboard: [
    [{ text: '📊 Status', callback_data: 'cmd:status' }, { text: '💰 Balance', callback_data: 'cmd:balance' }],
    [{ text: '📈 Positions', callback_data: 'cmd:positions' }, { text: '📉 Performance', callback_data: 'cmd:performance' }],
    [{ text: '▶️ Start Trading', callback_data: 'cmd:start_trading' }, { text: '⏹️ Stop Trading', callback_data: 'cmd:stop_trading' }],
    [{ text: '⚙️ Settings', callback_data: 'cmd:settings' }, { text: '❓ Help', callback_data: 'cmd:help' }],
  ],
};

export const COMMANDS = [
  ['start', 'Show the main menu'],
  ['status', 'Bot status and health'],
  ['balance', 'Cash, equity and P&L'],
  ['positions', 'Open positions'],
  ['performance', 'Performance metrics'],
  ['start_trading', 'Begin automated trading'],
  ['stop_trading', 'Stop all trading activity'],
  ['resume', 'Clear a risk halt'],
  ['close_all', 'Close every open position'],
  ['settings', 'View settings'],
  ['help', 'Help'],
];

const f2 = (n) => (n === null || n === undefined ? 'n/a' : Number(n).toFixed(2));

export function formatEvent(type, e) {
  switch (type) {
    case 'trade_executed':
      if (e.type === 'entry') return `🟢 <b>ENTRY</b> ${esc(e.strategy)}\n${esc(e.side?.toUpperCase())} <code>${esc(e.ticker)}</code> ×${e.quantity} @ ${f2(e.price)}\n${esc(e.event ?? '')}\n<i>${esc(e.reason ?? '')}</i>`;
      if (e.type === 'exit') return `🔴 <b>EXIT</b> (${esc(e.reason)})\n${esc(e.side?.toUpperCase())} <code>${esc(e.ticker)}</code> ×${e.quantity} @ ${f2(e.price)}\nP&amp;L ${fmtUsd(e.pnl ?? 0)}`;
      if (e.type === 'settled') return `🏁 <b>SETTLED</b> <code>${esc(e.ticker)}</code> → ${esc(e.result)}\nP&amp;L ${fmtUsd(e.pnl ?? 0)}`;
      if (e.type === 'basket') return `🧺 <b>BASKET</b> ${esc(e.id)} ×${e.sets} sets\n${e.legs.map((l) => `• ${esc(l)}`).join('\n')}\n<i>${esc(e.reason)}</i>`;
      return `ℹ️ trade ${esc(JSON.stringify(e))}`;
    case 'risk_event':
      return `🚨 <b>RISK EVENT</b> (${esc(e.kind)})\n${esc(e.reason)}`;
    case 'opportunity':
      return `💡 <b>Opportunity (not auto-executed)</b>\n${esc(e.reason)}\nNet edge/set ≈ ${f2(e.edge)}\n${e.legs.map((l) => `• ${esc(l.side.toUpperCase())} <code>${esc(l.ticker)}</code> @ ${f2(l.price)}`).join('\n')}`;
    case 'bot_error':
      return `⚠️ <b>Error</b>: ${esc(e.message)}`;
    default:
      return esc(`${type}: ${JSON.stringify(e)}`);
  }
}

export class TelegramBot {
  constructor({ token, allowedIds = [], trader, settings, cfg, logger, fetchImpl = globalThis.fetch, now = () => Date.now(), pollSeconds = 25, minIntervalMs = 1100 }) {
    this.token = token;
    this.minIntervalMs = minIntervalMs; // Telegram allows ~1 msg/s per chat; tests pass 0
    this.allowed = new Set(allowedIds.map(String));
    Object.assign(this, { trader, settings, cfg, logger, now, pollSeconds });
    this.fetch = fetchImpl;
    this.running = false;
    this.offset = 0;
    this.offsetFile = path.join(cfg.dataDir, 'telegram_offset.json');
    this.pending = new Map(); // nonce → {action, exp}
    this.queue = [];
    this.lastSent = 0;
  }

  async #api(method, params = {}, timeoutMs = 15000) {
    const res = await this.fetch(`${this.cfg.telegram?.apiBase ?? 'https://api.telegram.org'}/bot${this.token}/${method}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(params),
      signal: AbortSignal.timeout(timeoutMs),
    });
    const j = await res.json().catch(() => null);
    if (!res.ok || !j?.ok) throw new Error(`telegram ${method} failed: ${j?.description ?? res.status}`);
    return j.result;
  }

  async start() {
    const me = await this.#api('getMe');
    this.logger.info(`telegram connected as @${me.username}${this.allowed.size ? '' : ' (SETUP MODE: send /id to the bot, then set TELEGRAM_CHAT_ID)'}`);
    await this.#api('deleteWebhook', { drop_pending_updates: false }); // long polling and webhooks are mutually exclusive
    if (this.allowed.size) await this.#api('setMyCommands', { commands: COMMANDS.map(([command, description]) => ({ command, description })) }).catch(() => {});
    this.offset = (await readJson(this.offsetFile, { offset: 0 }))?.offset ?? 0;
    this.running = true;
    this.#loop();
    this.#drain();
  }

  stop() {
    this.running = false;
  }

  /** Queue an HTML message for every allowlisted chat. */
  notify(html) {
    if (!this.allowed.size) return;
    if (this.queue.length > 30) this.queue.splice(0, this.queue.length - 20, '…older notifications dropped…');
    this.queue.push(html);
  }

  async #drain() {
    while (this.running) {
      const msg = this.queue.shift();
      if (!msg) {
        await sleep(500);
        continue;
      }
      for (const id of this.allowed) await this.#send(id, msg).catch((e) => this.logger.warn(`telegram notify failed: ${e.message}`));
    }
  }

  async #send(chatId, html, keyboard) {
    const wait = this.minIntervalMs - (this.now() - this.lastSent);
    if (wait > 0) await sleep(wait);
    this.lastSent = this.now();
    const chunks = [];
    let rest = html;
    while (rest.length > 3900) {
      let cut = rest.lastIndexOf('\n', 3900);
      if (cut < 1000) cut = 3900;
      chunks.push(rest.slice(0, cut));
      rest = rest.slice(cut);
    }
    chunks.push(rest);
    for (let i = 0; i < chunks.length; i++) {
      await this.#api('sendMessage', { chat_id: chatId, text: chunks[i], parse_mode: 'HTML', disable_web_page_preview: true, ...(i === chunks.length - 1 && keyboard ? { reply_markup: keyboard } : {}) });
    }
  }

  async #loop() {
    let backoff = 1000;
    while (this.running) {
      try {
        const updates = await this.#api('getUpdates', { offset: this.offset, timeout: this.pollSeconds, allowed_updates: ['message', 'callback_query'] }, (this.pollSeconds + 10) * 1000);
        backoff = 1000;
        for (const u of updates) {
          this.offset = u.update_id + 1;
          await writeJsonAtomic(this.offsetFile, { offset: this.offset }).catch(() => {});
          await this.handleUpdate(u).catch((e) => this.logger.warn(`telegram handler error: ${e.message}`));
        }
      } catch (e) {
        if (!this.running) break;
        this.logger.warn(`telegram poll error: ${e.message}`);
        await sleep(backoff);
        backoff = Math.min(backoff * 2, 30000);
      }
    }
  }

  /** Public for tests. */
  async handleUpdate(u) {
    const cb = u.callback_query;
    const msg = u.message;
    const from = (cb ?? msg)?.from;
    const chat = cb ? cb.message?.chat : msg?.chat;
    if (!from || !chat || chat.type !== 'private') return;
    const id = String(from.id);

    if (this.allowed.size === 0) {
      if (msg?.text && /^\/(id|start)\b/.test(msg.text)) await this.#send(chat.id, `Your numeric Telegram ID is <code>${esc(id)}</code>.\nSet <code>TELEGRAM_CHAT_ID=${esc(id)}</code> in the bot's environment file and restart the service. Until then this bot executes nothing.`);
      return;
    }
    if (!this.allowed.has(id)) {
      this.logger.warn(`ignored telegram message from unauthorised user ${id}`);
      return;
    }
    if (msg?.date && this.now() / 1000 - msg.date > 120) return; // replay guard

    if (cb) {
      await this.#api('answerCallbackQuery', { callback_query_id: cb.id }).catch(() => {});
      return this.#dispatch(chat.id, cb.data ?? '', id);
    }
    if (msg?.text) return this.#dispatch(chat.id, msg.text.trim(), id);
  }

  async #dispatch(chatId, raw, userId) {
    let cmd;
    let args = [];
    if (raw.startsWith('cmd:')) cmd = raw.slice(4);
    else if (raw.startsWith('confirm:')) {
      const [, nonce] = raw.split(':');
      const p = this.pending.get(nonce);
      this.pending.delete(nonce);
      if (!p || p.exp < this.now()) return this.#send(chatId, '⌛ Confirmation expired. Send the command again.', MENU);
      return this.#send(chatId, await this.#confirmed(p.action, userId), MENU);
    } else if (raw === 'cancel') return this.#send(chatId, 'Cancelled.', MENU);
    else if (raw.startsWith('/')) {
      const parts = raw.split(/\s+/);
      cmd = parts[0].slice(1).replace(/@.*$/, '').toLowerCase();
      args = parts.slice(1);
    } else return;

    const t = this.trader;
    switch (cmd) {
      case 'start':
        return this.#send(chatId, '👋 <b>Kalshi Quant Bot</b>\nPick an action:', MENU);
      case 'help':
        return this.#send(chatId, ['<b>Commands</b>', ...COMMANDS.map(([c, d]) => `/${c} — ${esc(d)}`), '/set &lt;key&gt; &lt;value&gt; — change a setting', '/strategy &lt;name&gt; on|off — toggle a strategy', '', `Strategies: ${STRATEGY_NAMES.join(', ')}`].join('\n'), MENU);
      case 'status':
        return this.#send(chatId, this.#statusText(), MENU);
      case 'balance':
        return this.#send(chatId, this.#balanceText(), MENU);
      case 'positions':
        return this.#send(chatId, this.#positionsText(), MENU);
      case 'performance':
        return this.#send(chatId, this.#performanceText(), MENU);
      case 'settings':
        return this.#send(chatId, this.#settingsText(), MENU);
      case 'start_trading':
        if (t.halted) return this.#send(chatId, `⛔ Trading is halted: ${esc(t.haltText)}\nUse /resume after reviewing.`, MENU);
        if (this.cfg.live && this.cfg.kalshiEnv === 'prod') return this.#askConfirm(chatId, 'start', '⚠️ <b>REAL-MONEY</b> trading on Kalshi production. Start?');
        t.setTrading(true, `telegram:${userId}`);
        return this.#send(chatId, `▶️ Trading started (${esc(this.cfg.mode)}/${esc(this.cfg.kalshiEnv)}).`, MENU);
      case 'stop_trading':
        t.setTrading(false, `telegram:${userId}`);
        return this.#send(chatId, '⏹️ Trading stopped. Open positions are left untouched (use /close_all to flatten).', MENU);
      case 'resume':
        t.resume(`telegram:${userId}`);
        return this.#send(chatId, '✅ Risk halt cleared. Trading remains as it was (use /start_trading if stopped).', MENU);
      case 'close_all':
        return this.#askConfirm(chatId, 'close_all', `Close <b>${t.ledger.positionList().length}</b> open position(s) at market?`);
      case 'set': {
        if (args.length !== 2) return this.#send(chatId, 'Usage: <code>/set &lt;key&gt; &lt;value&gt;</code> — see /settings for keys.', MENU);
        const { applied, errors } = await this.settings.patch({ [args[0]]: args[1] });
        if (Object.keys(applied).length) t.emit('config_updated', applied);
        return this.#send(chatId, errors.length ? `❌ ${esc(errors.join('; '))}` : `✅ ${esc(args[0])} = ${esc(applied[args[0]])}`, MENU);
      }
      case 'strategy': {
        const [name, onoff] = args;
        if (!STRATEGY_NAMES.includes(name) || !['on', 'off'].includes(onoff)) return this.#send(chatId, `Usage: <code>/strategy &lt;${STRATEGY_NAMES.join('|')}&gt; on|off</code>`, MENU);
        await this.settings.setStrategy(name, onoff === 'on');
        return this.#send(chatId, `✅ ${esc(name)} ${onoff}. Active: ${esc(this.settings.enabledStrategies().join(', ') || 'none')}`, MENU);
      }
      default:
        return this.#send(chatId, 'Unknown command. Try /help.', MENU);
    }
  }

  #askConfirm(chatId, action, text) {
    const nonce = crypto.randomBytes(6).toString('hex');
    this.pending.set(nonce, { action, exp: this.now() + 60000 });
    return this.#send(chatId, `${text}\n<i>Confirm within 60 s.</i>`, { inline_keyboard: [[{ text: '✅ Confirm', callback_data: `confirm:${nonce}` }, { text: '✖ Cancel', callback_data: 'cancel' }]] });
  }

  async #confirmed(action, userId) {
    if (action === 'start') {
      this.trader.setTrading(true, `telegram:${userId}`);
      return '▶️ LIVE trading started.';
    }
    if (action === 'close_all') {
      const n = await this.trader.closeAll(`telegram:${userId}`);
      return `Closed ${n} position(s).`;
    }
    return 'Nothing to do.';
  }

  /* ── renderers ───────────────────────────────────────────────── */
  #statusText() {
    const s = this.trader.status();
    const ago = s.lastUpdate ? `${Math.round((this.now() - Date.parse(s.lastUpdate)) / 1000)}s ago` : 'no cycle yet';
    return [
      '<b>Bot status</b>',
      `Mode: <code>${esc(s.mode)}</code> / <code>${esc(s.kalshiEnv)}</code>`,
      `Trading: ${s.trading ? '✅ ON' : '⏹ OFF'}${s.halted ? ` · 🚨 HALTED (${esc(s.haltReason)})` : ''}`,
      `Kalshi API: ${s.apiConnected ? '🟢 connected' : '🔴 not connected'}`,
      `Strategies: ${esc(s.activeStrategies.join(', ') || 'none')}`,
      `Open positions: ${s.openPositions} · Trades: ${s.tradesCount}`,
      `Uptime ${esc(s.uptime)} · last cycle ${esc(ago)}${s.cycle.error ? ` · ⚠️ ${esc(s.cycle.error)}` : ''}`,
    ].join('\n');
  }

  #balanceText() {
    const b = this.trader.balanceView();
    return ['<b>Balance</b>', `Available: ${fmtUsd(b.available)}`, `Equity: ${fmtUsd(b.totalEquity)}`, `Unrealized: ${fmtUsd(b.unrealizedPnL)}`, `Today: ${fmtUsd(b.todayPnL)}`, `<i>${esc(b.mode)} ledger</i>`].join('\n');
  }

  #positionsText() {
    const ps = this.trader.positionsView();
    if (!ps.length) return '📭 No open positions.';
    return ['<b>Open positions</b>', ...ps.slice(0, 15).map((p) => `• ${esc(p.side.toUpperCase())} <code>${esc(p.ticker)}</code> ×${p.quantity} @ ${f2(p.entryPrice)} → ${f2(p.currentPrice)} (${fmtUsd(p.pnl)})`), ps.length > 15 ? `…and ${ps.length - 15} more` : ''].filter(Boolean).join('\n');
  }

  #performanceText() {
    const p = this.trader.performanceView();
    return ['<b>Performance</b>', `Return: ${f2(p.totalReturn)}%`, `Sharpe: ${p.sharpeRatio === null ? 'n/a (needs ≥5 days)' : f2(p.sharpeRatio)}`, `Max drawdown: ${f2(p.maxDrawdown)}%`, `Win rate: ${f2(p.winRate)}% over ${p.totalTrades} closed trades`, `Avg ${fmtUsd(p.avgTrade)} · best ${fmtUsd(p.bestTrade)} · worst ${fmtUsd(p.worstTrade)}`].join('\n');
  }

  #settingsText() {
    const v = this.settings.get();
    return ['<b>Settings</b> (change with /set &lt;key&gt; &lt;value&gt;)', ...Object.entries(SETTINGS_SCHEMA).map(([k, spec]) => `<code>${k}</code> = ${esc(v[k])} <i>(${esc(spec.min)}–${esc(spec.max)})</i>`), `Strategies on: ${esc(this.settings.enabledStrategies().join(', ') || 'none')}`].join('\n');
  }
}

/* ── Developer support (kept out of docs on purpose) ─────────────────────────
 * Andrew Ivan Bell · CashApp: $tomesingsoc · Coinbase: aibell@live.com
 * ─────────────────────────────────────────────────────────────────────────── */
