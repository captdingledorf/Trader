/**
 * @file src/util/http.js
 * Docs: README.md §"Data Ingestion" · docs/AUDIT.md F-20 (hostile/oversized responses)
 *
 * WHY: `await res.text()` buffers WHATEVER the server sends. On a 1 GB VM a compromised feed, a proxy
 * error page or a runaway API response could exhaust memory. We read the body as a stream and stop at a cap.
 */

/**
 * Read a fetch Response body as text, at most `maxBytes` bytes.
 * @returns {Promise<{text: string, truncated: boolean}>}
 */
export async function readTextCapped(res, maxBytes) {
  if (!res.body?.getReader) {
    // test doubles / very old runtimes: fall back to text() and cap by length
    const t = await res.text();
    return t.length > maxBytes ? { text: t.slice(0, maxBytes), truncated: true } : { text: t, truncated: false };
  }
  const reader = res.body.getReader();
  const dec = new TextDecoder('utf-8', { fatal: false });
  let size = 0;
  let out = '';
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    size += value.byteLength;
    if (size > maxBytes) {
      const keep = value.byteLength - (size - maxBytes);
      out += dec.decode(value.subarray(0, Math.max(0, keep)));
      await reader.cancel().catch(() => {});
      return { text: out, truncated: true };
    }
    out += dec.decode(value, { stream: true });
  }
  out += dec.decode();
  return { text: out, truncated: false };
}
