/**
 * @file src/util/wsHub.js
 * Docs: README.md §"API Documentation → WebSocket API" · docs/AUDIT.md F-04
 *
 * The original Node interface server exposed `ws://localhost:3001` with message types
 * status | trade_executed | bot_output | bot_error | config_updated and a {type:"subscribe"} handshake.
 * We keep that contract but implement the protocol ourselves (≈120 lines) so the whole bot stays
 * dependency-free.
 *
 * Scope limits (deliberate, documented in AUDIT):
 *   - text frames only, single-frame messages (FIN=1) up to maxPayload bytes
 *   - client frames MUST be masked (RFC 6455 §5.1) else connection closed with 1002
 *   - authentication is done BEFORE the 101 upgrade by the caller-supplied `authenticate(req)`
 *   - slow consumers (>1 MiB queued) are dropped
 */
import crypto from 'node:crypto';

const GUID = '258EAFA5-E914-47DA-95CA-C5AB0DC85B11';

function frame(opcode, payload) {
  const len = payload.length;
  let header;
  if (len < 126) header = Buffer.from([0x80 | opcode, len]);
  else if (len < 65536) {
    header = Buffer.alloc(4);
    header[0] = 0x80 | opcode;
    header[1] = 126;
    header.writeUInt16BE(len, 2);
  } else {
    header = Buffer.alloc(10);
    header[0] = 0x80 | opcode;
    header[1] = 127;
    header.writeBigUInt64BE(BigInt(len), 2);
  }
  return Buffer.concat([header, payload]);
}

export class WsHub {
  constructor({ authenticate, maxClients = 10, maxPayload = 65536, pingMs = 30000, logger = null, onMessage = null } = {}) {
    this.authenticate = authenticate ?? (() => false);
    this.maxClients = maxClients;
    this.maxPayload = maxPayload;
    this.logger = logger;
    this.onMessage = onMessage;
    this.clients = new Set();
    this.timer = setInterval(() => this.#heartbeat(), pingMs);
    this.timer.unref?.();
  }

  #reject(socket, code, text) {
    socket.write(`HTTP/1.1 ${code} ${text}\r\nConnection: close\r\nContent-Length: 0\r\n\r\n`);
    socket.destroy();
  }

  handleUpgrade(req, socket) {
    const key = req.headers['sec-websocket-key'];
    if (String(req.headers.upgrade ?? '').toLowerCase() !== 'websocket' || !key || req.headers['sec-websocket-version'] !== '13') {
      return this.#reject(socket, 400, 'Bad Request');
    }
    if (!this.authenticate(req)) return this.#reject(socket, 401, 'Unauthorized');
    if (this.clients.size >= this.maxClients) return this.#reject(socket, 503, 'Service Unavailable');

    const accept = crypto.createHash('sha1').update(key + GUID).digest('base64');
    socket.write(
      'HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\n' +
        `Sec-WebSocket-Accept: ${accept}\r\n\r\n`,
    );
    socket.setNoDelay(true);
    const client = { socket, subscribed: false, buf: Buffer.alloc(0), alive: true };
    this.clients.add(client);
    socket.on('data', (chunk) => {
      client.buf = Buffer.concat([client.buf, chunk]);
      this.#parse(client);
    });
    const drop = () => {
      this.clients.delete(client);
      socket.destroy();
    };
    socket.on('close', drop);
    socket.on('error', drop);
    socket.on('end', drop); // http.Server sockets are half-open: without this a vanished client lingers until the heartbeat
  }

  #close(client, code) {
    const p = Buffer.alloc(2);
    p.writeUInt16BE(code, 0);
    try {
      client.socket.write(frame(0x8, p));
    } catch {
      /* socket already gone */
    }
    client.socket.end();
    this.clients.delete(client);
  }

  #parse(client) {
    for (;;) {
      const b = client.buf;
      if (b.length < 2) return;
      const fin = (b[0] & 0x80) !== 0;
      const op = b[0] & 0x0f;
      const masked = (b[1] & 0x80) !== 0;
      let len = b[1] & 0x7f;
      let off = 2;
      if (len === 126) {
        if (b.length < 4) return;
        len = b.readUInt16BE(2);
        off = 4;
      } else if (len === 127) {
        if (b.length < 10) return;
        if (b.readUInt32BE(2) !== 0) return this.#close(client, 1009);
        len = b.readUInt32BE(6);
        off = 10;
      }
      if (len > this.maxPayload) return this.#close(client, 1009);
      if (!masked) return this.#close(client, 1002);
      if (b.length < off + 4 + len) return;
      const mask = b.subarray(off, off + 4);
      const payload = Buffer.from(b.subarray(off + 4, off + 4 + len));
      for (let i = 0; i < payload.length; i++) payload[i] ^= mask[i % 4];
      client.buf = b.subarray(off + 4 + len);

      if (op === 0x8) return this.#close(client, 1000);
      if (op === 0x9) client.socket.write(frame(0xa, payload));
      else if (op === 0xa) client.alive = true;
      else if (op === 0x1 && fin) this.#message(client, payload.toString('utf8'));
      else return this.#close(client, 1003); // binary / fragmented: unsupported
    }
  }

  #message(client, text) {
    let msg;
    try {
      msg = JSON.parse(text);
    } catch {
      return;
    }
    if (msg?.type === 'subscribe') {
      client.subscribed = true;
      this.#send(client, { type: 'subscribed', timestamp: new Date().toISOString() });
    }
    this.onMessage?.(msg, (obj) => this.#send(client, obj));
  }

  #send(client, obj) {
    if (client.socket.writableLength > 1024 * 1024) return this.#close(client, 1008);
    client.socket.write(frame(0x1, Buffer.from(JSON.stringify(obj))));
  }

  /** Send to every subscribed client. */
  broadcast(obj) {
    for (const c of this.clients) if (c.subscribed) this.#send(c, obj);
  }

  #heartbeat() {
    for (const c of this.clients) {
      if (!c.alive) {
        c.socket.destroy();
        this.clients.delete(c);
        continue;
      }
      c.alive = false;
      c.socket.write(frame(0x9, Buffer.alloc(0)));
    }
  }

  close() {
    clearInterval(this.timer);
    for (const c of [...this.clients]) this.#close(c, 1001);
  }
}
