/**
 * @file src/util/money.js
 * Docs: README.md §"Kalshi API compatibility" · docs/PORT_MAP.md §"Money & units"
 *
 * WHY THIS FILE EXISTS (chain of thought)
 *  1. Kalshi migrated from integer cents (`yes_bid: 12`) to fixed-point dollar strings
 *     (`yes_bid_dollars: "0.1200"`) and from integer counts to `*_fp` strings.
 *     Their migration page lists Jan 29 2026 (new fields accepted/returned) and
 *     Mar 12 2026 (legacy integer fields removed/deprecated).
 *  2. Therefore every reader in this project must PREFER `*_dollars` / `*_fp`
 *     and only FALL BACK to the legacy integer fields.
 *  3. All strategy math uses plain JS numbers in DOLLARS (0 < p < 1). Order payloads
 *     convert back to fixed-point strings at the very edge (src/engine/broker.js).
 *
 * Alternatives considered (tree of thought)
 *   A) decimal.js / big.js  -> rejected: adds a dependency; cents-granularity math fits in IEEE-754.
 *   B) integer micro-dollars -> rejected: complicates every strategy formula for no real gain.
 *   C) plain numbers + rounding at edges -> CHOSEN.
 */

/** Parse anything number-ish; returns null for ''/null/undefined/NaN. */
export function num(v) {
  if (v === null || v === undefined || v === '') return null;
  const n = typeof v === 'number' ? v : Number(v);
  return Number.isFinite(n) ? n : null;
}

/** Read `${base}_dollars` (preferred) or legacy `${base}` (cents) and return DOLLARS. */
export function dollars(obj, base) {
  if (!obj) return null;
  const d = num(obj[`${base}_dollars`]);
  if (d !== null) return d;
  const c = num(obj[base]);
  return c === null ? null : c / 100;
}

/** Read `${base}_fp` (preferred) or legacy integer `${base}`; returns a number of contracts. */
export function fp(obj, base) {
  if (!obj) return null;
  const f = num(obj[`${base}_fp`]);
  if (f !== null) return f;
  return num(obj[base]);
}

export const clamp = (x, lo, hi) => Math.min(hi, Math.max(lo, x));
export const round = (x, d = 4) => {
  const f = 10 ** d;
  return Math.round(x * f) / f;
};

/** Fixed-point strings for request bodies (Kalshi accepts up to 4 dp for dollars, 0-2 dp for counts). */
export const toDollarString = (p) => Number(p).toFixed(4);
export const toCountString = (n) => Number(n).toFixed(2);

/** Round a probability/price to whole cents (the safe tick on every market's mid-range). */
export const toCents = (p) => Math.round(p * 100) / 100;

export const fmtUsd = (n) => `${n < 0 ? '-' : ''}$${Math.abs(n).toFixed(2)}`;

/**
 * Estimated Kalshi TAKER fee in dollars for `count` contracts at `price`.
 * Formula used by Kalshi's published fee schedule: ceil_to_cent(coeff * C * P * (1-P)), coeff = 0.07
 * for most markets. COEFFICIENT IS CONFIGURABLE (FEE_COEFFICIENT) because Kalshi changes schedules;
 * verify against the current fee schedule before trusting any edge calculation. [AUDIT F-07]
 */
export function takerFee(count, price, coeff = 0.07) {
  if (!(count > 0)) return 0;
  const raw = coeff * count * price * (1 - price);
  return Math.ceil(raw * 100 - 1e-9) / 100;
}

/** Per-contract fee at an assumed order size (rounding up to a cent amortises over larger orders). */
export const feePerContract = (price, count = 10, coeff = 0.07) => takerFee(count, price, coeff) / Math.max(1, count);

/* ── Developer support (kept out of docs on purpose) ─────────────────────────
 * Andrew Ivan Bell · CashApp: $tomesingsoc · Coinbase: aibell@live.com
 * ─────────────────────────────────────────────────────────────────────────── */
