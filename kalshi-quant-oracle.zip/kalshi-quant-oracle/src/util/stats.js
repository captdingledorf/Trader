/**
 * @file src/util/stats.js
 * Docs: README.md §"Trading Strategies" (Statistical Arbitrage, Volatility) · docs/THESIS.md ch.4
 *
 * The original project listed cointegration (statsmodels-style) and GARCH (arch-style) analytics
 * backed by Python's scientific stack. Node has no equivalent in its standard library and the
 * Oracle Always Free micro shape has only 1 GB RAM, so we implement the small subset we need
 * with plain arrays. Every routine is unit-tested in test/stats.test.js.
 *
 * Alternatives considered
 *   A) spawn a Python sidecar (pandas/statsmodels) -> rejected: ~400 MB RSS, breaks the 1 GB budget.
 *   B) npm numeric libraries                       -> rejected: supply-chain surface for a money-handling bot.
 *   C) ~150 lines of audited math                  -> CHOSEN.
 */

export const mean = (a) => a.reduce((s, x) => s + x, 0) / a.length;

export function variance(a, ddof = 1) {
  if (a.length <= ddof) return 0;
  const m = mean(a);
  return a.reduce((s, x) => s + (x - m) ** 2, 0) / (a.length - ddof);
}
export const std = (a, ddof = 1) => Math.sqrt(variance(a, ddof));

export const logit = (p) => Math.log(p / (1 - p));

/** Pearson correlation over the aligned tails of two series; null if <3 points or zero variance. */
export function pearson(a, b) {
  const n = Math.min(a.length, b.length);
  if (n < 3) return null;
  const x = a.slice(-n);
  const y = b.slice(-n);
  const mx = mean(x);
  const my = mean(y);
  let sxy = 0;
  let sxx = 0;
  let syy = 0;
  for (let i = 0; i < n; i++) {
    sxy += (x[i] - mx) * (y[i] - my);
    sxx += (x[i] - mx) ** 2;
    syy += (y[i] - my) ** 2;
  }
  if (sxx === 0 || syy === 0) return null;
  return sxy / Math.sqrt(sxx * syy);
}

/** Gauss-Jordan inverse for small square matrices (k <= ~6). Returns null if singular. */
function invert(M) {
  const n = M.length;
  const A = M.map((row, i) => [...row, ...Array.from({ length: n }, (_, j) => (i === j ? 1 : 0))]);
  for (let c = 0; c < n; c++) {
    let p = c;
    for (let r = c + 1; r < n; r++) if (Math.abs(A[r][c]) > Math.abs(A[p][c])) p = r;
    if (Math.abs(A[p][c]) < 1e-12) return null;
    [A[c], A[p]] = [A[p], A[c]];
    const d = A[c][c];
    for (let j = 0; j < 2 * n; j++) A[c][j] /= d;
    for (let r = 0; r < n; r++) {
      if (r === c) continue;
      const f = A[r][c];
      if (f !== 0) for (let j = 0; j < 2 * n; j++) A[r][j] -= f * A[c][j];
    }
  }
  return A.map((row) => row.slice(n));
}

/** Ordinary least squares. X: rows of regressors (include a 1 column yourself). */
export function ols(X, y) {
  const n = X.length;
  const k = X[0].length;
  const XtX = Array.from({ length: k }, () => new Array(k).fill(0));
  const Xty = new Array(k).fill(0);
  for (let i = 0; i < n; i++) {
    for (let a = 0; a < k; a++) {
      Xty[a] += X[i][a] * y[i];
      for (let b = 0; b < k; b++) XtX[a][b] += X[i][a] * X[i][b];
    }
  }
  const inv = invert(XtX);
  if (!inv || n <= k) return null;
  const beta = inv.map((row) => row.reduce((s, v, j) => s + v * Xty[j], 0));
  const resid = y.map((yi, i) => yi - X[i].reduce((s, v, j) => s + v * beta[j], 0));
  const sigma2 = resid.reduce((s, e) => s + e * e, 0) / (n - k);
  const se = inv.map((row, i) => Math.sqrt(Math.max(0, row[i] * sigma2)));
  const tstat = beta.map((b, i) => (se[i] > 0 ? b / se[i] : 0));
  return { beta, resid, se, tstat, sigma2, n, k };
}

/**
 * Augmented Dickey-Fuller regression with constant:
 *   dy_t = c + g*y_{t-1} + sum_i phi_i * dy_{t-i} + e_t   ->  returns t-stat of g.
 */
export function adf(series, lags = 1) {
  const n = series.length;
  if (n < 20 + lags) return null;
  const dy = [];
  for (let j = 1; j < n; j++) dy.push(series[j] - series[j - 1]);
  const X = [];
  const y = [];
  for (let t = lags + 1; t < n; t++) {
    const row = [1, series[t - 1]];
    for (let i = 1; i <= lags; i++) row.push(dy[t - i - 1]);
    X.push(row);
    y.push(dy[t - 1]);
  }
  const fit = ols(X, y);
  if (!fit) return null;
  return { stat: fit.tstat[1], gamma: fit.beta[1], n: fit.n, lags };
}

/** Asymptotic Engle-Granger critical values (two variables, constant) from MacKinnon. */
export const EG_CRITICAL = { 1: -3.9, 5: -3.34, 10: -3.04 };

/** Engle-Granger two-step cointegration test of y on x. */
export function engleGranger(y, x, { lags = 1 } = {}) {
  const n = Math.min(y.length, x.length);
  if (n < 30) return null;
  const yy = y.slice(-n);
  const xx = x.slice(-n);
  const fit = ols(xx.map((v) => [1, v]), yy);
  if (!fit) return null;
  const test = adf(fit.resid, lags);
  if (!test) return null;
  const sd = std(fit.resid);
  const last = fit.resid[fit.resid.length - 1];
  const g = test.gamma;
  const halfLife = g < 0 && g > -1 ? -Math.LN2 / Math.log(1 + g) : null;
  return {
    alpha: fit.beta[0],
    beta: fit.beta[1],
    adfStat: test.stat,
    cointegrated5: test.stat < EG_CRITICAL[5],
    halfLife,
    spreadStd: sd,
    zLast: sd > 0 ? last / sd : 0,
    n,
  };
}

/** RiskMetrics EWMA volatility (variance recursion) — fallback when GARCH fit is unstable. */
export function ewmaVol(returns, lambda = 0.94) {
  if (!returns.length) return 0;
  let v = variance(returns.slice(0, Math.min(20, returns.length)), 0) || returns[0] ** 2;
  for (const r of returns) v = lambda * v + (1 - lambda) * r * r;
  return Math.sqrt(v);
}

/**
 * GARCH(1,1) by quasi-maximum-likelihood with variance targeting and a coarse grid search.
 * Cheap (≈ 900 likelihood passes) and robust on the short, noisy series we see on event contracts.
 * Returns the one-step-ahead variance forecast and the long-run variance.
 */
export function garch11(returns) {
  const n = returns.length;
  if (n < 30) return null;
  const mu = mean(returns);
  const r = returns.map((x) => x - mu);
  const s2 = variance(r, 0);
  if (!(s2 > 0)) return null;
  let best = null;
  for (let a = 0.02; a <= 0.3001; a += 0.02) {
    for (let b = 0.5; b <= 0.9701; b += 0.01) {
      if (a + b >= 0.995) continue;
      const omega = s2 * (1 - a - b);
      let h = s2;
      let ll = 0;
      for (let t = 0; t < n; t++) {
        ll += -0.5 * (Math.log(h) + (r[t] * r[t]) / h);
        h = omega + a * r[t] * r[t] + b * h;
      }
      if (!best || ll > best.ll) best = { ll, a, b, omega, h };
    }
  }
  if (!best) return null;
  return {
    omega: best.omega,
    alpha: best.a,
    beta: best.b,
    persistence: best.a + best.b,
    forecastVar: best.h,
    longRunVar: best.omega / (1 - best.a - best.b),
    n,
  };
}

/** Exponential moving average of a numeric series (returns the final value). */
export function ema(series, span) {
  if (!series.length) return null;
  const k = 2 / (span + 1);
  let e = series[0];
  for (let i = 1; i < series.length; i++) e = k * series[i] + (1 - k) * e;
  return e;
}
