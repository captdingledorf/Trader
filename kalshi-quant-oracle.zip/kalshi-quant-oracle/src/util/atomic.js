/**
 * @file src/util/atomic.js
 * Docs: README.md §"State & persistence" · docs/DEPLOYMENT_ORACLE.md Step 12 (backups)
 *
 * Reasoning chain
 *  1. A trading bot must survive kill -9 / power loss / Oracle host maintenance without
 *     corrupting its ledger.
 *  2. write-to-temp + rename() is atomic on POSIX filesystems (ext4/xfs on OCI boot volumes).
 *  3. If a file is nevertheless unreadable we MOVE it aside (never delete) and start fresh,
 *     so a human can inspect it.
 */
import { promises as fs } from 'node:fs';
import path from 'node:path';

export async function writeJsonAtomic(file, data, mode = 0o600) {
  await fs.mkdir(path.dirname(file), { recursive: true, mode: 0o700 });
  const tmp = `${file}.${process.pid}.${Date.now()}.tmp`;
  await fs.writeFile(tmp, JSON.stringify(data, null, 2), { mode });
  await fs.rename(tmp, file);
}

/** Read JSON; ENOENT -> fallback; corrupt -> quarantine file and return fallback. */
export async function readJson(file, fallback = null, logger = null) {
  let raw;
  try {
    raw = await fs.readFile(file, 'utf8');
  } catch (e) {
    if (e.code === 'ENOENT') return fallback;
    throw e;
  }
  try {
    return JSON.parse(raw);
  } catch {
    const aside = `${file}.corrupt-${Date.now()}`;
    await fs.rename(file, aside).catch(() => {});
    logger?.error?.(`state file unreadable; moved to ${aside}`);
    return fallback;
  }
}

export async function appendJsonl(file, obj) {
  await fs.mkdir(path.dirname(file), { recursive: true, mode: 0o700 });
  await fs.appendFile(file, JSON.stringify(obj) + '\n', { mode: 0o600 });
}
