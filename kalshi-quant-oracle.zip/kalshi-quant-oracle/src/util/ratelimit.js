/**
 * @file src/util/ratelimit.js
 * Docs: README.md §"Kalshi API compatibility" (rate limits) · docs/AUDIT.md F-09
 *
 * Kalshi enforces per-tier request budgets (see docs.kalshi.com "Rate Limits"). We stay far
 * below any tier by default (reads 8/s, writes 4/s) and make both configurable.
 */
export const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

export class TokenBucket {
  /** @param {number} ratePerSec refill rate  @param {number} burst bucket capacity */
  constructor(ratePerSec, burst = Math.max(1, Math.ceil(ratePerSec))) {
    this.rate = ratePerSec;
    this.burst = burst;
    this.tokens = burst;
    this.last = Date.now();
  }

  #refill() {
    const now = Date.now();
    this.tokens = Math.min(this.burst, this.tokens + ((now - this.last) / 1000) * this.rate);
    this.last = now;
  }

  async take(n = 1) {
    for (;;) {
      this.#refill();
      if (this.tokens >= n) {
        this.tokens -= n;
        return;
      }
      await sleep(Math.ceil(((n - this.tokens) / this.rate) * 1000) + 5);
    }
  }
}
