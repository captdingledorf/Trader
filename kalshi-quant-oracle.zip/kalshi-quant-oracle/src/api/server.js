/**
 * @file src/api/server.js
 * Docs: README.md §"API Documentation" · docs/DEPLOYMENT_ORACLE.md Step 11 (SSH tunnel to the API) · docs/AUDIT.md F-04
 *
 * Endpoint parity with the original Node interface server (base path /api):
 *   GET /health  GET /status  GET /positions  GET /balance  GET /performance
 *   POST /start-trading  POST /stop-trading  GET /config  POST /config
 *   WebSocket  ws://host:port/ws   (send {"type":"subscribe"})
 *   Dashboard data (read-only, added in v1.1): GET /api/equity /api/trades /api/markets /api/signals /api/sentiment /api/logs
 *   Dashboard UI: GET /  (single self-contained page, src/ui/index.html; the page itself holds no secrets — every data call
 *   needs the bearer token, which you type into the page and which lives only in sessionStorage)
 *
 * WHAT CHANGED vs the original (and why)
 *   The README says "IP-based authentication for local access". That is not authentication: on a
 *   cloud VM behind a proxy every request appears local. We require `Authorization: Bearer <API_TOKEN>`
 *   on everything except /api/health, bind to 127.0.0.1 by default, and the Oracle security list
 *   opens NO inbound port besides SSH — reach the API through `ssh -L 3001:127.0.0.1:3001`.
 *   If API_TOKEN is unset the server is simply not started.
 */
import http from 'node:http';
import crypto from 'node:crypto';
import fs from 'node:fs';
import { WsHub } from '../util/wsHub.js';

const sha = (s) => crypto.createHash('sha256').update(String(s)).digest();
const safeEqual = (a, b) => crypto.timingSafeEqual(sha(a), sha(b));

const KEY_MAP = {
  maxPositionSize: 'maxPositionSize',
  stopLoss: 'stopLoss',
  newsSentimentThreshold: 'newsSentimentThreshold',
  statArbitrageThreshold: 'statArbitrageThreshold',
  volatilityThreshold: 'volatilityThreshold',
  tradeInterval: 'tradeInterval',
};

const sha256b64 = (s) => crypto.createHash('sha256').update(s, 'utf8').digest('base64');

/** Strict CSP for the single-file dashboard: only its own inline <script>/<style> (by hash), same-origin fetches, nothing else. */
export function uiCsp(html) {
  const inline = (tag) => {
    const m = html.match(new RegExp(`<${tag}>([\\s\\S]*?)</${tag}>`));
    return m ? `'sha256-${sha256b64(m[1])}'` : "'none'";
  };
  return ["default-src 'none'", `script-src ${inline('script')}`, `style-src ${inline('style')}`, "img-src 'self' data:", "connect-src 'self'", "base-uri 'none'", "form-action 'none'", "frame-ancestors 'none'"].join('; ');
}

export function createApiServer({ cfg, trader, settings, logger, qwen = null }) {
  let uiHtml = null;
  try {
    uiHtml = fs.readFileSync(new URL('../ui/index.html', import.meta.url), 'utf8');
  } catch {
    logger.warn('dashboard UI file not found (src/ui/index.html): API only');
  }
  const uiHeaders = uiHtml ? { 'Content-Type': 'text/html; charset=utf-8', 'Content-Security-Policy': uiCsp(uiHtml), 'X-Content-Type-Options': 'nosniff', 'X-Frame-Options': 'DENY', 'Referrer-Policy': 'no-referrer', 'Cache-Control': 'no-store' } : null;
  const logRing = []; // last 200 log lines for GET /api/logs
  logger.subscribe((lvl, msg, ts) => {
    logRing.push({ ts, lvl, msg });
    if (logRing.length > 200) logRing.shift();
  });
  const token = cfg.api.token;
  const hits = new Map(); // ip → {n, reset}
  const limiter = setInterval(() => {
    const now = Date.now();
    for (const [ip, h] of hits) if (h.reset < now) hits.delete(ip);
  }, 60000);
  limiter.unref?.();

  const bearer = (req) => {
    const h = req.headers.authorization ?? '';
    return h.startsWith('Bearer ') ? h.slice(7) : '';
  };
  const authed = (req) => Boolean(token) && safeEqual(bearer(req), token);

  const hub = new WsHub({
    logger,
    authenticate: (req) => {
      const q = new URL(req.url, 'http://x').searchParams.get('token') ?? '';
      return authed(req) || (Boolean(token) && safeEqual(q, token)); // browsers cannot set headers on WebSocket
    },
  });
  const fwd = (type) => (payload) => hub.broadcast({ type, data: payload, timestamp: new Date().toISOString() });
  trader.on('status', fwd('status'));
  trader.on('trade_executed', fwd('trade_executed'));
  trader.on('bot_error', fwd('bot_error'));
  trader.on('risk_event', fwd('risk_event'));
  trader.on('config_updated', fwd('config_updated'));
  logger.subscribe((lvl, msg) => {
    if (lvl !== 'debug') hub.broadcast({ type: 'bot_output', data: { level: lvl, message: msg }, timestamp: new Date().toISOString() });
  });

  const send = (res, code, obj, close = false) => {
    const body = JSON.stringify(obj);
    res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Content-Length': Buffer.byteLength(body), 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff', ...(close ? { Connection: 'close' } : {}) });
    res.end(body);
  };

  // Oversized bodies: stop buffering and answer 413 with `Connection: close` (destroying the socket
  // first would hand the client an unexplained connection reset instead of a clean error).
  const readBody = (req) =>
    new Promise((resolve, reject) => {
      let size = 0;
      let tooBig = false;
      const chunks = [];
      req.on('data', (c) => {
        size += c.length;
        if (size > 16 * 1024) {
          if (!tooBig) reject(Object.assign(new Error('body too large'), { code: 413 }));
          tooBig = true;
          chunks.length = 0;
        } else if (!tooBig) chunks.push(c);
      });
      req.on('end', () => {
        if (!chunks.length) return resolve({});
        try {
          resolve(JSON.parse(Buffer.concat(chunks).toString('utf8')));
        } catch {
          reject(Object.assign(new Error('invalid JSON'), { code: 400 }));
        }
      });
      req.on('error', reject);
    });

  const configView = () => {
    const v = settings.get();
    return { maxPositionSize: v.maxPositionSize, stopLoss: v.stopLoss, newsSentimentThreshold: v.newsSentimentThreshold, statArbitrageThreshold: v.statArbitrageThreshold, volatilityThreshold: v.volatilityThreshold, tradeInterval: v.tradeInterval, ...v, strategies: settings.enabledStrategies() };
  };

  const server = http.createServer(async (req, res) => {
    try {
      const ip = req.socket.remoteAddress ?? '?';
      const h = hits.get(ip) ?? { n: 0, reset: Date.now() + 60000 };
      h.n += 1;
      hits.set(ip, h);
      if (h.n > 120) return send(res, 429, { error: 'rate limit' });

      const url = new URL(req.url, 'http://x');
      const route = `${req.method} ${url.pathname}`;
      if (uiHtml && (req.method === 'GET' || req.method === 'HEAD') && (url.pathname === '/' || url.pathname === '/ui' || url.pathname === '/index.html')) {
        res.writeHead(200, { ...uiHeaders, 'Content-Length': Buffer.byteLength(uiHtml) });
        return res.end(req.method === 'HEAD' ? undefined : uiHtml);
      }
      if (route === 'GET /api/health') return send(res, 200, { status: 'healthy', timestamp: new Date().toISOString(), engine: trader.stopped ? 'stopped' : 'running' });
      if (!authed(req)) return send(res, 401, { error: 'unauthorized' });

      switch (route) {
        case 'GET /api/status':
          return send(res, 200, trader.status());
        case 'GET /api/positions':
          return send(res, 200, trader.positionsView());
        case 'GET /api/balance':
          return send(res, 200, trader.balanceView());
        case 'GET /api/performance':
          return send(res, 200, trader.performanceView());
        case 'GET /api/equity':
          return send(res, 200, trader.equityView());
        case 'GET /api/trades':
          return send(res, 200, trader.tradesView());
        case 'GET /api/markets':
          return send(res, 200, trader.marketsView());
        case 'GET /api/signals':
          return send(res, 200, trader.signalsView());
        case 'GET /api/sentiment':
          return send(res, 200, { qwen: qwen ? qwen.summary() : null, recent: qwen ? qwen.recent.slice(0, 40) : [] });
        case 'GET /api/logs':
          return send(res, 200, logRing.slice(-150));
        case 'POST /api/start-trading':
          if (trader.halted) return send(res, 409, { success: false, message: `halted: ${trader.haltText}` });
          if (cfg.live && cfg.kalshiEnv === 'prod') return send(res, 403, { success: false, message: 'Real-money trading can only be started from Telegram (confirmation button).' });
          trader.setTrading(true, 'api');
          return send(res, 200, { success: true, message: 'Trading started successfully' });
        case 'POST /api/stop-trading':
          trader.setTrading(false, 'api');
          return send(res, 200, { success: true, message: 'Trading stopped successfully' });
        case 'GET /api/config':
          return send(res, 200, configView());
        case 'POST /api/config': {
          const body = await readBody(req);
          if (body === null || typeof body !== 'object' || Array.isArray(body)) return send(res, 400, { success: false, message: 'body must be a JSON object' });
          const patch = {};
          const known = settings.get();
          for (const [k, v] of Object.entries(body)) if (Object.hasOwn(KEY_MAP, k) || Object.hasOwn(known, k)) patch[k] = v;
          const { applied, errors } = await settings.patch(patch);
          if (Object.keys(applied).length) trader.emit('config_updated', applied);
          if (errors.length) return send(res, 400, { success: false, message: errors.join('; ') });
          return send(res, 200, { success: true, message: 'Configuration updated successfully' });
        }
        default:
          return send(res, 404, { error: 'not found' });
      }
    } catch (e) {
      logger.warn(`api error: ${e.message}`);
      if (!res.headersSent) send(res, e.code === 413 || e.code === 400 ? e.code : 500, { error: e.code ? e.message : 'internal error' }, e.code === 413);
    }
  });
  server.on('upgrade', (req, socket) => hub.handleUpgrade(req, socket));
  server.headersTimeout = 10000;
  server.requestTimeout = 15000;

  return {
    server,
    hub,
    listen: () =>
      new Promise((resolve, reject) => {
        server.once('error', reject);
        server.listen(cfg.api.port, cfg.api.host, () => resolve(server.address()));
      }),
    close: () => {
      clearInterval(limiter);
      hub.close();
      return new Promise((r) => server.close(r));
    },
  };
}

/* ── Developer support (kept out of docs on purpose) ─────────────────────────
 * Andrew Ivan Bell · CashApp: $tomesingsoc · Coinbase: aibell@live.com
 * ─────────────────────────────────────────────────────────────────────────── */
