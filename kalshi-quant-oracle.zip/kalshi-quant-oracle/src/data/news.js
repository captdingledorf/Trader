/**
 * @file src/data/news.js
 * Docs: README.md §"News Sentiment Analysis Strategy" · docs/AUDIT.md F-10, F-20 · docs/QWEN.md (LLM alternative)
 *
 * The original README describes transformer-based NLP. Transformer inference needs hundreds of MB of RAM, so
 * the DEFAULT scorer here is a transparent lexicon (≈100 words, negation + intensifier handling); an optional
 * local Qwen model (src/ai/qwen.js) can replace/augment it on shapes with enough RAM. The lexicon measures the
 * TONE of headlines, not the probability that a specific market resolves YES, so the strategy ships OFF.
 *
 * SECURITY / ROBUSTNESS (audit pass 2): feeds are untrusted input. The first version used regexes with lazy
 * quantifiers that were QUADRATIC on hostile input (an 80 000-fold unclosed CDATA took 76 s of CPU and froze
 * the event loop). The parser below uses only indexOf scans and single passes — O(n) for every input — plus
 * hard caps on bytes, items and field lengths. Tests: test/hardening.test.js.
 *
 * Feeds are plain RSS/Atom (NEWS_FEEDS). Defaults: BBC News + NPR top stories — free, no API key. Verify
 * availability from your instance before enabling (deployment Step 8).
 */
import { readTextCapped } from '../util/http.js';

const MAX_FEED_BYTES = 1_000_000;
const MAX_ITEMS = 100;
const MAX_TITLE = 400;
const MAX_SUMMARY = 1500;

const ENT = { amp: '&', lt: '<', gt: '>', quot: '"', apos: "'", nbsp: ' ' };

function codePoint(n) {
  return Number.isInteger(n) && n >= 0 && n <= 0x10ffff && !(n >= 0xd800 && n <= 0xdfff) ? String.fromCodePoint(n) : '\uFFFD';
}

/** Replace <![CDATA[ … ]]> sections by their content, in one linear pass (unclosed sections are left as text). */
function unCdata(s) {
  let out = '';
  let pos = 0;
  for (;;) {
    const a = s.indexOf('<![CDATA[', pos);
    if (a === -1) break;
    const b = s.indexOf(']]>', a + 9);
    if (b === -1) break;
    out += s.slice(pos, a) + s.slice(a + 9, b);
    pos = b + 3;
  }
  return out + s.slice(pos);
}

/** Remove <…> tags in one linear pass; a '<' with no later '>' is kept as literal text. */
function stripTags(s) {
  let out = '';
  let pos = 0;
  for (;;) {
    const lt = s.indexOf('<', pos);
    if (lt === -1) break;
    const gt = s.indexOf('>', lt + 1);
    if (gt === -1) break;
    out += s.slice(pos, lt) + ' ';
    pos = gt + 1;
  }
  return out + s.slice(pos);
}

/** Decode the five XML entities plus numeric references (linear regexes: no nested quantifiers). */
function decode(s) {
  return s
    .replace(/&(amp|lt|gt|quot|apos|nbsp);/g, (_m, n) => ENT[n])
    .replace(/&#(\d{1,7});/g, (_m, d) => codePoint(Number(d)))
    .replace(/&#x([0-9a-fA-F]{1,6});/g, (_m, h) => codePoint(parseInt(h, 16)));
}

const clean = (s, max) => decode(stripTags(decode(unCdata(s.slice(0, max * 4))))).replace(/\s+/g, ' ').trim().slice(0, max);

/** First <name>…</name> inside a block (exact-case, as XML is case-sensitive). O(n). */
function tag(block, name, max) {
  const open = `<${name}`;
  let from = 0;
  for (;;) {
    const s = block.indexOf(open, from);
    if (s === -1) return '';
    const c = block[s + open.length];
    if (c !== '>' && c !== ' ' && c !== '\t' && c !== '\n' && c !== '\r' && c !== '/') {
      from = s + open.length; // e.g. <titleX
      continue;
    }
    const gt = block.indexOf('>', s);
    if (gt === -1 || block[gt - 1] === '/') return '';
    const close = block.indexOf(`</${name}>`, gt + 1);
    if (close === -1) return '';
    return clean(block.slice(gt + 1, close), max);
  }
}

/** Yield <item>/<entry> blocks without ever rescanning consumed text. */
function* blocks(xml) {
  let pos = 0;
  let nextItem = xml.indexOf('<item', 0);
  let nextEntry = xml.indexOf('<entry', 0);
  let count = 0;
  while (count < MAX_ITEMS) {
    if (nextItem !== -1 && nextItem < pos) nextItem = xml.indexOf('<item', pos);
    if (nextEntry !== -1 && nextEntry < pos) nextEntry = xml.indexOf('<entry', pos);
    if (nextItem === -1 && nextEntry === -1) return;
    const useItem = nextEntry === -1 || (nextItem !== -1 && nextItem < nextEntry);
    const start = useItem ? nextItem : nextEntry;
    const name = useItem ? 'item' : 'entry';
    const after = xml[start + name.length + 1];
    if (after !== '>' && after !== ' ' && after !== '\t' && after !== '\n' && after !== '\r') {
      pos = start + 1; // <items>, <entryX> …
      continue;
    }
    const endTag = `</${name}>`;
    const end = xml.indexOf(endTag, start);
    if (end === -1) return; // unclosed: stop instead of rescanning
    yield xml.slice(start, end + endTag.length);
    pos = end + endTag.length;
    count += 1;
  }
}

/** Parse RSS 2.0 <item> or Atom <entry> blocks. Pure, linear-time (unit- and hostile-input-tested). */
export function parseFeed(xml, source = '') {
  const out = [];
  for (const b of blocks(xml.slice(0, MAX_FEED_BYTES))) {
    const title = tag(b, 'title', MAX_TITLE);
    if (!title) continue;
    out.push({ title, summary: tag(b, 'description', MAX_SUMMARY) || tag(b, 'summary', MAX_SUMMARY), published: tag(b, 'pubDate', 80) || tag(b, 'updated', 80), source });
  }
  return out;
}

export class NewsFeed {
  constructor({ feeds, fetchImpl = globalThis.fetch, ttlMs = 10 * 60 * 1000, logger = null, now = () => Date.now() }) {
    this.feeds = feeds;
    this.fetch = fetchImpl;
    this.ttl = ttlMs;
    this.logger = logger;
    this.now = now;
    this.cache = { at: 0, items: [] };
  }

  async headlines() {
    if (this.now() - this.cache.at < this.ttl) return this.cache.items;
    const items = [];
    for (const url of this.feeds) {
      try {
        if (!/^https:\/\//.test(url)) throw new Error('feed URL must be https');
        const res = await this.fetch(url, { signal: AbortSignal.timeout(8000), headers: { 'User-Agent': 'kalshi-quant-telebot-node/1.1' } });
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const { text } = await readTextCapped(res, MAX_FEED_BYTES); // truncated feeds are parsed as far as they go
        items.push(...parseFeed(text, new URL(url).hostname));
      } catch (e) {
        this.logger?.warn?.(`news feed failed (${url}): ${e.message}`);
      }
    }
    this.cache = { at: this.now(), items };
    return items;
  }
}

/* ── lexicon sentiment ──────────────────────────────────────────────── */
const POS = new Set(
  'win wins won winning victory leads lead ahead surge surges surged rise rises rose gain gains gained growth grow grows record boost boosts boosted approve approves approved approval passes passed agreement deal deals success successful strong stronger recovery recover rebound improve improves improved optimism optimistic breakthrough celebrate secure secures secured upgrade beat beats exceeds exceeded advance advances advancing support backs backed endorse endorses confirm confirms confirmed resolve resolves ceasefire peace expand expands'.split(' '),
);
const NEG = new Set(
  'lose loses lost losing defeat defeated trails behind fall falls fell drop drops dropped plunge plunges plunged decline declines declined crisis crash crashes collapse collapses fail fails failed failure reject rejects rejected rejection delay delays delayed cut cuts slump slumps weak weaker recession fear fears worry worries scandal probe investigation indicted charged resign resigns resigned war attack attacks strike strikes threat threatens threatened ban bans banned block blocks blocked veto vetoes vetoed shutdown default downgrade miss misses'.split(' '),
);
const NEGATORS = new Set(['not', 'no', 'never', 'without', "isn't", "wasn't", "won't", "doesn't", "didn't", 'fails', 'unlikely']);
const BOOST = new Set(['very', 'sharply', 'strongly', 'dramatically', 'massive', 'major', 'huge']);

/** Score free text in [-1, 1]. tanh-squashed sum of lexicon hits with 3-word negation window. */
export function scoreText(text) {
  const words = text.slice(0, 20000).toLowerCase().replace(/[^a-z' ]+/g, ' ').split(/\s+/).filter(Boolean);
  let sum = 0;
  let hits = 0;
  for (let i = 0; i < words.length; i++) {
    let v = POS.has(words[i]) ? 1 : NEG.has(words[i]) ? -1 : 0;
    if (!v) continue;
    for (let j = Math.max(0, i - 3); j < i; j++) {
      if (NEGATORS.has(words[j])) v = -v;
      if (BOOST.has(words[j])) v *= 1.5;
    }
    sum += v;
    hits += 1;
  }
  return hits ? Math.tanh(sum / Math.sqrt(hits + 1)) : 0;
}

const STOP = new Set('the a an and or of to in on for at by with from will be is are was were this that these those than then who what when where which whom how any all not no yes before after over under above below between into during per vs'.split(' '));
export const tokens = (text) => new Set(text.slice(0, 5000).toLowerCase().replace(/[^a-z0-9 ]+/g, ' ').split(/\s+/).filter((w) => w.length >= 3 && !STOP.has(w)));

/** Overlap relevance of a headline to a market title in [0,1] (needs ≥2 shared tokens). */
export function relevance(titleTokens, headline) {
  const h = tokens(headline);
  let shared = 0;
  for (const t of titleTokens) if (h.has(t)) shared += 1;
  if (shared < 2) return 0;
  return Math.min(1, shared / Math.min(titleTokens.size, 6));
}
