/**
 * @file src/data/scanner.js
 * Docs: README.md §"Data Ingestion" · docs/DEPLOYMENT_ORACLE.md Step 6 (SCAN_* tuning for 1 GB RAM)
 *
 * WHAT IT DOES
 *  - pulls open events (+ nested markets) from Kalshi each cycle, normalises them
 *  - fetches individually any held ticker that fell outside the scanned pages
 *  - records one mid-price sample per cycle into bounded ring buffers (the only history the
 *    volatility and cointegration strategies have; they need a warm-up period)
 *
 * MEMORY BUDGET (chain of thought): E2.1.Micro has 1 GB RAM and shares it with the OS.
 *   300 tickers × 400 samples × 8 bytes ≈ 1 MB → trivially small; the expensive part is the raw
 *   /events JSON, which we parse page-by-page and discard (SCAN_MAX_PAGES, default 3 × 200 events).
 */
import path from 'node:path';
import { scanEvents } from '../kalshi/client.js';
import { readJson, writeJsonAtomic } from '../util/atomic.js';

const TRADABLE = new Set(['active', 'open']);

export class MarketScanner {
  constructor({ client, cfg, logger = null, now = () => Date.now() }) {
    this.client = client;
    this.cfg = cfg;
    this.logger = logger;
    this.now = now;
    this.file = path.join(cfg.dataDir, 'price_history.json');
    this.history = new Map(); // ticker → number[]
    this.events = new Map();
    this.quotes = new Map(); // ticker → normalized market (all scanned + extras)
    this.scans = 0;
  }

  async load() {
    const saved = await readJson(this.file, null, this.logger);
    if (saved?.history) for (const [k, v] of Object.entries(saved.history)) this.history.set(k, v);
    return this;
  }

  save() {
    return writeJsonAtomic(this.file, { savedAt: new Date(this.now()).toISOString(), history: Object.fromEntries(this.history) });
  }

  isTradable(m) {
    const s = this.cfg.scan;
    if (!TRADABLE.has(m.status)) return false;
    if (m.yesBid === null || m.yesAsk === null || m.noAsk === null || m.noBid === null) return false;
    if (m.spread === null || m.spread > s.maxSpread) return false;
    if (m.mid < 0.03 || m.mid > 0.97) return false;
    if (m.volume24h < s.minVolume24h) return false;
    if (m.closeTime) {
      const mins = (Date.parse(m.closeTime) - this.now()) / 60000;
      if (Number.isFinite(mins) && mins < s.minMinutesToClose) return false;
    }
    return true;
  }

  /**
   * @param {{extraTickers?: string[], priorityTickers?: string[]}} opts
   * @returns {{markets: object[], quotes: Map, events: Map}} markets = tradable subset
   */
  async scan({ extraTickers = [], priorityTickers = [] } = {}) {
    const { markets, events } = await scanEvents(this.client, { maxPages: this.cfg.scan.maxPages, limit: this.cfg.scan.pageLimit ?? 100 });
    this.events = events;
    this.quotes = new Map(markets.map((m) => [m.ticker, m]));
    for (const t of new Set(extraTickers)) {
      if (this.quotes.has(t)) continue;
      try {
        this.quotes.set(t, await this.client.getMarket(t));
      } catch (e) {
        this.logger?.warn?.(`quote fetch failed for ${t}: ${e.message}`);
      }
    }
    const tradable = markets.filter((m) => this.isTradable(m));
    this.#record(tradable, new Set([...priorityTickers, ...extraTickers]));
    this.scans += 1;
    return { markets: tradable, quotes: this.quotes, events: this.events };
  }

  #record(tradable, priority) {
    const max = this.cfg.scan.historyMax;
    const keep = new Set(priority);
    const byVol = [...tradable].sort((a, b) => b.volume24h - a.volume24h);
    for (const m of byVol) {
      if (keep.size >= this.cfg.scan.historyTickers) break;
      keep.add(m.ticker);
    }
    for (const t of keep) {
      const q = this.quotes.get(t);
      if (!q || q.mid === null || q.mid === undefined) continue;
      const arr = this.history.get(t) ?? [];
      arr.push(+q.mid.toFixed(4));
      if (arr.length > max) arr.splice(0, arr.length - max);
      this.history.set(t, arr);
    }
    for (const t of [...this.history.keys()]) if (!keep.has(t)) this.history.delete(t);
  }
}
