/**
 * @file src/config.js
 * Docs: README.md §"Configuration" · docs/DEPLOYMENT_ORACLE.md Step 6 (secrets & env file)
 *
 * TWO KINDS OF CONFIGURATION (chain of thought)
 *  1. Static / secret config → environment variables (systemd EnvironmentFile on Oracle).
 *     Changing it requires a restart; it contains credentials and safety gates.
 *  2. Runtime-tunable settings → SettingsStore (persisted to DATA_DIR/bot_settings.json).
 *     These map 1:1 to the original project's `/settings` + `POST /api/config` surface:
 *       maxPositionSize, stopLoss, newsSentimentThreshold, statArbitrageThreshold,
 *       volatilityThreshold, tradeInterval  (+ a few risk additions).
 *
 * SAFETY GATES (tree of thought)
 *   mode=paper                       → never sends an order to Kalshi.                    [default]
 *   mode=live + env=demo             → orders go to Kalshi's DEMO exchange (play money).
 *   mode=live + env=prod             → REAL MONEY: additionally requires
 *                                      I_UNDERSTAND_LIVE_TRADING_RISK=yes, else startup aborts.
 *   Trading never auto-resumes after a restart unless AUTOSTART_TRADING=true.
 */
import fs from 'node:fs';
import path from 'node:path';
import { EventEmitter } from 'node:events';
import { writeJsonAtomic, readJson } from './util/atomic.js';

export class ConfigError extends Error {}

/** Minimal .env parser (KEY=VALUE, # comments, optional quotes). Never overrides real env vars. */
export function loadDotEnv(file = '.env') {
  let raw;
  try {
    raw = fs.readFileSync(file, 'utf8');
  } catch {
    return false;
  }
  for (const line of raw.split(/\r?\n/)) {
    const m = line.match(/^\s*(?:export\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*?)\s*$/);
    if (!m || line.trim().startsWith('#')) continue;
    let v = m[2];
    if ((v.startsWith('"') && v.endsWith('"')) || (v.startsWith("'") && v.endsWith("'"))) v = v.slice(1, -1);
    if (process.env[m[1]] === undefined) process.env[m[1]] = v.includes('-----BEGIN') ? v.replace(/\\n/g, '\n') : v;
  }
  return true;
}

/** Runtime-tunable settings: key → {env, def, min, max, int?}. camelCase keys match the original REST API. */
export const SETTINGS_SCHEMA = {
  bankroll: { env: 'BANKROLL', def: 1000, min: 1, max: 1e7, doc: 'Capital the bot may deploy (USD). Paper: starting cash. Live: cap on balance.' },
  tradeInterval: { env: 'TRADE_INTERVAL_SECONDS', def: 60, min: 10, max: 3600, int: true, doc: 'Seconds between trading cycles.' },
  maxPositionSize: { env: 'MAX_POSITION_SIZE_PERCENTAGE', def: 0.1, min: 0.001, max: 0.5, doc: 'Max stake per position as a fraction of bankroll.' },
  stopLoss: { env: 'STOP_LOSS_PERCENTAGE', def: 0.05, min: 0.005, max: 0.9, doc: 'Fixed stop-loss as a fraction of entry cost.' },
  newsSentimentThreshold: { env: 'NEWS_SENTIMENT_THRESHOLD', def: 0.6, min: 0.05, max: 1, doc: 'Min |sentiment| to act (-1..1).' },
  statArbitrageThreshold: { env: 'STAT_ARBITRAGE_THRESHOLD', def: 0.05, min: 0.005, max: 0.5, doc: 'Min price deviation ($) for arbitrage signals.' },
  volatilityThreshold: { env: 'VOLATILITY_THRESHOLD', def: 0.1, min: 0.01, max: 0.5, doc: 'Min deviation of mid from its EMA (probability units) to fade.' },
  maxDailyLoss: { env: 'MAX_DAILY_LOSS', def: 0.02, min: 0.001, max: 1, doc: 'Halt new entries when day loss exceeds this fraction of day-start equity.' },
  maxOpenPositions: { env: 'MAX_OPEN_POSITIONS', def: 10, min: 1, max: 200, int: true, doc: 'Max concurrent positions.' },
  correlationLimit: { env: 'CORRELATION_LIMIT', def: 0.7, min: 0.1, max: 1, doc: 'Skip a candidate whose price series correlates above this with an open position.' },
  kellyScale: { env: 'KELLY_SCALING_FACTOR', def: 0.25, min: 0.01, max: 1, doc: 'Fraction of full Kelly to use (0.25 = quarter-Kelly).' },
  maxOrderContracts: { env: 'MAX_ORDER_CONTRACTS', def: 50, min: 1, max: 10000, int: true, doc: 'Hard cap on contracts per order.' },
  maxDrawdown: { env: 'MAX_DRAWDOWN', def: 0.1, min: 0.01, max: 1, doc: 'Halt new entries when equity falls this far below its peak.' },
  minEdge: { env: 'MIN_EDGE', def: 0.03, min: 0.005, max: 0.5, doc: 'Min net edge per contract ($) after fees for single-leg signals.' },
};

/* Strict env parsing: an explicitly-set but invalid value is a startup error, never a silent default
 * (a typo like AUTOSTART_TRADING=ture or SCAN_MAX_PAGES=three must not quietly change behaviour). */
const bool = (name, v, d = false) => {
  if (v === undefined || String(v).trim() === '') return d;
  const x = String(v).trim().toLowerCase();
  if (['1', 'true', 'yes', 'on'].includes(x)) return true;
  if (['0', 'false', 'no', 'off'].includes(x)) return false;
  throw new ConfigError(`${name}=${v}: expected true/false`);
};
const num = (name, v, d, { min = -Infinity, max = Infinity, integer = false } = {}) => {
  if (v === undefined || String(v).trim() === '') return d;
  const n = Number(v);
  if (!Number.isFinite(n) || (integer && !Number.isInteger(n)) || n < min || n > max) {
    throw new ConfigError(`${name}=${v}: expected ${integer ? 'an integer' : 'a number'} between ${min} and ${max}`);
  }
  return n;
};

export const STRATEGY_NAMES = ['arbitrage', 'volatility', 'sentiment'];

/** Validate and coerce one setting; returns {ok, value|error}. */
export function coerceSetting(key, raw) {
  if (!Object.hasOwn(SETTINGS_SCHEMA, key)) return { ok: false, error: `unknown setting "${String(key).slice(0, 40)}"` };
  const spec = SETTINGS_SCHEMA[key];
  const n = Number(raw);
  if (!Number.isFinite(n)) return { ok: false, error: `${key} must be a number` };
  if (spec.int && !Number.isInteger(n)) return { ok: false, error: `${key} must be an integer` };
  if (n < spec.min || n > spec.max) return { ok: false, error: `${key} must be between ${spec.min} and ${spec.max}` };
  return { ok: true, value: n };
}

export class SettingsStore extends EventEmitter {
  constructor(file, initial, strategies) {
    super();
    this.file = file;
    this.values = initial;
    this.strategies = new Set(strategies);
  }

  get() {
    return { ...this.values };
  }

  isEnabled(name) {
    return this.strategies.has(name);
  }

  enabledStrategies() {
    return [...this.strategies];
  }

  /** Apply a patch of {key: value}; accepts only schema keys. Returns {applied, errors}. */
  async patch(patch) {
    const applied = {};
    const errors = [];
    for (const [k, v] of Object.entries(patch ?? {})) {
      const r = coerceSetting(k, v);
      if (r.ok) applied[k] = r.value;
      else errors.push(r.error);
    }
    if (Object.keys(applied).length) {
      Object.assign(this.values, applied);
      await this.#persist();
      this.emit('updated', applied);
    }
    return { applied, errors };
  }

  async setStrategy(name, on) {
    if (!STRATEGY_NAMES.includes(name)) return false;
    if (on) this.strategies.add(name);
    else this.strategies.delete(name);
    await this.#persist();
    this.emit('updated', { strategies: this.enabledStrategies() });
    return true;
  }

  async #persist() {
    await writeJsonAtomic(this.file, { values: this.values, strategies: this.enabledStrategies() });
  }
}

/** Build the immutable environment config and the mutable settings store. */
export async function loadConfig(env = process.env) {
  const dataDir = path.resolve(env.DATA_DIR ?? './data');
  const mode = (env.TRADING_MODE ?? 'paper').toLowerCase();
  const kalshiEnv = (env.KALSHI_ENV ?? 'demo').toLowerCase();
  if (!['paper', 'live'].includes(mode)) throw new ConfigError('TRADING_MODE must be "paper" or "live"');
  if (!['demo', 'prod'].includes(kalshiEnv)) throw new ConfigError('KALSHI_ENV must be "demo" or "prod"');

  const defaultBase = kalshiEnv === 'prod' ? 'https://api.elections.kalshi.com/trade-api/v2' : 'https://demo-api.kalshi.co/trade-api/v2';
  const baseUrl = (env.KALSHI_BASE_URL || defaultBase).replace(/\/+$/, '');
  let u;
  try {
    u = new URL(baseUrl);
  } catch {
    throw new ConfigError('KALSHI_BASE_URL must be a valid URL');
  }
  // Loopback http is allowed ONLY so the test-suite / a local mock can stand in for Kalshi: signed requests sent
  // to 127.0.0.1 never leave the machine. Everything else must be https on *.kalshi.com / *.kalshi.co.
  const loopback = ['127.0.0.1', 'localhost', '[::1]'].includes(u.hostname);
  if (!loopback) {
    if (u.protocol !== 'https:') throw new ConfigError('KALSHI_BASE_URL must be https');
    if (!/(^|\.)kalshi\.(com|co)$/.test(u.hostname)) throw new ConfigError(`KALSHI_BASE_URL host "${u.hostname}" is not a kalshi.com / kalshi.co host`);
  }

  const keyId = env.KALSHI_API_KEY_ID || env.KALSHI_API_KEY || '';
  const live = mode === 'live';
  const autostart = bool('AUTOSTART_TRADING', env.AUTOSTART_TRADING, false);
  if (live && !keyId) throw new ConfigError('TRADING_MODE=live requires KALSHI_API_KEY_ID and a private key');
  if (live && kalshiEnv === 'prod' && env.I_UNDERSTAND_LIVE_TRADING_RISK !== 'yes') {
    throw new ConfigError('REAL-MONEY MODE BLOCKED: set I_UNDERSTAND_LIVE_TRADING_RISK=yes to trade on production Kalshi.');
  }
  if (live && kalshiEnv === 'prod' && autostart) {
    throw new ConfigError('AUTOSTART_TRADING=true is not allowed with real money: start trading from Telegram (confirmation button) after every restart.');
  }

  const apiToken = env.API_TOKEN ?? '';
  if (apiToken && apiToken.length < 24) throw new ConfigError('API_TOKEN must be at least 24 characters');
  const apiHost = env.API_HOST || '127.0.0.1';
  if (apiHost !== '127.0.0.1' && apiHost !== '::1' && apiHost !== 'localhost' && !apiToken) {
    throw new ConfigError('API_HOST is not loopback but API_TOKEN is empty');
  }
  const orderFieldStyle = (env.KALSHI_ORDER_FIELD_STYLE || 'fixed').toLowerCase();
  if (!['fixed', 'legacy', 'both'].includes(orderFieldStyle)) throw new ConfigError('KALSHI_ORDER_FIELD_STYLE must be fixed, legacy or both');
  const logLevel = (env.LOG_LEVEL || 'info').toLowerCase();
  if (!['debug', 'info', 'warn', 'error'].includes(logLevel)) throw new ConfigError('LOG_LEVEL must be debug, info, warn or error');

  const chatIds = (env.TELEGRAM_CHAT_ID ?? '').split(',').map((s) => s.trim()).filter(Boolean);
  for (const id of chatIds) if (!/^\d{1,20}$/.test(id)) throw new ConfigError(`TELEGRAM_CHAT_ID entry "${id.slice(0, 20)}" is not a numeric user ID`);

  const cfg = Object.freeze({
    mode,
    live,
    kalshiEnv,
    baseUrl,
    keyId,
    dataDir,
    logLevel,
    logJson: bool('LOG_JSON', env.LOG_JSON, false),
    autostart,
    exitsWhenStopped: bool('EXITS_WHEN_STOPPED', env.EXITS_WHEN_STOPPED, false),
    feeCoeff: num('FEE_COEFFICIENT', env.FEE_COEFFICIENT, 0.07, { min: 0, max: 0.5 }),
    orderFieldStyle,
    readRps: num('KALSHI_READ_RPS', env.KALSHI_READ_RPS, 8, { min: 0.1, max: 50 }),
    writeRps: num('KALSHI_WRITE_RPS', env.KALSHI_WRITE_RPS, 4, { min: 0.1, max: 20 }),
    maxResponseBytes: num('KALSHI_MAX_RESPONSE_MB', env.KALSHI_MAX_RESPONSE_MB, 25, { min: 1, max: 200 }) * 1024 * 1024,
    scan: {
      maxPages: num('SCAN_MAX_PAGES', env.SCAN_MAX_PAGES, 3, { min: 1, max: 20, integer: true }),
      pageLimit: num('SCAN_PAGE_LIMIT', env.SCAN_PAGE_LIMIT, 100, { min: 10, max: 200, integer: true }),
      minVolume24h: num('SCAN_MIN_VOLUME_24H', env.SCAN_MIN_VOLUME_24H, 0, { min: 0 }),
      maxSpread: num('SCAN_MAX_SPREAD', env.SCAN_MAX_SPREAD, 0.08, { min: 0.001, max: 0.5 }),
      minMinutesToClose: num('SCAN_MIN_MINUTES_TO_CLOSE', env.SCAN_MIN_MINUTES_TO_CLOSE, 30, { min: 0, max: 10080, integer: true }),
      historyMax: num('PRICE_HISTORY_MAX', env.PRICE_HISTORY_MAX, 400, { min: 20, max: 5000, integer: true }),
      historyTickers: num('PRICE_HISTORY_TICKERS', env.PRICE_HISTORY_TICKERS, 300, { min: 1, max: 2000, integer: true }),
    },
    paper: { slippage: num('PAPER_SLIPPAGE', env.PAPER_SLIPPAGE, 0.01, { min: 0, max: 0.2 }), assumedDepth: num('PAPER_ASSUMED_DEPTH', env.PAPER_ASSUMED_DEPTH, 20, { min: 1, max: 100000, integer: true }) },
    arbitrageAutoExec: bool('ARBITRAGE_AUTOEXEC', env.ARBITRAGE_AUTOEXEC, false),
    reconcileEvery: num('RECONCILE_EVERY_N_CYCLES', env.RECONCILE_EVERY_N_CYCLES, 3, { min: 1, max: 1000, integer: true }),
    maxNewTradesPerCycle: num('MAX_NEW_TRADES_PER_CYCLE', env.MAX_NEW_TRADES_PER_CYCLE, 3, { min: 1, max: 20, integer: true }),
    timeStopHours: num('TIME_STOP_HOURS', env.TIME_STOP_HOURS, 0, { min: 0, max: 8760 }),
    relationsFile: env.RELATIONS_FILE || path.join(dataDir, 'relations.json'),
    newsFeeds: (env.NEWS_FEEDS || 'https://feeds.bbci.co.uk/news/rss.xml,https://feeds.npr.org/1001/rss.xml').split(',').map((s) => s.trim()).filter(Boolean),
    telegram: { token: env.TELEGRAM_BOT_TOKEN ?? '', chatIds, apiBase: telegramBase(env.TELEGRAM_API_URL) },
    api: { host: apiHost, port: num('API_PORT', env.API_PORT, 3001, { min: 0, max: 65535, integer: true }), token: apiToken },
    qwen: qwenConfig(env),
  });

  // Runtime settings: defaults ← env ← persisted file (file wins so Telegram/API edits survive restarts).
  const initial = {};
  for (const [k, spec] of Object.entries(SETTINGS_SCHEMA)) {
    const raw = env[spec.env];
    if (raw !== undefined && String(raw).trim() !== '') {
      const r = coerceSetting(k, raw);
      if (!r.ok) throw new ConfigError(`${spec.env}=${raw}: ${r.error}`);
      initial[k] = r.value;
    } else initial[k] = spec.def;
  }
  const file = path.join(dataDir, 'bot_settings.json');
  const saved = await readJson(file, null);
  const strategyEnv = (env.STRATEGIES ?? 'arbitrage').split(',').map((s) => s.trim()).filter(Boolean);
  for (const s of strategyEnv) if (!STRATEGY_NAMES.includes(s)) throw new ConfigError(`STRATEGIES: unknown strategy "${s.slice(0, 30)}" (valid: ${STRATEGY_NAMES.join(', ')})`);
  let strategies = strategyEnv;
  if (saved?.values && typeof saved.values === 'object') {
    for (const [k, v] of Object.entries(saved.values)) {
      const r = coerceSetting(k, v);
      if (r.ok) initial[k] = r.value;
    }
    if (Array.isArray(saved.strategies)) strategies = saved.strategies.filter((x) => STRATEGY_NAMES.includes(x));
  }
  return { cfg, settings: new SettingsStore(file, initial, strategies) };
}

/** Telegram API base: https only, except loopback (lets the test-suite run a mock Telegram). */
function telegramBase(raw) {
  const v = (raw || 'https://api.telegram.org').replace(/\/+$/, '');
  let u;
  try {
    u = new URL(v);
  } catch {
    throw new ConfigError('TELEGRAM_API_URL must be a valid URL');
  }
  const loop = ['127.0.0.1', 'localhost', '[::1]'].includes(u.hostname);
  if (!loop && u.protocol !== 'https:') throw new ConfigError('TELEGRAM_API_URL must be https');
  if (!loop && u.hostname !== 'api.telegram.org') throw new ConfigError('TELEGRAM_API_URL must be api.telegram.org (or loopback for tests)');
  return v;
}

/** Local Qwen (Ollama / OpenAI-compatible) news-intelligence settings — see docs/QWEN.md. All optional; OFF by default. */
function qwenConfig(env) {
  const enabled = bool('QWEN_ENABLED', env.QWEN_ENABLED, false);
  const url = (env.QWEN_URL || 'http://127.0.0.1:11434').replace(/\/+$/, '');
  let host = '';
  try {
    host = new URL(url).hostname;
  } catch {
    throw new ConfigError('QWEN_URL must be a valid URL');
  }
  const loop = ['127.0.0.1', 'localhost', '[::1]'].includes(host);
  if (enabled && !loop && env.QWEN_ALLOW_REMOTE !== 'yes') {
    throw new ConfigError(`QWEN_URL host "${host}" is not loopback: headlines would leave this machine. Set QWEN_ALLOW_REMOTE=yes to allow it.`);
  }
  const backend = (env.QWEN_BACKEND || 'ollama').toLowerCase();
  if (!['ollama', 'openai'].includes(backend)) throw new ConfigError('QWEN_BACKEND must be ollama or openai');
  return {
    enabled,
    backend,
    url,
    model: env.QWEN_MODEL || 'qwen3:1.7b',
    timeoutMs: num('QWEN_TIMEOUT_MS', env.QWEN_TIMEOUT_MS, 60000, { min: 1000, max: 600000, integer: true }),
    maxPerCycle: num('QWEN_MAX_PER_CYCLE', env.QWEN_MAX_PER_CYCLE, 6, { min: 1, max: 100, integer: true }),
    numCtx: num('QWEN_NUM_CTX', env.QWEN_NUM_CTX, 2048, { min: 512, max: 32768, integer: true }),
    shadow: !bool('QWEN_TRADE', env.QWEN_TRADE, false), // shadow mode (assess + log, never trade) unless QWEN_TRADE=true
    minConfidence: num('QWEN_MIN_CONFIDENCE', env.QWEN_MIN_CONFIDENCE, 0.6, { min: 0, max: 1 }),
    minSources: num('QWEN_MIN_SOURCES', env.QWEN_MIN_SOURCES, 2, { min: 1, max: 10, integer: true }),
  };
}

/* ── Developer support (kept out of docs on purpose) ─────────────────────────
 * Andrew Ivan Bell · CashApp: $tomesingsoc · Coinbase: aibell@live.com
 * ─────────────────────────────────────────────────────────────────────────── */
