/**
 * @file src/logger.js
 * Docs: README.md §"Monitoring and Logging" · docs/DEPLOYMENT_ORACLE.md Step 10 (journald)
 *
 * Reasoning chain
 *  1. Under systemd, stdout/stderr go to journald → no log-rotation code needed in the app.
 *  2. A trading bot handles an RSA private key, a Telegram bot token and an API bearer token;
 *     a leaked log line is a credential leak. So EVERY line passes through redact().
 *  3. Lines are also offered to subscribers (the WebSocket hub) as `bot_output` events.
 */
const LEVELS = { debug: 10, info: 20, warn: 30, error: 40 };

const PATTERNS = [
  [/-----BEGIN [A-Z ]*PRIVATE KEY-----[\s\S]*?-----END [A-Z ]*PRIVATE KEY-----/g, '[REDACTED_PEM]'],
  [/bot\d{6,}:[A-Za-z0-9_-]{20,}/g, 'bot[REDACTED_TOKEN]'],
  [/Bearer\s+[A-Za-z0-9._~+/=-]{8,}/gi, 'Bearer [REDACTED]'],
  [/(KALSHI-ACCESS-(?:SIGNATURE|KEY)["':=\s]+)[A-Za-z0-9+/=_-]{8,}/gi, '$1[REDACTED]'],
];

export function redact(text) {
  let s = String(text);
  for (const [re, rep] of PATTERNS) s = s.replace(re, rep);
  return s;
}

export function createLogger({ level = 'info', json = false, sink = process.stdout } = {}) {
  const min = LEVELS[level] ?? LEVELS.info;
  const listeners = new Set();
  const emit = (lvl, msg, meta) => {
    if (LEVELS[lvl] < min) return;
    let metaStr = '';
    if (meta !== undefined) {
      try {
        metaStr = typeof meta === 'string' ? meta : JSON.stringify(meta, (_k, v) => (v instanceof Error ? v.message : v));
      } catch {
        metaStr = '[unserializable]';
      }
    }
    const ts = new Date().toISOString();
    const line = json
      ? JSON.stringify({ ts, level: lvl, msg: redact(msg), meta: metaStr ? redact(metaStr) : undefined })
      : `${ts} ${lvl.toUpperCase().padEnd(5)} ${redact(msg)}${metaStr ? ` ${redact(metaStr)}` : ''}`;
    sink.write(line + '\n');
    for (const l of listeners) {
      try {
        l(lvl, redact(msg), ts);
      } catch {
        /* listener errors must never break logging */
      }
    }
  };
  return {
    debug: (m, x) => emit('debug', m, x),
    info: (m, x) => emit('info', m, x),
    warn: (m, x) => emit('warn', m, x),
    error: (m, x) => emit('error', m, x),
    subscribe: (fn) => {
      listeners.add(fn);
      return () => listeners.delete(fn);
    },
  };
}
