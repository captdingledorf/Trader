/**
 * @file src/engine/trader.js
 * Docs: README.md §"Architecture → Core Trading Engine" · docs/ARCHITECTURE.md §"The trading cycle"
 *       docs/DEPLOYMENT_ORACLE.md Step 11 (operating the bot)
 *
 * THE CYCLE (chain of thought — order matters)
 *   1. exchange status        public call; proves connectivity, honours exchange/trading halts
 *   2. live: sync cash        exchange balance is the source of truth for cash
 *   3. scan                   open events/markets + quotes for anything we hold; record price history
 *   4. settle                 resolved markets → ledger.settle()
 *   5. mark-to-market         value positions at the BID (what we could sell into)
 *   6. halt check             daily-loss / drawdown breaker (manual /resume required)
 *   7. exits                  stop-loss / trailing / time stop        (only while trading, see EXITS_WHEN_STOPPED)
 *   8. entries                strategies → ranked signals → risk-sized execution
 *   9. persist + emit         atomic ledger write; WebSocket/Telegram events
 *
 * WHY setTimeout CHAINS, NOT setInterval: a slow cycle (API retries) must never overlap the next one
 * — overlapping cycles could double-submit orders.
 *
 * EVENTS (map onto the original WebSocket message types):
 *   status · trade_executed · bot_error · risk_event · opportunity · config_updated(emitted by index.js)
 */
import { EventEmitter } from 'node:events';
import crypto from 'node:crypto';
import { toCents, feePerContract } from '../util/money.js';
import { sizeSingle, exitDecision, haltReason, correlatedWith, eventExposure } from './risk.js';

const SETTLED = new Set(['determined', 'finalized', 'settled']);
export const VERSION = '1.1.0';

export class Trader extends EventEmitter {
  constructor({ cfg, settings, ledger, broker, client, scanner, strategies, relationTickers = () => [], logger, now = () => Date.now() }) {
    super();
    Object.assign(this, { cfg, settings, ledger, broker, client, scanner, strategies, relationTickers, logger, now });
    this.trading = false;
    this.halted = false;
    this.haltText = '';
    this.startedAt = now();
    this.cycleCount = 0;
    this.apiConnected = false;
    this.last = { at: null, ms: 0, scanned: 0, tradable: 0, signals: 0, executed: 0, error: null };
    this.seen = new Map(); // opportunity id → last announced (ms)
    this.reconcile = { at: null, mismatches: 0 };
    this.saveFailures = 0;
    this.signalLog = []; // newest first, for the dashboard
    this.lastDiffKey = '';
    this.timer = null;
    this.busy = false;
    this.stopped = false;
  }

  /* ── lifecycle ───────────────────────────────────────────────── */
  start() {
    if (this.cfg.autostart) this.trading = true;
    this.#schedule(1000);
  }

  #schedule(ms) {
    if (this.stopped) return;
    this.timer = setTimeout(async () => {
      await this.cycle();
      this.#schedule(this.settings.get().tradeInterval * 1000 + Math.random() * 500);
    }, ms);
    // NOT unref'd on purpose: this timer is the application's heartbeat. If it were unref'd and neither the
    // API server nor Telegram polling were active, Node would see an empty event loop and exit(0) silently —
    // and systemd's Restart=on-failure would not bring the bot back. (Found while measuring memory.)
  }

  async stop() {
    this.stopped = true;
    clearTimeout(this.timer);
    for (let i = 0; i < 50 && this.busy; i++) await new Promise((r) => setTimeout(r, 100));
    await this.ledger.save();
  }

  setTrading(on, by = 'system') {
    this.trading = Boolean(on);
    this.logger.info(`trading ${on ? 'ENABLED' : 'DISABLED'} by ${by}`);
    this.emit('status', this.status());
    return this.trading;
  }

  resume(by = 'system') {
    this.halted = false;
    this.haltText = '';
    this.ledger.rebaseline(); // acknowledge current losses; limits count from here
    this.saveFailures = 0;
    this.logger.info(`halt cleared by ${by}; loss/drawdown baselines reset to current equity`);
    this.emit('status', this.status());
  }

  /* ── views (shapes follow the original REST API) ────────────────── */
  #uptime() {
    const s = Math.floor((this.now() - this.startedAt) / 1000);
    return `${Math.floor(s / 3600)}h ${Math.floor((s % 3600) / 60)}m`;
  }

  status() {
    return {
      trading: this.trading,
      halted: this.halted,
      haltReason: this.haltText || null,
      mode: this.cfg.mode,
      kalshiEnv: this.cfg.kalshiEnv,
      lastUpdate: this.last.at,
      uptime: this.#uptime(),
      apiConnected: this.apiConnected,
      activeStrategies: this.settings.enabledStrategies(),
      tradesCount: this.ledger.s.tradeCount,
      openPositions: this.ledger.positionList().length,
      cycle: this.last,
      reconcile: this.reconcile,
      risk: this.#riskView(),
      version: VERSION,
    };
  }

  #riskView() {
    const s = this.settings.get();
    return {
      dailyPnl: this.ledger.dailyPnl(),
      dailyLossLimit: s.maxDailyLoss * s.bankroll,
      drawdown: this.ledger.drawdown(),
      maxDrawdown: s.maxDrawdown,
      openPositions: this.ledger.positionList().length,
      maxOpenPositions: s.maxOpenPositions,
      bankroll: s.bankroll,
    };
  }

  /** Dashboard data (read-only views; the API layer only serialises these). */
  equityView() {
    const c = this.ledger.s.equityCurve;
    return { points: c.slice(-600), start: this.ledger.s.startingCash, peak: this.ledger.s.peakEquity, dayStart: this.ledger.s.dayStart };
  }

  tradesView() {
    return this.ledger.s.closed.slice(-100).reverse();
  }

  signalsView() {
    return this.signalLog.slice(0, 40);
  }

  marketsView() {
    const sc = this.scanner;
    const tradable = [...sc.quotes.values()].filter((m) => sc.isTradable(m));
    const top = [...tradable].sort((a, b) => b.volume24h - a.volume24h).slice(0, 48).map((m) => ({ ticker: m.ticker, title: m.title, mid: m.mid, spread: m.spread, volume24h: m.volume24h }));
    const byEvent = new Map();
    for (const m of tradable) {
      if (!sc.events.get(m.eventTicker)?.mutuallyExclusive || m.yesBid === null) continue;
      const e = byEvent.get(m.eventTicker) ?? { eventTicker: m.eventTicker, title: sc.events.get(m.eventTicker).title, n: 0, sumYesBid: 0 };
      e.n += 1;
      e.sumYesBid += m.yesBid;
      byEvent.set(m.eventTicker, e);
    }
    const events = [...byEvent.values()].filter((e) => e.n >= 2).map((e) => ({ ...e, overround: e.sumYesBid - 1 })).sort((a, b) => b.overround - a.overround).slice(0, 12);
    return { scannedAt: this.last.at, count: sc.quotes.size, tradable: tradable.length, top, events };
  }

  balanceView() {
    const eq = this.ledger.equity();
    const cost = this.ledger.positionList().reduce((s, p) => s + p.qty * p.avgCost, 0);
    const value = eq - this.ledger.cash;
    return {
      available: this.ledger.cash,
      totalEquity: eq,
      unrealizedPnL: value - cost,
      todayPnL: this.ledger.dailyPnl(),
      mode: this.cfg.mode,
      timestamp: new Date(this.now()).toISOString(),
    };
  }

  positionsView() {
    return this.ledger.positionList().map((p) => ({
      eventName: p.title,
      eventId: p.eventTicker,
      ticker: p.ticker,
      side: p.side,
      quantity: p.qty,
      entryPrice: p.avgCost,
      currentPrice: p.lastBid ?? null,
      pnl: p.qty * ((p.lastBid ?? 0) - p.avgCost),
      timestamp: new Date(p.openedAt).toISOString(),
    }));
  }

  performanceView() {
    return this.ledger.performance();
  }

  /* ── the cycle ───────────────────────────────────────────────── */
  async cycle() {
    if (this.busy || this.stopped) return;
    this.busy = true;
    const t0 = this.now();
    const stat = { at: new Date(t0).toISOString(), ms: 0, scanned: 0, tradable: 0, signals: 0, executed: 0, error: null };
    try {
      const s = this.settings.get();
      let exch;
      try {
        exch = await this.client.getExchangeStatus();
        this.apiConnected = true;
      } catch (e) {
        this.apiConnected = false;
        throw e;
      }
      const tradingActive = exch?.trading_active !== false && exch?.exchange_active !== false;

      if (this.broker.kind === 'kalshi') {
        this.ledger.reconcileCash((await this.client.getBalance()).cash);
        if (this.cycleCount % (this.cfg.reconcileEvery ?? 3) === 0) {
          // A reconciliation hiccup must never block stop-losses or the rest of the cycle.
          await this.#reconcilePositions().catch((e) => this.logger.warn(`position reconciliation skipped: ${e.message}`));
        }
      }

      const held = this.ledger.positionList().map((p) => p.ticker);
      const scan = await this.scanner.scan({ extraTickers: held, priorityTickers: this.relationTickers() });
      stat.scanned = scan.quotes.size;
      stat.tradable = scan.markets.length;

      await this.#settleResolved(scan.quotes);
      this.ledger.markToMarket(scan.quotes);
      this.ledger.tick();

      const reason = haltReason(this.ledger, s);
      if (reason && !this.halted) {
        this.halted = true;
        this.haltText = reason;
        this.logger.warn(`TRADING HALTED: ${reason}`);
        this.emit('risk_event', { kind: 'halt', reason });
      }

      if (tradingActive && (this.trading || this.cfg.exitsWhenStopped)) await this.#runExits(scan.quotes, s);
      if (this.trading && !this.halted && tradingActive) await this.#runEntries(scan, s, stat);
      if (!tradingActive) this.logger.warn('exchange reports trading inactive; skipping orders this cycle');
      await this.#observe(scan, s);

      this.ledger.tick();
      await this.#persist();
      if (this.scanner.scans % 5 === 0) await this.scanner.save().catch((e) => this.logger.warn(`price history not saved: ${e.message}`));
    } catch (e) {
      stat.error = e.message;
      this.logger.error(`cycle failed: ${e.message}`);
      this.emit('bot_error', { message: e.message });
    } finally {
      stat.ms = this.now() - t0;
      this.last = stat;
      this.cycleCount += 1;
      this.busy = false;
      this.emit('status', this.status());
    }
  }

  /**
   * Compare the exchange's net positions (+YES / −NO) with the bot ledger. Differences mean either a
   * position opened outside the bot, or an order whose response was lost. We ALERT (deduplicated), we
   * never "fix" automatically: guessing which side is right with real money is worse than asking a human.
   */
  async #reconcilePositions() {
    const ex = new Map((await this.client.getPositions()).map((p) => [p.ticker, p.position]));
    const local = new Map();
    for (const p of this.ledger.positionList()) local.set(p.ticker, (local.get(p.ticker) ?? 0) + (p.side === 'yes' ? p.qty : -p.qty));
    const diffs = [];
    for (const t of new Set([...ex.keys(), ...local.keys()])) {
      const a = ex.get(t) ?? 0;
      const b = local.get(t) ?? 0;
      if (Math.abs(a - b) > 1e-6) diffs.push({ ticker: t, exchange: a, ledger: b });
    }
    this.reconcile = { at: new Date(this.now()).toISOString(), mismatches: diffs.length };
    const key = JSON.stringify(diffs);
    if (diffs.length && key !== this.lastDiffKey) {
      this.lastDiffKey = key;
      const sample = diffs.slice(0, 5).map((d) => `${d.ticker} exchange ${d.exchange} vs bot ${d.ledger}`).join('; ');
      this.emit('risk_event', { kind: 'position_mismatch', reason: `${diffs.length} ticker(s) differ between Kalshi and the bot ledger (${sample}). Positions opened outside the bot, or a lost order response — review manually.` });
    }
    if (!diffs.length) this.lastDiffKey = '';
  }

  /** Trading without being able to persist state is how positions get forgotten after a crash: halt after 3 failures. */
  async #persist() {
    try {
      await this.ledger.save();
      this.saveFailures = 0;
    } catch (e) {
      this.saveFailures += 1;
      this.logger.error(`state save failed (${this.saveFailures}): ${e.message}`);
      if (this.saveFailures >= 3 && !this.halted) {
        this.halted = true;
        this.haltText = `cannot persist state (${e.message})`;
        this.emit('risk_event', { kind: 'halt', reason: this.haltText });
      }
    }
  }

  async #settleResolved(quotes) {
    const done = new Set();
    for (const p of this.ledger.positionList()) {
      if (done.has(p.ticker)) continue;
      const q = quotes.get(p.ticker);
      if (!q || !SETTLED.has(q.status)) continue;
      if (q.result && !['yes', 'no'].includes(q.result)) {
        // e.g. a scalar/void result: we cannot value it, so tell a human once instead of silently carrying a ghost position
        if (!this.seen.has(`res:${p.ticker}`)) {
          this.seen.set(`res:${p.ticker}`, this.now());
          this.emit('risk_event', { kind: 'unsettleable', reason: `${p.ticker} settled with result "${q.result}", which the ledger cannot value. Check Kalshi and fix the position manually.` });
        }
        continue;
      }
      if (!['yes', 'no'].includes(q.result)) continue; // determined but result not published yet
      done.add(p.ticker);
      const pnl = await this.ledger.settle(p.ticker, q.result);
      this.logger.info(`settled ${p.ticker} → ${q.result} (P&L ${pnl.toFixed(2)})`);
      this.emit('trade_executed', { type: 'settled', ticker: p.ticker, result: q.result, pnl });
    }
  }

  async #runExits(quotes, s) {
    for (const p of this.ledger.positionList()) {
      const q = quotes.get(p.ticker);
      if (!q) continue;
      const bid = p.side === 'yes' ? q.yesBid : q.noBid;
      const d = exitDecision(p, bid, s, this.now(), this.cfg.timeStopHours);
      if (d) await this.#sell(p, q, bid, d.reason);
    }
  }

  async #sell(p, q, bid, reason) {
    const order = { ticker: p.ticker, side: p.side, action: 'sell', count: p.qty, limitPrice: toCents(Math.max(0.01, bid - 0.03)), clientOrderId: crypto.randomUUID() };
    const r = await this.#submit(order, q);
    if (!r.ok) {
      this.logger.warn(`exit order for ${p.ticker} not filled (${r.note ?? r.status})`);
      return false;
    }
    const res = await this.ledger.applySell({ ticker: p.ticker, side: p.side, qty: r.filled, price: r.avgPrice, fee: r.fee, reason, orderId: r.orderId });
    this.logger.info(`EXIT ${p.side.toUpperCase()} ${p.ticker} x${r.filled} @ ${r.avgPrice.toFixed(2)} (${reason}) P&L ${res?.realized?.toFixed(2)}`);
    this.emit('trade_executed', { type: 'exit', reason, ticker: p.ticker, side: p.side, quantity: r.filled, price: r.avgPrice, pnl: res?.realized, event: p.title });
    return true;
  }

  /** Close every open position at market (used by Telegram /close_all). */
  async closeAll(reason = 'manual_close_all') {
    // Same mutex as the cycle: a manual close racing a stop-loss exit could sell the same position twice.
    while (this.busy) await new Promise((r) => setTimeout(r, 50));
    this.busy = true;
    try {
      const quotes = this.scanner.quotes;
      let n = 0;
      for (const p of this.ledger.positionList()) {
        const q = quotes.get(p.ticker);
        const bid = q ? (p.side === 'yes' ? q.yesBid : q.noBid) : null;
        if (bid !== null && bid !== undefined && (await this.#sell(p, q, bid, reason))) n += 1;
      }
      await this.ledger.save();
      return n;
    } finally {
      this.busy = false;
    }
  }

  /** Every order goes through here: a broker exception must never abort a cycle half-way or hide an order. */
  async #submit(order, quote) {
    try {
      const r = await this.broker.submit(order, quote);
      if (!r.ok && r.status === 'unknown') {
        this.emit('risk_event', { kind: 'order_unknown', reason: `Order ${order.clientOrderId} (${order.action} ${order.side} ${order.ticker}) was sent but its outcome is unknown: ${r.note ?? ''}. Check Kalshi; the next reconciliation will show any difference.` });
      }
      return r;
    } catch (e) {
      this.logger.error(`broker threw on ${order.action} ${order.side} ${order.ticker}: ${e.message}`);
      this.emit('risk_event', { kind: 'order_error', reason: `Order for ${order.ticker} threw (${e.message}). It may or may not have reached Kalshi — the next reconciliation will show any difference.` });
      return { ok: false, filled: 0, status: 'error', note: e.message };
    }
  }

  #capital(s) {
    return Math.max(0, Math.min(s.bankroll, this.ledger.equity()));
  }

  async #runEntries(scan, s, stat) {
    const ctx = { markets: scan.markets, quotes: scan.quotes, events: scan.events, history: this.scanner.history, settings: s, cfg: this.cfg };
    const signals = [];
    for (const strat of this.strategies) {
      if (!this.settings.isEnabled(strat.name)) continue;
      try {
        signals.push(...(await strat.analyze(ctx)));
      } catch (e) {
        this.logger.warn(`strategy ${strat.name} failed: ${e.message}`);
      }
    }
    stat.signals = signals.length;
    signals.sort((a, b) => b.edge * b.confidence - a.edge * a.confidence);
    const alertOnly = this.broker.kind === 'kalshi' && !this.cfg.arbitrageAutoExec;
    const fresh = [];
    for (const sig of signals) {
      let outcome = 'not tried';
      if (stat.executed < this.cfg.maxNewTradesPerCycle && !this.halted) {
        const ok = sig.kind === 'basket' ? await this.#execBasket(sig, ctx) : await this.#execSingle(sig, ctx);
        if (ok) stat.executed += 1;
        outcome = ok ? 'executed' : sig.kind === 'basket' && alertOnly ? 'alert' : 'skipped';
      }
      if (fresh.length < 20) fresh.push({ t: this.now(), id: sig.id, strategy: sig.strategy, kind: sig.kind, riskless: sig.riskless, edge: sig.edge, confidence: sig.confidence, reason: sig.reason, legs: sig.legs.map((l) => ({ side: l.side, ticker: l.ticker, price: l.price })), outcome });
    }
    this.signalLog = [...fresh, ...this.signalLog].slice(0, 60);
  }

  /** Strategies that are NOT trading but want to observe (e.g. Qwen shadow mode). Never blocks, never trades. */
  async #observe(scan, s) {
    const ctx = { markets: scan.markets, quotes: scan.quotes, events: scan.events, history: this.scanner.history, settings: s, cfg: this.cfg };
    for (const strat of this.strategies) {
      if (typeof strat.observe !== 'function' || this.settings.isEnabled(strat.name)) continue;
      try {
        await strat.observe(ctx);
      } catch (e) {
        this.logger.debug(`observer ${strat.name} failed: ${e.message}`);
      }
    }
  }

  async #execSingle(sig, ctx) {
    const s = ctx.settings;
    const l = sig.legs[0];
    const q = ctx.quotes.get(l.ticker);
    const px = q ? (l.side === 'yes' ? q.yesAsk : q.noAsk) : null;
    if (px === null || px === undefined) return false;
    if (this.ledger.hasTicker(l.ticker)) return false;
    const open = this.ledger.positionList();
    if (open.length >= s.maxOpenPositions) return false;
    const corr = correlatedWith(l.ticker, this.scanner.history, open.map((p) => p.ticker), s.correlationLimit);
    if (corr) {
      this.logger.debug(`skip ${l.ticker}: correlated ${corr.corr.toFixed(2)} with ${corr.ticker}`);
      return false;
    }
    const capital = this.#capital(s);
    if (eventExposure(open, l.eventTicker) >= capital * s.maxPositionSize * 2) return false;
    const sz = sizeSingle({ fairProb: sig.fairProb, price: px, capital, cash: this.ledger.cash, settings: s, feeCoeff: this.cfg.feeCoeff });
    if (sz.count < 1) {
      this.logger.debug(`skip ${l.ticker}: ${sz.reason}`);
      return false;
    }
    const order = { ticker: l.ticker, side: l.side, action: 'buy', count: sz.count, limitPrice: toCents(px + 0.01), clientOrderId: crypto.randomUUID() };
    const r = await this.#submit(order, q);
    if (!r.ok) {
      this.logger.info(`entry not filled ${l.ticker}: ${r.note ?? r.status}`);
      return false;
    }
    await this.ledger.applyBuy({ ticker: l.ticker, eventTicker: l.eventTicker, title: l.title, side: l.side, qty: r.filled, price: r.avgPrice, fee: r.fee, strategy: sig.strategy, orderId: r.orderId });
    this.logger.info(`ENTRY ${sig.strategy} ${l.side.toUpperCase()} ${l.ticker} x${r.filled} @ ${r.avgPrice.toFixed(2)} — ${sig.reason}`);
    this.emit('trade_executed', { type: 'entry', strategy: sig.strategy, ticker: l.ticker, side: l.side, quantity: r.filled, price: r.avgPrice, event: l.title, reason: sig.reason });
    return true;
  }

  async #depth(leg) {
    try {
      const ob = await this.client.getOrderbook(leg.ticker, 1);
      // Buying YES hits NO bids' complement and vice versa: size at our ask = size of the opposite best bid.
      return (leg.side === 'yes' ? ob.noBids[0]?.size : ob.yesBids[0]?.size) ?? 0;
    } catch {
      return this.broker.kind === 'paper' ? this.cfg.paper.assumedDepth : 0; // live: unknown depth ⇒ do not trade
    }
  }

  #announce(sig) {
    const last = this.seen.get(sig.id) ?? 0;
    if (this.now() - last < 30 * 60 * 1000) return;
    this.seen.set(sig.id, this.now());
    this.emit('opportunity', sig);
    this.logger.info(`OPPORTUNITY (not executed) ${sig.id}: ${sig.reason}`);
  }

  async #execBasket(sig, ctx) {
    const s = ctx.settings;
    if (this.broker.kind === 'kalshi' && !this.cfg.arbitrageAutoExec) {
      this.#announce(sig);
      return false;
    }
    if (this.ledger.positionList().length + sig.legs.length > s.maxOpenPositions) return false;
    if (sig.legs.some((l) => this.ledger.hasTicker(l.ticker))) return false;
    const legs = [];
    for (const l of sig.legs) {
      const q = ctx.quotes.get(l.ticker);
      const px = q ? (l.side === 'yes' ? q.yesAsk : q.noAsk) : null;
      if (px === null || px === undefined) return false;
      legs.push({ ...l, q, px });
    }
    const feeSum = legs.reduce((a, l) => a + feePerContract(l.px, 10, this.cfg.feeCoeff), 0);
    const costPerSet = legs.reduce((a, l) => a + l.px, 0) + feeSum;
    if (sig.payoutFloor !== null && sig.payoutFloor - costPerSet < s.statArbitrageThreshold / 2) return false; // edge vanished since scan

    for (const l of legs) l.depth = await this.#depth(l);
    const depth = Math.min(...legs.map((l) => l.depth));
    const budget = Math.min(this.#capital(s) * s.maxPositionSize * (sig.riskless ? 2 : 1), this.ledger.cash);
    const sets = Math.min(Math.floor(budget / costPerSet), s.maxOrderContracts, Math.floor(depth));
    if (sets < 1) return false;

    legs.sort((a, b) => a.depth - b.depth); // thinnest leg first: if it fails we have nothing to unwind
    const filledLegs = [];
    for (const l of legs) {
      const order = { ticker: l.ticker, side: l.side, action: 'buy', count: sets, limitPrice: toCents(l.px + 0.01), clientOrderId: crypto.randomUUID(), depthHint: l.depth };
      const r = await this.#submit(order, l.q);
      if (!r.ok || r.filled < sets) {
        const detail = `leg ${l.side.toUpperCase()} ${l.ticker}: filled ${r.filled ?? 0}/${sets} (${r.note ?? r.status})`;
        if (r.ok) await this.#recordLeg(l, r, sig);
        this.logger.error(`PARTIAL BASKET ${sig.id}: ${detail}`);
        this.emit('risk_event', { kind: 'partial_basket', reason: `${sig.id} ${detail}. ${filledLegs.length + (r.ok ? 1 : 0)}/${legs.length} legs held; stop-loss protection is ACTIVE on them — review manually.` });
        return filledLegs.length > 0;
      }
      await this.#recordLeg(l, r, sig);
      filledLegs.push(l.ticker);
    }
    // basket complete: now (and only now) a riskless basket's legs are held to settlement, exempt from stop-loss
    for (const l of legs) {
      const pos = this.ledger.getPosition(l.ticker, l.side);
      if (pos) pos.hold = sig.riskless;
    }
    this.logger.info(`BASKET ${sig.id} x${sets} sets — ${sig.reason}`);
    this.emit('trade_executed', { type: 'basket', strategy: sig.strategy, id: sig.id, sets, legs: legs.map((l) => `${l.side.toUpperCase()} ${l.ticker}`), reason: sig.reason });
    return true;
  }

  #recordLeg(l, r, sig) {
    return this.ledger.applyBuy({ ticker: l.ticker, eventTicker: l.eventTicker, title: l.title, side: l.side, qty: r.filled, price: r.avgPrice, fee: r.fee, strategy: `${sig.strategy}:${sig.id}`, orderId: r.orderId, hold: false });
  }
}

/* ── Developer support (kept out of docs on purpose) ─────────────────────────
 * Andrew Ivan Bell · CashApp: $tomesingsoc · Coinbase: aibell@live.com
 * ─────────────────────────────────────────────────────────────────────────── */
