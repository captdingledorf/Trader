/**
 * @file src/engine/broker.js
 * Docs: README.md §"Usage" (paper vs live) · docs/DEPLOYMENT_ORACLE.md Step 8 (demo smoke test)
 *
 * TWO BROKERS, ONE INTERFACE (tree of thought)
 *   submit(order, quote) → { ok, filled, avgPrice, fee, orderId, status, note }
 *     order = { ticker, side:'yes'|'no', action:'buy'|'sell', count, limitPrice, clientOrderId }
 *   PaperBroker  – never touches the network. Fills marketable limits at the quoted ask/bid plus a
 *                  pessimistic slippage. OPTIMISTIC about depth and latency → paper P&L is an upper
 *                  bound on live P&L (AUDIT F-02).
 *   KalshiBroker – sends IOC (immediate-or-cancel) limit orders to demo or prod, then reconciles
 *                  the actual fill from the order/fills endpoints.
 *
 * WHY IOC TAKER ORDERS? The bot's signals are "act now at the visible price or not at all"; a resting
 * order would need cancel/amend/queue logic that multiplies failure modes.
 *
 * ORDER FIELD STYLE (verify on demo!)  KALSHI_ORDER_FIELD_STYLE = fixed | legacy | both
 *   fixed  → count_fp:"10.00", yes_price_dollars:"0.6500"   (post-migration fields; default)
 *   legacy → count:10, yes_price:65                          (cents; being removed by Kalshi)
 *   both   → both sets (Kalshi requires them to match)
 */
import { fp, dollars, toCents, toCountString, toDollarString, takerFee } from '../util/money.js';

export class PaperBroker {
  constructor({ slippage = 0.01, feeCoeff = 0.07, assumedDepth = 20 } = {}) {
    this.slippage = slippage;
    this.feeCoeff = feeCoeff;
    this.assumedDepth = assumedDepth;
    this.kind = 'paper';
  }

  async submit(order, quote) {
    const { side, action, count, limitPrice } = order;
    const book = side === 'yes' ? { ask: quote?.yesAsk, bid: quote?.yesBid } : { ask: quote?.noAsk, bid: quote?.noBid };
    const touch = action === 'buy' ? book.ask : book.bid;
    if (touch === null || touch === undefined) return { ok: false, filled: 0, note: 'no quote', status: 'rejected' };
    const px = action === 'buy' ? Math.min(0.99, touch + this.slippage) : Math.max(0.01, touch - this.slippage);
    const fillPx = toCents(px);
    const crosses = action === 'buy' ? fillPx <= limitPrice + 1e-9 : fillPx >= limitPrice - 1e-9;
    if (!crosses) return { ok: false, filled: 0, note: `limit ${limitPrice} does not cross ${fillPx}`, status: 'canceled' };
    const filled = Math.min(count, order.depthHint ?? count); // depthHint comes from the order book when known
    const fee = takerFee(filled, fillPx, this.feeCoeff);
    return { ok: filled > 0, filled, avgPrice: fillPx, fee, orderId: `paper-${order.clientOrderId}`, status: 'executed' };
  }
}

export class KalshiBroker {
  constructor({ client, feeCoeff = 0.07, fieldStyle = 'fixed', logger = null }) {
    this.client = client;
    this.feeCoeff = feeCoeff;
    this.fieldStyle = fieldStyle;
    this.logger = logger;
    this.kind = 'kalshi';
  }

  /** Build the POST /portfolio/orders body. Exported via static for unit tests. */
  buildBody(order) {
    // Whole-cent prices are valid on every Kalshi price grid (docs: 'Fixed-Point Representation → Price Level Structures'),
    // but a limit of exactly $0.00 or $1.00 is not a tradable price: clamp into [0.01, 0.99].
    const price = Math.min(0.99, Math.max(0.01, toCents(order.limitPrice)));
    const body = {
      ticker: order.ticker,
      action: order.action,
      side: order.side,
      type: 'limit',
      time_in_force: 'immediate_or_cancel',
      client_order_id: order.clientOrderId,
    };
    const priceKey = order.side === 'yes' ? 'yes_price' : 'no_price';
    if (this.fieldStyle === 'fixed' || this.fieldStyle === 'both') {
      body.count_fp = toCountString(order.count);
      body[`${priceKey}_dollars`] = toDollarString(price);
    }
    if (this.fieldStyle === 'legacy' || this.fieldStyle === 'both') {
      body.count = Math.round(order.count);
      body[priceKey] = Math.round(price * 100);
    }
    return body;
  }

  async submit(order) {
    const body = this.buildBody(order);
    let res;
    try {
      res = await this.client.createOrder(body);
    } catch (e) {
      // 409 = duplicate client_order_id → our previous attempt may have landed; reconcile instead of failing.
      if (e.status === 409) return this.#reconcileByClientId(order);
      return { ok: false, filled: 0, status: 'error', note: e.message };
    }
    try {
      return await this.#settle(res, order);
    } catch (e) {
      // The POST succeeded but we could not read the answer: the order may be live. Say so; reconciliation will confirm.
      this.logger?.error?.(`order ${order.clientOrderId} sent but response unreadable: ${e.message}`);
      return { ok: false, filled: 0, status: 'unknown', note: `order sent; response unreadable (${e.message})` };
    }
  }

  async #settle(res, order) {
    let o = res.order ?? res;
    // A 2xx answer without an order object is NOT "no fill": the order may be live. Surface it as unknown.
    if (!o || typeof o !== 'object' || (o.order_id === undefined && o.status === undefined)) throw new Error('response contained no order object');
    let filled = this.#filled(o);
    // IOC orders finish immediately, but the create response may omit fill info → ask the exchange.
    if (filled === null && o.order_id) {
      try {
        o = await this.client.getOrder(o.order_id);
        filled = this.#filled(o);
      } catch (e) {
        this.logger?.warn?.(`could not re-read order ${o.order_id}: ${e.message}`);
      }
    }
    if (filled === null) filled = o.status === 'executed' ? order.count : 0;
    const status = o.status ?? 'unknown';
    if (!(filled > 0)) return { ok: false, filled: 0, orderId: o.order_id, status, note: 'no fill' };
    const cost = dollars(o, 'taker_fill_cost');
    const fees = dollars(o, 'taker_fees');
    const avgPrice = cost !== null && filled > 0 ? cost / filled : order.limitPrice; // limit = conservative bound
    return {
      ok: true,
      filled,
      avgPrice,
      fee: fees ?? takerFee(filled, avgPrice, this.feeCoeff),
      orderId: o.order_id,
      status,
      note: cost === null ? 'avg price = limit (exchange did not report fill cost)' : undefined,
    };
  }

  #filled(o) {
    const f = fp(o, 'fill_count');
    if (f !== null) return f;
    const remaining = fp(o, 'remaining_count');
    const initial = fp(o, 'initial_count');
    if (remaining !== null && initial !== null) return initial - remaining;
    return null;
  }

  async #reconcileByClientId(order) {
    try {
      const r = await this.client.getOrders({ ticker: order.ticker, limit: 50 });
      const o = (r.orders ?? []).find((x) => x.client_order_id === order.clientOrderId);
      if (!o) return { ok: false, filled: 0, status: 'unknown', note: 'duplicate client_order_id but order not found' };
      const filled = this.#filled(o) ?? 0;
      return { ok: filled > 0, filled, avgPrice: order.limitPrice, fee: takerFee(filled, order.limitPrice, this.feeCoeff), orderId: o.order_id, status: o.status, note: 'reconciled after 409' };
    } catch (e) {
      return { ok: false, filled: 0, status: 'unknown', note: `reconcile failed: ${e.message}` };
    }
  }
}

