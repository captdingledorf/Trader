/**
 * @file src/engine/risk.js
 * Docs: README.md §"Risk Management" · docs/ARCHITECTURE.md §"Risk layers" · docs/AUDIT.md F-05
 *
 * LAYERS (outermost first) — each is independent so one bug cannot disable all protection
 *   L0 mode gate        paper by default; real money needs an explicit env acknowledgement (config.js)
 *   L1 halt conditions  daily-loss and drawdown breakers stop NEW entries (haltReason)
 *   L2 portfolio caps   max open positions, per-event concentration, correlation limit
 *   L3 position sizing  fractional Kelly net of fees, capped by maxPositionSize and maxOrderContracts
 *   L4 exits            fixed stop-loss, trailing stop, optional time stop
 *
 * KELLY FOR A BINARY CONTRACT (chain of thought)
 *   Buy 1 YES at effective cost c (= price + fee) paying $1 if true with probability p.
 *   Net odds b = (1-c)/c ; Kelly f* = (p*b - (1-p))/b = (p - c)/(1 - c).
 *   The README's generic form (win_amount/loss_amount) is the same maths: kellyGeneric().
 *   Full Kelly is notoriously aggressive when p is ESTIMATED (estimation error → over-betting),
 *   so we scale by kellyScale (default 0.25) — see docs/THESIS.md §3.2.
 */
import { feePerContract } from '../util/money.js';
import { pearson } from '../util/stats.js';

/** README-parity generic Kelly: winAmount/lossAmount are payoffs per unit staked. Returns fraction ≥ 0. */
export function kellyGeneric(winProb, winAmount, lossAmount) {
  if (!(winProb > 0 && winProb < 1)) return 0;
  const b = winAmount / Math.abs(lossAmount);
  if (!(b > 0)) return 0;
  return Math.max(0, (winProb * b - (1 - winProb)) / b);
}

export function kellyBinary(p, cost) {
  if (!(cost > 0 && cost < 1) || !(p > 0 && p < 1)) return 0;
  return Math.max(0, (p - cost) / (1 - cost));
}

/** Size a single-leg buy. Returns {count, stake, edge, kelly, reason?}. */
export function sizeSingle({ fairProb, price, capital, cash, settings, existingCost = 0, feeCoeff = 0.07 }) {
  const fee1 = feePerContract(price, 10, feeCoeff);
  const cost = price + fee1;
  const edge = fairProb - cost;
  if (edge < settings.minEdge) return { count: 0, edge, reason: `net edge ${edge.toFixed(3)} below minEdge ${settings.minEdge}` };
  const kelly = kellyBinary(fairProb, cost) * settings.kellyScale;
  const cap = capital * settings.maxPositionSize - existingCost;
  const stake = Math.min(kelly * capital, cap, cash);
  const count = Math.min(Math.floor(stake / cost), settings.maxOrderContracts);
  if (count < 1) return { count: 0, edge, kelly, reason: 'stake smaller than one contract' };
  return { count, stake: count * cost, edge, kelly };
}

/** Exit rules for a discretionary position. `bid` is the price we could sell into right now. */
export function exitDecision(pos, bid, settings, nowMs, timeStopHours = 0) {
  if (pos.hold || bid === null || bid === undefined) return null;
  const pnlPct = (bid - pos.avgCost) / pos.avgCost;
  if (pnlPct <= -settings.stopLoss) return { reason: 'stop_loss', pnlPct };
  const armAt = pos.avgCost * (1 + 2 * settings.stopLoss); // trail only after a 2×stop gain
  if ((pos.peakBid ?? 0) >= armAt && bid <= pos.peakBid * (1 - settings.stopLoss)) return { reason: 'trailing_stop', pnlPct };
  if (timeStopHours > 0 && nowMs - pos.openedAt >= timeStopHours * 3600 * 1000) return { reason: 'time_stop', pnlPct };
  return null;
}

/** Returns a human-readable reason if NEW entries must be blocked, else null. */
export function haltReason(ledger, settings) {
  const dayLoss = -ledger.dailyPnl();
  if (dayLoss >= settings.maxDailyLoss * settings.bankroll) {
    return `daily loss $${dayLoss.toFixed(2)} ≥ ${(settings.maxDailyLoss * 100).toFixed(2)}% of bankroll`;
  }
  const dd = ledger.drawdown();
  if (dd >= settings.maxDrawdown) return `drawdown ${(dd * 100).toFixed(2)}% ≥ ${(settings.maxDrawdown * 100).toFixed(2)}%`;
  return null;
}

const diffs = (a) => a.slice(1).map((x, i) => x - a[i]);

/** First open position whose price CHANGES correlate above `limit` with `ticker` (levels would give spurious ρ). */
export function correlatedWith(ticker, history, openTickers, limit, window = 60) {
  const h = history.get(ticker);
  if (!h || h.length < 20) return null;
  for (const t of openTickers) {
    if (t === ticker) continue;
    const o = history.get(t);
    if (!o || o.length < 20) continue;
    const c = pearson(diffs(h.slice(-window)), diffs(o.slice(-window)));
    if (c !== null && Math.abs(c) > limit) return { ticker: t, corr: c };
  }
  return null;
}

/** Cost already deployed in the same event (cap = 2× the per-position cap). */
export function eventExposure(positions, eventTicker) {
  return positions.filter((p) => p.eventTicker && p.eventTicker === eventTicker).reduce((s, p) => s + p.qty * p.avgCost, 0);
}
