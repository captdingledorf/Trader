/**
 * @file src/engine/ledger.js
 * Docs: README.md §"API Documentation" (/balance /positions /performance) · docs/ARCHITECTURE.md §"Ledger"
 *
 * ACCOUNTING MODEL (chain of thought)
 *  1. The bot keeps its OWN ledger of what it traded, in both paper and live modes, so strategy
 *     logic is identical in both and works even if Kalshi's portfolio endpoint is down.
 *  2. Cost basis per contract INCLUDES entry fees:  avgCost = (qty0*avg0 + qty*price + fee) / (qty0+qty)
 *  3. Realized P&L on a sell = qty*price − fee − qty*avgCost. On settlement = payout − qty*avgCost
 *     where payout is $1 per winning contract.
 *  4. Unrealized value uses the BID we could actually sell into (conservative), never the mid.
 *  5. Equity = cash + Σ qty × bid. Daily P&L compares to the first equity seen each UTC day.
 *  6. In live mode `reconcileCash()` overwrites local cash with the exchange balance (truth).
 *
 * Persisted to DATA_DIR/state.json atomically; fills append to DATA_DIR/trades.jsonl.
 */
import path from 'node:path';
import { writeJsonAtomic, readJson, appendJsonl } from '../util/atomic.js';
import { mean, std } from '../util/stats.js';

const keyOf = (ticker, side) => `${ticker}|${side}`;
const dayOf = (ms) => new Date(ms).toISOString().slice(0, 10);

export class Ledger {
  /** `name` separates state per mode (paper / live-demo / live-prod) so a mode switch can never mix books. */
  constructor({ dataDir, startingCash, name = 'paper', logger = null, now = () => Date.now() }) {
    this.file = path.join(dataDir, `state.${name}.json`);
    this.tradesFile = path.join(dataDir, `trades.${name}.jsonl`);
    this.logger = logger;
    this.now = now;
    this.s = {
      cash: startingCash,
      startingCash,
      positions: {},
      closed: [],
      equityCurve: [],
      dayStart: null,
      peakEquity: startingCash,
      realizedPnl: 0,
      feesPaid: 0,
      tradeCount: 0,
    };
  }

  async load() {
    const saved = await readJson(this.file, null, this.logger);
    this.fresh = !saved; // true on first run: live mode uses this to seed starting cash from the exchange
    if (saved) this.s = { ...this.s, ...saved };
    return this;
  }

  save() {
    return writeJsonAtomic(this.file, this.s);
  }

  get cash() {
    return this.s.cash;
  }

  positionList() {
    return Object.values(this.s.positions);
  }

  getPosition(ticker, side) {
    return this.s.positions[keyOf(ticker, side)] ?? null;
  }

  hasTicker(ticker) {
    return this.positionList().some((p) => p.ticker === ticker);
  }

  reconcileCash(exchangeCash) {
    if (Number.isFinite(exchangeCash)) this.s.cash = exchangeCash;
  }

  async #log(rec) {
    try {
      await appendJsonl(this.tradesFile, rec);
    } catch (e) {
      this.logger?.warn?.(`trade log write failed: ${e.message}`);
    }
  }

  /** `hold:true` marks legs of a riskless basket: they are held to settlement and never stop-lossed. */
  async applyBuy({ ticker, eventTicker, title, side, qty, price, fee = 0, strategy = '', orderId = '', hold = false }) {
    const t = this.now();
    const k = keyOf(ticker, side);
    const p = this.s.positions[k] ?? { ticker, eventTicker, title, side, qty: 0, avgCost: 0, openedAt: t, peakBid: price, strategy, lastBid: price, hold };
    const total = p.qty * p.avgCost + qty * price + fee;
    p.qty += qty;
    p.avgCost = total / p.qty;
    p.peakBid = Math.max(p.peakBid ?? price, price);
    this.s.positions[k] = p;
    this.s.cash -= qty * price + fee;
    this.s.feesPaid += fee;
    this.s.tradeCount += 1;
    await this.#log({ t, type: 'buy', ticker, side, qty, price, fee, strategy, orderId });
    return p;
  }

  async applySell({ ticker, side, qty, price, fee = 0, reason = 'sell', orderId = '' }) {
    const t = this.now();
    const k = keyOf(ticker, side);
    const p = this.s.positions[k];
    if (!p) return null;
    const q = Math.min(qty, p.qty);
    const proceeds = q * price - fee;
    const realized = proceeds - q * p.avgCost;
    this.s.cash += proceeds;
    this.s.realizedPnl += realized;
    this.s.feesPaid += fee;
    this.s.tradeCount += 1;
    this.#closeRecord(p, q, price, realized, fee, reason, t);
    p.qty -= q;
    if (p.qty <= 1e-9) delete this.s.positions[k];
    await this.#log({ t, type: 'sell', ticker, side, qty: q, price, fee, reason, realized, orderId });
    return { realized, remaining: p.qty };
  }

  /** Settle every position on `ticker` given the market result ('yes' | 'no'). */
  async settle(ticker, result) {
    const t = this.now();
    let total = 0;
    for (const p of this.positionList().filter((x) => x.ticker === ticker)) {
      const payout = p.qty * (p.side === result ? 1 : 0);
      const realized = payout - p.qty * p.avgCost;
      this.s.cash += payout;
      this.s.realizedPnl += realized;
      this.#closeRecord(p, p.qty, p.side === result ? 1 : 0, realized, 0, `settled:${result}`, t);
      delete this.s.positions[keyOf(p.ticker, p.side)];
      total += realized;
      await this.#log({ t, type: 'settle', ticker, side: p.side, qty: p.qty, result, realized });
    }
    return total;
  }

  #closeRecord(p, qty, exit, pnl, fee, reason, t) {
    this.s.closed.push({ ticker: p.ticker, side: p.side, qty, entry: p.avgCost, exit, pnl, fee, openedAt: p.openedAt, closedAt: t, reason, strategy: p.strategy });
    if (this.s.closed.length > 2000) this.s.closed.splice(0, this.s.closed.length - 2000);
  }

  /** Update marks from normalized quotes keyed by ticker; returns {value, unrealized}. */
  markToMarket(quotes) {
    let value = 0;
    let cost = 0;
    for (const p of this.positionList()) {
      const q = quotes instanceof Map ? quotes.get(p.ticker) : quotes[p.ticker];
      const bid = q ? (p.side === 'yes' ? q.yesBid : q.noBid) : null;
      if (bid !== null && bid !== undefined) {
        p.lastBid = bid;
        p.peakBid = Math.max(p.peakBid ?? bid, bid);
      }
      value += p.qty * (p.lastBid ?? 0);
      cost += p.qty * p.avgCost;
    }
    return { value, unrealized: value - cost };
  }

  equity() {
    return this.s.cash + this.positionList().reduce((s, p) => s + p.qty * (p.lastBid ?? 0), 0);
  }

  /** Call once per cycle: tracks day-start equity, peak equity, and a thinned equity curve. */
  tick() {
    const t = this.now();
    const eq = this.equity();
    const today = dayOf(t);
    if (!this.s.dayStart || this.s.dayStart.date !== today) this.s.dayStart = { date: today, equity: eq };
    this.s.peakEquity = Math.max(this.s.peakEquity ?? eq, eq);
    const last = this.s.equityCurve[this.s.equityCurve.length - 1];
    if (!last || t - last.t >= 10 * 60 * 1000) {
      this.s.equityCurve.push({ t, equity: eq });
      if (this.s.equityCurve.length > 5000) this.s.equityCurve.splice(0, this.s.equityCurve.length - 5000);
    }
    return eq;
  }

  /** Human-acknowledged restart point (/resume): today's loss and the drawdown high-water mark restart from NOW,
   *  otherwise the same breaker would re-halt on the very next cycle and the operator could never resume. */
  rebaseline() {
    const t = this.now();
    const eq = this.equity();
    this.s.dayStart = { date: dayOf(t), equity: eq };
    this.s.peakEquity = eq;
  }

  dailyPnl() {
    return this.s.dayStart ? this.equity() - this.s.dayStart.equity : 0;
  }

  drawdown() {
    const peak = this.s.peakEquity || this.equity();
    return peak > 0 ? Math.max(0, (peak - this.equity()) / peak) : 0;
  }

  /** README /performance shape: totalReturn, sharpeRatio, maxDrawdown, winRate, totalTrades, avgTrade, bestTrade, worstTrade. */
  performance() {
    const closed = this.s.closed;
    const pnls = closed.map((c) => c.pnl);
    const wins = pnls.filter((x) => x > 0).length;
    // daily equity series for Sharpe + max drawdown
    const byDay = new Map();
    for (const pt of this.s.equityCurve) byDay.set(dayOf(pt.t), pt.equity);
    const daily = [...byDay.values()];
    const rets = [];
    for (let i = 1; i < daily.length; i++) if (daily[i - 1] > 0) rets.push(daily[i] / daily[i - 1] - 1);
    const sharpe = rets.length >= 5 && std(rets) > 0 ? (mean(rets) / std(rets)) * Math.sqrt(365) : null;
    let peak = -Infinity;
    let mdd = 0;
    for (const pt of this.s.equityCurve) {
      peak = Math.max(peak, pt.equity);
      if (peak > 0) mdd = Math.max(mdd, (peak - pt.equity) / peak);
    }
    return {
      totalReturn: this.s.startingCash > 0 ? ((this.equity() - this.s.startingCash) / this.s.startingCash) * 100 : 0,
      sharpeRatio: sharpe,
      maxDrawdown: mdd * 100,
      winRate: closed.length ? (wins / closed.length) * 100 : 0,
      totalTrades: closed.length,
      avgTrade: pnls.length ? mean(pnls) : 0,
      bestTrade: pnls.length ? Math.max(...pnls) : 0,
      worstTrade: pnls.length ? Math.min(...pnls) : 0,
      timestamp: new Date(this.now()).toISOString(),
    };
  }
}
