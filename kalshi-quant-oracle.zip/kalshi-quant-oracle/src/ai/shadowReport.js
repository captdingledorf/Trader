/**
 * @file src/ai/shadowReport.js
 * Docs: docs/QWEN.md §"Evaluate before you trust" · docs/THESIS.md §8 item 3 · docs/AUDIT.md F-21
 *
 * THE FALSIFIABLE TEST. Shadow mode logs, for every (market, headline) pair, the market mid AT THE TIME, the lexicon score and
 * Qwen's assessment. Once those markets resolve we can ask the only question that matters:
 *
 *      Would adjusting the market price by the model's view have scored better than the market price itself?
 *
 * Proper scoring (Brier 1950; Gneiting & Raftery 2007) of three probabilities per assessment, against the 0/1 outcome:
 *      p0 = mid                                       (the market — the thing you must beat)
 *      p1 = mid + 0.10 · stance · confidence · relevance      (what the Qwen strategy would act on; same ±10-point bound)
 *      p2 = mid + 0.10 · lexiconTone                           (the baseline scorer)
 * Assessments of one market share one outcome, so the confidence interval is a CLUSTER bootstrap over markets, not over rows.
 * A negative ΔBrier = better than the market. This is necessary for profitability, NOT sufficient (fees, spreads, execution).
 */
import { clamp } from '../util/money.js';

const mean = (a) => (a.length ? a.reduce((s, x) => s + x, 0) / a.length : 0);

function rng(seed) {
  let s = seed >>> 0;
  return () => {
    s = (s * 1664525 + 1013904223) >>> 0;
    return s / 2 ** 32;
  };
}

/** Cluster bootstrap CI of the mean of `field` over items grouped by ticker. */
function clusterCi(groups, field, boots, rand) {
  const keys = [...groups.keys()];
  const means = [];
  for (let b = 0; b < boots; b++) {
    let sum = 0;
    let cnt = 0;
    for (let i = 0; i < keys.length; i++) {
      const g = groups.get(keys[Math.floor(rand() * keys.length)]);
      for (const it of g) { sum += it[field]; cnt += 1; }
    }
    means.push(sum / cnt);
  }
  means.sort((a, b) => a - b);
  return [means[Math.floor(boots * 0.025)], means[Math.floor(boots * 0.975)]];
}

/**
 * @param rows     parsed qwen_assessments.jsonl lines
 * @param outcomes Map<ticker, 0|1> for RESOLVED markets
 */
export function shadowReport(rows, outcomes, { minRelevance = 0.5, boots = 1000, seed = 1 } = {}) {
  const items = [];
  for (const r of rows) {
    const y = outcomes.get(r.ticker);
    if (y === undefined || !r.qwen || !(r.qwen.relevance >= minRelevance) || !Number.isFinite(r.mid)) continue;
    const p0 = clamp(r.mid, 0.01, 0.99);
    const p1 = clamp(r.mid + 0.1 * r.qwen.stance * r.qwen.confidence * r.qwen.relevance, 0.01, 0.99);
    const p2 = clamp(r.mid + 0.1 * (r.lexicon ?? 0), 0.01, 0.99);
    items.push({ ticker: r.ticker, y, b0: (p0 - y) ** 2, b1: (p1 - y) ** 2, b2: (p2 - y) ** 2, d1: (p1 - y) ** 2 - (p0 - y) ** 2, d2: (p2 - y) ** 2 - (p0 - y) ** 2, stance: r.qwen.stance, mid: r.mid });
  }
  const groups = new Map();
  for (const it of items) (groups.get(it.ticker) ?? groups.set(it.ticker, []).get(it.ticker)).push(it);
  const markets = groups.size;
  const rand = rng(seed);
  const dir = items.filter((i) => Math.abs(i.stance) >= 0.3 && i.y !== i.mid);
  const hits = dir.filter((i) => Math.sign(i.stance) === Math.sign(i.y - i.mid)).length;
  const ci1 = markets >= 2 ? clusterCi(groups, 'd1', boots, rand) : [NaN, NaN];
  const ci2 = markets >= 2 ? clusterCi(groups, 'd2', boots, rand) : [NaN, NaN];
  let verdict;
  if (markets < 30) verdict = `INSUFFICIENT DATA: ${markets} resolved markets (need ≥ 30 to say anything, ≥ 200 to be convincing).`;
  else if (ci1[1] < 0) verdict = 'Qwen-adjusted probabilities scored better than the market price (95% cluster-bootstrap CI excludes 0). Necessary, NOT sufficient: fees, spreads and execution still have to be beaten.';
  else verdict = 'NO EVIDENCE that the Qwen adjustment beats the market price. Do not enable QWEN_TRADE.';
  return {
    assessments: items.length,
    resolvedMarkets: markets,
    brier: { market: +mean(items.map((i) => i.b0)).toFixed(5), qwenAdjusted: +mean(items.map((i) => i.b1)).toFixed(5), lexiconAdjusted: +mean(items.map((i) => i.b2)).toFixed(5) },
    deltaBrierQwen: { mean: +mean(items.map((i) => i.d1)).toFixed(5), ci95: ci1.map((x) => +x.toFixed(5)) },
    deltaBrierLexicon: { mean: +mean(items.map((i) => i.d2)).toFixed(5), ci95: ci2.map((x) => +x.toFixed(5)) },
    directional: { n: dir.length, hitRate: dir.length ? +(hits / dir.length).toFixed(3) : null },
    verdict,
  };
}
