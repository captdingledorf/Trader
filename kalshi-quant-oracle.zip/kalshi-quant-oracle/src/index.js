#!/usr/bin/env node
/**
 * @file src/index.js
 * Docs: README.md §"Usage" · docs/DEPLOYMENT_ORACLE.md Steps 6–8 (configure, verify, run)
 *
 * PROCESS MODEL (chain of thought)
 *   The original ran THREE processes (Python engine, Node bot interface, Node Telegram bot) glued
 *   together with supervisor/WebSockets. On a 1 GB Always Free VM that is wasteful and adds IPC
 *   failure modes. This port is ONE Node 24 process with clearly separated modules:
 *     config → kalshi client → scanner → strategies → trader(ledger, broker) → { telegram, api }
 *   systemd restarts it on failure; state lives in DATA_DIR and is written atomically.
 *
 * START-UP SAFETY (tree of thought)
 *   paper (default) ─────────────► never sends orders
 *   live + demo ─────────────────► orders to Kalshi's demo exchange
 *   live + prod ──► blocked unless I_UNDERSTAND_LIVE_TRADING_RISK=yes (config.js)
 *   After ANY start, trading is OFF until /start_trading (or AUTOSTART_TRADING=true).
 *
 *   node src/index.js            run the bot
 *   node src/index.js --check    validate configuration and exit (used in deployment Step 8)
 */
import { loadDotEnv, loadConfig, ConfigError } from './config.js';
import { createLogger } from './logger.js';
import { KalshiClient } from './kalshi/client.js';
import { readPrivateKeyPem } from './kalshi/auth.js';
import { MarketScanner } from './data/scanner.js';
import { NewsFeed } from './data/news.js';
import { Ledger } from './engine/ledger.js';
import { PaperBroker, KalshiBroker } from './engine/broker.js';
import { Trader, VERSION } from './engine/trader.js';
import { ArbitrageStrategy, loadRelations } from './strategies/arbitrage.js';
import { VolatilityStrategy } from './strategies/volatility.js';
import { SentimentStrategy } from './strategies/sentiment.js';
import { TelegramBot, formatEvent } from './telegram/bot.js';
import { createApiServer } from './api/server.js';
import { QwenProvider } from './ai/qwen.js';

async function main() {
  loadDotEnv(process.env.ENV_FILE ?? '.env');
  const checkOnly = process.argv.includes('--check');

  let loaded;
  try {
    loaded = await loadConfig();
  } catch (e) {
    if (e instanceof ConfigError) {
      console.error(`CONFIG ERROR: ${e.message}`);
      process.exit(2);
    }
    throw e;
  }
  const { cfg, settings } = loaded;
  const logger = createLogger({ level: cfg.logLevel, json: cfg.logJson });

  let pem = null;
  try {
    pem = readPrivateKeyPem();
  } catch (e) {
    console.error(`CONFIG ERROR: cannot read Kalshi private key: ${e.message}`);
    process.exit(2);
  }
  let client;
  try {
    client = new KalshiClient({ baseUrl: cfg.baseUrl, keyId: cfg.keyId, privateKeyPem: pem, logger, readRps: cfg.readRps, writeRps: cfg.writeRps, maxResponseBytes: cfg.maxResponseBytes });
  } catch (e) {
    console.error(`CONFIG ERROR: Kalshi private key is not a valid RSA/Ed25519 PEM (${e.message})`);
    process.exit(2);
  }
  if (cfg.live && !client.canSign) {
    console.error('CONFIG ERROR: TRADING_MODE=live needs KALSHI_API_KEY_ID and a private key (see .env.example)');
    process.exit(2);
  }

  const banner =
    cfg.mode === 'paper'
      ? 'PAPER MODE — no orders are ever sent to Kalshi'
      : cfg.kalshiEnv === 'demo'
        ? 'LIVE MODE on Kalshi DEMO — orders go to the demo exchange'
        : '*** REAL MONEY: LIVE MODE on Kalshi PRODUCTION ***';
  logger.info(`kalshi-quant-telebot-node v${VERSION} · node ${process.version} · ${banner}`);
  logger.info(`api base ${cfg.baseUrl} · key type ${client.signer?.keyType ?? 'none (public data only)'} · strategies ${settings.enabledStrategies().join(',') || 'none'}`);
  if (checkOnly) {
    logger.info(`config OK · telegram ${cfg.telegram.token ? (cfg.telegram.chatIds.length ? 'enabled' : 'setup-mode') : 'disabled'} · api ${cfg.api.token ? `${cfg.api.host}:${cfg.api.port}` : 'disabled (no API_TOKEN)'}`);
    return;
  }

  const name = cfg.mode === 'paper' ? 'paper' : `live-${cfg.kalshiEnv}`;
  const ledger = await new Ledger({ dataDir: cfg.dataDir, startingCash: settings.get().bankroll, name, logger }).load();
  const broker = cfg.live ? new KalshiBroker({ client, feeCoeff: cfg.feeCoeff, fieldStyle: cfg.orderFieldStyle, logger }) : new PaperBroker({ slippage: cfg.paper.slippage, feeCoeff: cfg.feeCoeff, assumedDepth: cfg.paper.assumedDepth });
  if (cfg.live && ledger.fresh) {
    const b = await client.getBalance(); // seed starting cash from the real balance on first run
    Object.assign(ledger.s, { cash: b.cash, startingCash: b.cash, peakEquity: b.cash });
    logger.info(`seeded live ledger from exchange balance $${b.cash.toFixed(2)}`);
  }

  const scanner = await new MarketScanner({ client, cfg, logger }).load();
  const relations = loadRelations(cfg.relationsFile, logger);
  const qwen = cfg.qwen.enabled ? new QwenProvider({ cfg: cfg.qwen, dataDir: cfg.dataDir, logger }) : null;
  if (qwen) {
    const h = await qwen.health();
    if (!h.ok) logger.warn(`Qwen enabled but ${cfg.qwen.url} is not reachable (${h.error}) — lexicon fallback until it is (docs/QWEN.md)`);
    else if (!h.modelPresent) logger.warn(`Qwen server is up but model "${cfg.qwen.model}" is not installed (found: ${h.models.join(', ') || 'none'})`);
    else logger.info(`Qwen ready: ${cfg.qwen.model} via ${cfg.qwen.backend} — ${cfg.qwen.shadow ? 'SHADOW mode (assess + log, never trades)' : 'TRADE mode'}`);
  }
  const strategies = [new ArbitrageStrategy({ relations, feeCoeff: cfg.feeCoeff, logger }), new VolatilityStrategy(), new SentimentStrategy({ news: new NewsFeed({ feeds: cfg.newsFeeds, logger }), qwen, logger })];
  const relationTickers = () => [...relations.implications.flatMap((r) => [r.if, r.then]), ...relations.pairs.flat()];

  const trader = new Trader({ cfg, settings, ledger, broker, client, scanner, strategies, relationTickers, logger });

  /* Telegram ----------------------------------------------------- */
  let bot = null;
  if (cfg.telegram.token) {
    bot = new TelegramBot({ token: cfg.telegram.token, allowedIds: cfg.telegram.chatIds, trader, settings, cfg, logger });
    try {
      await bot.start();
      const lastErr = new Map();
      for (const type of ['trade_executed', 'risk_event', 'opportunity']) trader.on(type, (e) => bot.notify(formatEvent(type, e)));
      trader.on('bot_error', (e) => {
        const last = lastErr.get(e.message) ?? 0;
        if (Date.now() - last > 10 * 60 * 1000) {
          lastErr.set(e.message, Date.now());
          bot.notify(formatEvent('bot_error', e));
        }
      });
      bot.notify(`🔌 <b>Bot started</b> v${VERSION}\n${cfg.mode}/${cfg.kalshiEnv} · trading is OFF until /start_trading`);
    } catch (e) {
      logger.error(`telegram failed to start: ${e.message} — continuing WITHOUT the Telegram control plane`);
      bot = null;
    }
  } else logger.warn('TELEGRAM_BOT_TOKEN not set: no Telegram control plane (use the REST API or set the token)');

  /* REST + WebSocket --------------------------------------------- */
  let api = null;
  if (cfg.api.token) {
    api = createApiServer({ cfg, trader, settings, logger, qwen });
    const addr = await api.listen();
    logger.info(`API listening on ${addr.address}:${addr.port} (bearer token required)`);
  } else logger.warn('API_TOKEN not set: REST/WebSocket API disabled');

  trader.start();
  logger.info(cfg.autostart ? 'AUTOSTART_TRADING=true: trading is ON' : 'trading is OFF — send /start_trading in Telegram (or POST /api/start-trading)');

  /* Shutdown ----------------------------------------------------- */
  let closing = false;
  const shutdown = async (sig) => {
    if (closing) return;
    closing = true;
    logger.info(`${sig} received: shutting down (open positions are NOT touched)`);
    setTimeout(() => process.exit(1), 10000).unref();
    bot?.stop();
    client.abortAll(); // cancel pending reads so the in-flight cycle ends fast (POSTs finish)
    await trader.stop().catch(() => {});
    await scanner.save().catch(() => {});
    await api?.close().catch(() => {});
    process.exit(0);
  };
  process.on('SIGINT', () => shutdown('SIGINT'));
  process.on('SIGTERM', () => shutdown('SIGTERM'));
  process.on('unhandledRejection', (r) => logger.error(`unhandledRejection: ${r?.message ?? r}`));
  process.on('uncaughtException', async (e) => {
    logger.error(`uncaughtException: ${e.stack ?? e}`);
    await ledger.save().catch(() => {});
    process.exit(1); // systemd Restart=on-failure brings us back with trading OFF
  });
}

main().catch((e) => {
  console.error(`FATAL: ${e.stack ?? e}`);
  process.exit(1);
});

/* ── Developer support (kept out of docs on purpose) ─────────────────────────
 * Andrew Ivan Bell · CashApp: $tomesingsoc · Coinbase: aibell@live.com
 * ─────────────────────────────────────────────────────────────────────────── */
