/**
 * @file src/kalshi/client.js
 * Docs: README.md §"Kalshi API compatibility" · docs/ARCHITECTURE.md §"Exchange adapter"
 *
 * DESIGN (chain of thought)
 *  1. Public market-data endpoints need no signature; portfolio/order endpoints do (`auth:true`).
 *  2. Only the PATH (e.g. /trade-api/v2/portfolio/balance) is signed — never the query string.
 *  3. GET/DELETE are retried (429/5xx/network) with exponential backoff + jitter, honouring Retry-After.
 *     POST /portfolio/orders is NEVER blindly retried: a lost response could double-fill. The engine
 *     instead reconciles by `client_order_id` (idempotency key, 409 on duplicates).
 *  4. Every response is passed through a NORMALISER that prefers the new `*_dollars` / `*_fp` fields
 *     and falls back to legacy cents/ints (see src/util/money.js).
 *
 * UNVERIFIED-FROM-SANDBOX NOTICE: the build sandbox has no outbound network, so this file was tested
 * against recorded-shape mocks only. Run `npm run smoke:demo` against Kalshi's DEMO environment
 * before trusting it (docs/DEPLOYMENT_ORACLE.md Step 8).
 */
import { TokenBucket, sleep } from '../util/ratelimit.js';
import { createSigner } from './auth.js';
import { dollars, fp } from '../util/money.js';
import { readTextCapped } from '../util/http.js';

export class KalshiApiError extends Error {
  constructor(status, body, method, path) {
    super(`Kalshi ${method} ${path} → HTTP ${status}${body?.error?.message ? `: ${body.error.message}` : body?.message ? `: ${body.message}` : ''}`);
    this.status = status;
    this.body = body;
  }
}

/** Convert a raw market object into the engine's canonical shape (prices in dollars, counts as numbers). */
export function normalizeMarket(m) {
  const px = (base) => {
    const v = dollars(m, base);
    return v !== null && v > 0 && v < 1 ? v : null;
  };
  let yesBid = px('yes_bid');
  let yesAsk = px('yes_ask');
  let noBid = px('no_bid');
  let noAsk = px('no_ask');
  // Binary book complementarity: buying YES at ask == selling NO at (1-ask), etc.
  if (yesAsk === null && noBid !== null) yesAsk = +(1 - noBid).toFixed(4);
  if (noAsk === null && yesBid !== null) noAsk = +(1 - yesBid).toFixed(4);
  if (yesBid === null && noAsk !== null) yesBid = +(1 - noAsk).toFixed(4);
  if (noBid === null && yesAsk !== null) noBid = +(1 - yesAsk).toFixed(4);
  const last = px('last_price');
  const mid = yesBid !== null && yesAsk !== null ? (yesBid + yesAsk) / 2 : last;
  return {
    ticker: m.ticker,
    eventTicker: m.event_ticker ?? null,
    title: m.title ?? m.yes_sub_title ?? m.ticker,
    subtitle: m.yes_sub_title ?? m.subtitle ?? '',
    status: m.status ?? '',
    result: m.result ?? '',
    closeTime: m.close_time ?? m.expiration_time ?? null,
    yesBid,
    yesAsk,
    noBid,
    noAsk,
    last,
    mid,
    spread: yesBid !== null && yesAsk !== null ? yesAsk - yesBid : null,
    volume: fp(m, 'volume') ?? 0,
    volume24h: fp(m, 'volume_24h') ?? 0,
    openInterest: fp(m, 'open_interest') ?? 0,
  };
}

/** Parse an order book into sorted bid ladders. Kalshi lists only BIDS for YES and NO. */
export function normalizeOrderbook(raw) {
  const ob = raw?.orderbook_fp ?? raw?.orderbook ?? {};
  const ladder = (dollarsArr, centsArr) => {
    const src = dollarsArr ?? centsArr ?? [];
    const isDollars = Boolean(dollarsArr);
    return src
      .map(([p, q]) => ({ price: isDollars ? Number(p) : Number(p) / 100, size: Number(q) }))
      .filter((l) => Number.isFinite(l.price) && Number.isFinite(l.size))
      .sort((a, b) => b.price - a.price);
  };
  return { yesBids: ladder(ob.yes_dollars, ob.yes), noBids: ladder(ob.no_dollars, ob.no) };
}

export class KalshiClient {
  constructor({ baseUrl, keyId = '', privateKeyPem = null, logger = null, readRps = 8, writeRps = 4, timeoutMs = 10000, maxResponseBytes = 25 * 1024 * 1024, fetchImpl = globalThis.fetch, nowMs = () => Date.now() }) {
    this.baseUrl = baseUrl.replace(/\/+$/, '');
    this.basePath = new URL(this.baseUrl).pathname.replace(/\/+$/, ''); // e.g. /trade-api/v2
    this.keyId = keyId;
    this.signer = privateKeyPem ? createSigner(privateKeyPem) : null;
    this.logger = logger;
    this.reads = new TokenBucket(readRps);
    this.writes = new TokenBucket(writeRps);
    this.timeoutMs = timeoutMs;
    this.maxBytes = maxResponseBytes; // a response bigger than this is an error, not an OOM
    this.fetch = fetchImpl;
    this.nowMs = nowMs;
    this.ctl = new AbortController(); // shutdown switch for READ requests only
  }

  /** Graceful shutdown: cancel in-flight/queued reads and suppress retries. POSTs are left to finish so
   *  a submitted order is always recorded in the ledger (otherwise exchange and ledger would diverge). */
  abortAll() {
    this.ctl.abort();
  }

  get canSign() {
    return Boolean(this.keyId && this.signer);
  }

  async #request(method, path, { query, body, auth = false, retries = method === 'POST' ? 0 : 3 } = {}) {
    if (auth && !this.canSign) throw new Error(`${method} ${path} needs Kalshi credentials (KALSHI_API_KEY_ID + private key)`);
    const qs = query ? new URLSearchParams(Object.entries(query).filter(([, v]) => v !== undefined && v !== null && v !== '').map(([k, v]) => [k, String(v)])).toString() : '';
    const url = `${this.baseUrl}${path}${qs ? `?${qs}` : ''}`;
    for (let attempt = 0; ; attempt++) {
      if (method !== 'POST' && this.ctl.signal.aborted) throw new Error('Kalshi client is shutting down');
      await (method === 'GET' ? this.reads : this.writes).take();
      const headers = { Accept: 'application/json' };
      if (body !== undefined) headers['Content-Type'] = 'application/json';
      if (auth) {
        const ts = String(this.nowMs());
        headers['KALSHI-ACCESS-KEY'] = this.keyId;
        headers['KALSHI-ACCESS-TIMESTAMP'] = ts;
        headers['KALSHI-ACCESS-SIGNATURE'] = this.signer.sign(ts, method, `${this.basePath}${path}`);
      }
      let res;
      try {
        res = await this.fetch(url, { method, headers, body: body !== undefined ? JSON.stringify(body) : undefined, signal: method === 'POST' ? AbortSignal.timeout(this.timeoutMs) : AbortSignal.any([AbortSignal.timeout(this.timeoutMs), this.ctl.signal]) });
      } catch (e) {
        if (attempt < retries && !this.ctl.signal.aborted) {
          await sleep(500 * 2 ** attempt + Math.random() * 250);
          continue;
        }
        throw new Error(`Kalshi ${method} ${path} network error: ${e.message}`);
      }
      let json = null;
      const { text, truncated } = await readTextCapped(res, this.maxBytes);
      if (truncated) throw new Error(`Kalshi ${method} ${path} response exceeded ${Math.round(this.maxBytes / 1048576)} MB — lower SCAN_PAGE_LIMIT/SCAN_MAX_PAGES`);
      if (text) {
        try {
          json = JSON.parse(text);
        } catch {
          json = { message: text.slice(0, 200) };
        }
      }
      if (res.ok) return json ?? {};
      if ((res.status === 429 || res.status >= 500) && attempt < retries && !this.ctl.signal.aborted) {
        const ra = Number(res.headers?.get?.('retry-after'));
        await sleep(Number.isFinite(ra) && ra > 0 ? Math.min(ra, 10) * 1000 : 500 * 2 ** attempt + Math.random() * 250);
        continue;
      }
      throw new KalshiApiError(res.status, json, method, path);
    }
  }

  /* ── public market data ─────────────────────────────────────────── */
  getExchangeStatus() {
    return this.#request('GET', '/exchange/status');
  }

  /** One page of events with nested markets. */
  getEvents({ status = 'open', limit = 100, cursor } = {}) {
    return this.#request('GET', '/events', { query: { status, limit, cursor, with_nested_markets: true } });
  }

  async getMarket(ticker) {
    const r = await this.#request('GET', `/markets/${encodeURIComponent(ticker)}`);
    return normalizeMarket(r.market ?? r);
  }

  getMarkets(query = {}) {
    return this.#request('GET', '/markets', { query });
  }

  async getOrderbook(ticker, depth = 5) {
    return normalizeOrderbook(await this.#request('GET', `/markets/${encodeURIComponent(ticker)}/orderbook`, { query: { depth } }));
  }

  /* ── portfolio (signed) ─────────────────────────────────────────── */
  async getBalance() {
    const r = await this.#request('GET', '/portfolio/balance', { auth: true });
    const cash = dollars(r, 'balance');
    const pv = dollars(r, 'portfolio_value');
    return { cash: cash ?? 0, portfolioValue: pv, raw: r };
  }

  async getPositions() {
    const r = await this.#request('GET', '/portfolio/positions', { auth: true, query: { limit: 200 } });
    return (r.market_positions ?? []).map((p) => ({
      ticker: p.ticker,
      position: fp(p, 'position') ?? 0, // + = YES contracts, - = NO contracts
      exposure: dollars(p, 'market_exposure') ?? 0,
      realizedPnl: dollars(p, 'realized_pnl') ?? 0,
    }));
  }

  getOrders(query = {}) {
    return this.#request('GET', '/portfolio/orders', { auth: true, query });
  }

  async getOrder(orderId) {
    const r = await this.#request('GET', `/portfolio/orders/${encodeURIComponent(orderId)}`, { auth: true });
    return r.order ?? r;
  }

  createOrder(body) {
    return this.#request('POST', '/portfolio/orders', { auth: true, body });
  }

  cancelOrder(orderId) {
    return this.#request('DELETE', `/portfolio/orders/${encodeURIComponent(orderId)}`, { auth: true });
  }

  getFills(query = {}) {
    return this.#request('GET', '/portfolio/fills', { auth: true, query });
  }
}

/** Pull all normalized markets (+ event metadata) from up to `maxPages` pages of /events. */
export async function scanEvents(client, { maxPages = 3, limit = 100 } = {}) {
  const markets = [];
  const events = new Map();
  let cursor;
  for (let page = 0; page < maxPages; page++) {
    const r = await client.getEvents({ cursor, limit });
    for (const ev of r.events ?? []) {
      events.set(ev.event_ticker, { eventTicker: ev.event_ticker, title: ev.title ?? ev.event_ticker, mutuallyExclusive: ev.mutually_exclusive === true, category: ev.category ?? '' });
      for (const m of ev.markets ?? []) markets.push(normalizeMarket({ event_ticker: ev.event_ticker, ...m }));
    }
    cursor = r.cursor;
    if (!cursor) break;
  }
  return { markets, events };
}


/* ── Developer support (kept out of docs on purpose) ─────────────────────────
 * Andrew Ivan Bell · CashApp: $tomesingsoc · Coinbase: aibell@live.com
 * ─────────────────────────────────────────────────────────────────────────── */
