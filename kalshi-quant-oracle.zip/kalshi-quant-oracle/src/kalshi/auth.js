/**
 * @file src/kalshi/auth.js
 * Docs: README.md §"Obtaining API Keys" · docs/DEPLOYMENT_ORACLE.md Step 6 (private key handling)
 *
 * WHAT THE ORIGINAL README GOT WRONG (and why we changed it)
 *  The original README tells users to send `Authorization: Bearer <API_KEY>`. Kalshi's current
 *  Trade API v2 uses SIGNED requests instead (docs.kalshi.com → "API Keys" / "Quick Start:
 *  Authenticated Requests"):
 *    KALSHI-ACCESS-KEY        the key id
 *    KALSHI-ACCESS-TIMESTAMP  epoch milliseconds
 *    KALSHI-ACCESS-SIGNATURE  base64( sign( timestamp + METHOD + path-without-query ) )
 *  Algorithms: RSA-PSS / SHA-256 / MGF1-SHA-256 / salt = digest length for RSA keys, or Ed25519
 *  for Ed25519 keys (the web app's default key type as of late 2026). We support BOTH and detect
 *  the type from the PEM, so users can paste whichever key Kalshi issued.
 *
 * KEY SOURCES, in priority order (tree of thought)
 *   1) $CREDENTIALS_DIRECTORY/kalshi_key  — systemd LoadCredential (best: root-owned file, never in env)
 *   2) KALSHI_PRIVATE_KEY_PATH            — path to a PEM file
 *   3) KALSHI_PRIVATE_KEY_BASE64          — whole PEM, base64 (handy for CI)
 *   4) KALSHI_PRIVATE_KEY                 — inline PEM with literal \n
 */
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';

export function readPrivateKeyPem(env = process.env) {
  const credDir = env.CREDENTIALS_DIRECTORY;
  if (credDir) {
    const f = path.join(credDir, 'kalshi_key');
    if (fs.existsSync(f)) return fs.readFileSync(f, 'utf8');
  }
  if (env.KALSHI_PRIVATE_KEY_PATH) return fs.readFileSync(env.KALSHI_PRIVATE_KEY_PATH, 'utf8');
  if (env.KALSHI_PRIVATE_KEY_BASE64) return Buffer.from(env.KALSHI_PRIVATE_KEY_BASE64, 'base64').toString('utf8');
  if (env.KALSHI_PRIVATE_KEY) return env.KALSHI_PRIVATE_KEY.replace(/\\n/g, '\n');
  return null;
}

/** Build a signer {keyType, sign(timestampMs, method, pathNoQuery) → base64}. */
export function createSigner(pem) {
  const key = crypto.createPrivateKey(pem);
  const keyType = key.asymmetricKeyType; // 'rsa' | 'rsa-pss' | 'ed25519' | ...
  if (!['rsa', 'rsa-pss', 'ed25519'].includes(keyType)) throw new Error(`unsupported Kalshi key type: ${keyType}`);
  return {
    keyType,
    sign(timestampMs, method, pathNoQuery) {
      const msg = Buffer.from(`${timestampMs}${method.toUpperCase()}${pathNoQuery}`, 'utf8');
      const sig =
        keyType === 'ed25519'
          ? crypto.sign(null, msg, key)
          : crypto.sign('sha256', msg, {
              key,
              padding: crypto.constants.RSA_PKCS1_PSS_PADDING,
              saltLength: crypto.constants.RSA_PSS_SALTLEN_DIGEST,
            });
      return sig.toString('base64');
    },
  };
}

/** Verify helper used by tests (and the smoke script) to prove signer/verifier agreement. */
export function verifySignature(publicKeyPem, keyType, signatureB64, timestampMs, method, pathNoQuery) {
  const msg = Buffer.from(`${timestampMs}${method.toUpperCase()}${pathNoQuery}`, 'utf8');
  const sig = Buffer.from(signatureB64, 'base64');
  return keyType === 'ed25519'
    ? crypto.verify(null, msg, publicKeyPem, sig)
    : crypto.verify('sha256', msg, { key: publicKeyPem, padding: crypto.constants.RSA_PKCS1_PSS_PADDING, saltLength: crypto.constants.RSA_PSS_SALTLEN_DIGEST }, sig);
}
