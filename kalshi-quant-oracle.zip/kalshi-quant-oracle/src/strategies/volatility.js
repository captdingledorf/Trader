/**
 * @file src/strategies/volatility.js
 * Docs: README.md §"Volatility-Based Strategy" · docs/PORT_MAP.md §"Interpretations" · docs/AUDIT.md F-10
 *
 * RULE (chain of thought)
 *  1. Prices live in (0,1), so raw price differences have state-dependent variance. We model
 *     LOGIT returns r_t = logit(m_t) − logit(m_{t−1}), which are unbounded and closer to homoskedastic.
 *  2. Fit GARCH(1,1) (src/util/stats.js). ratio = sqrt(forecastVar / longRunVar):
 *       ratio ≥ 1  → volatility is at/above its long-run level (the README's "high-volatility period").
 *  3. In that regime fade overshoots: if |m − EMA20| ≥ volatilityThreshold (probability units),
 *     assume partial reversion  fair = m − 0.5·(m − EMA).
 *  4. Direction: m above EMA → buy NO ; below → buy YES. Edge/fees/size are enforced by the trader.
 *
 * HONESTY NOTE: this is a heuristic. There is no evidence in this repository (or the original) that
 * it earns money after fees; it ships DISABLED unless enabled via STRATEGIES or /strategy.
 */
import { ema, garch11, logit } from '../util/stats.js';

const MIN_SAMPLES = 40;

export class VolatilityStrategy {
  name = 'volatility';

  async analyze({ markets, history, settings }) {
    const out = [];
    const candidates = [...markets].sort((a, b) => b.volume24h - a.volume24h).slice(0, 100);
    for (const m of candidates) {
      const h = history.get(m.ticker);
      if (!h || h.length < MIN_SAMPLES) continue;
      const clipped = h.map((x) => Math.min(0.97, Math.max(0.03, x)));
      const rets = [];
      for (let i = 1; i < clipped.length; i++) rets.push(logit(clipped[i]) - logit(clipped[i - 1]));
      const g = garch11(rets);
      if (!g) continue;
      const ratio = Math.sqrt(g.forecastVar / g.longRunVar);
      if (ratio < 1) continue;
      const e = ema(clipped, 20);
      const dev = m.mid - e;
      if (Math.abs(dev) < settings.volatilityThreshold) continue;
      const fairYes = m.mid - 0.5 * dev;
      const sigmaP = Math.sqrt(g.forecastVar) * m.mid * (1 - m.mid); // delta method: logit-σ → probability-σ
      const side = dev > 0 ? 'no' : 'yes';
      const price = side === 'yes' ? m.yesAsk : m.noAsk;
      if (price === null) continue;
      out.push({
        id: `vol:${m.ticker}`,
        strategy: 'volatility',
        kind: 'single',
        riskless: false,
        legs: [{ ticker: m.ticker, eventTicker: m.eventTicker, title: m.title, side, price }],
        fairProb: side === 'yes' ? fairYes : 1 - fairYes,
        edge: Math.abs(dev) * 0.5,
        confidence: Math.min(1, Math.abs(dev) / (3 * Math.max(sigmaP, 0.005))),
        reason: `mid ${m.mid.toFixed(3)} vs EMA20 ${e.toFixed(3)} (dev ${dev.toFixed(3)}), GARCH σ-ratio ${ratio.toFixed(2)}, persistence ${g.persistence.toFixed(2)}`,
      });
    }
    return out.sort((a, b) => b.confidence - a.confidence);
  }
}
