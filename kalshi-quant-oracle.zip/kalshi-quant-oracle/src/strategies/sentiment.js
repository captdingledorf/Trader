/**
 * @file src/strategies/sentiment.js
 * Docs: README.md §"News Sentiment Analysis Strategy" · docs/QWEN.md · docs/PORT_MAP.md §"Interpretations" · docs/AUDIT.md F-10, F-21
 *
 * PIPELINE (mirrors the README's five phases, scaled to the machine)
 *   collect   → NewsFeed.headlines()                     RSS/Atom, cached 10 min
 *   relevance → lexical overlap (always) + Qwen relevance (optional)
 *   assess    → lexicon tone  — or —  local Qwen stance/relevance/novelty/confidence (src/ai/qwen.js)
 *   signal    → weighted mean → probability shift bounded to ±10 points → trader sizes/caps/executes
 *
 * THREE MODES (chain of thought: a model that cannot be shown to help must not be allowed to trade)
 *   QWEN_ENABLED=false                    lexicon only (original behaviour)
 *   QWEN_ENABLED=true, QWEN_TRADE=false   SHADOW (default): Qwen assesses and everything is logged side-by-side with the
 *                                         lexicon score and the market mid, but ONLY the lexicon path can emit signals.
 *                                         This builds the dataset needed to test whether Qwen adds anything (qwen-eval.mjs).
 *   QWEN_ENABLED=true, QWEN_TRADE=true    Qwen stance drives signals (lexicon is the fallback if the model is down).
 *
 * LATENCY (tree of thought). A CPU-hosted 1.7B model needs seconds per headline. ✗ awaiting it inside the trading cycle
 * (stop-losses and later cycles would stall) ✓ analyze() only READS the cache (`peek`) and a background pump fills it,
 * at most QWEN_MAX_PER_CYCLE new assessments per cycle, one at a time. Signals appear a cycle or two after the news.
 *
 * PROBABILITY SHIFT: shift = 0.10 × meanTone/stance × confidence → at most ±10 points. Headlines can say a topic is
 * "going well" but not that a specific binary contract resolves YES, so we refuse to move fair value further.
 */
import { relevance, scoreText, tokens } from '../data/news.js';
import { NOVELTY_WEIGHT } from '../ai/qwen.js';

export class SentimentStrategy {
  name = 'sentiment';

  constructor({ news, qwen = null, logger = null }) {
    this.news = news;
    this.qwen = qwen;
    this.logger = logger;
    this.queue = []; // pending {market, h}
    this.queued = new Set();
    this.pumping = null;
  }

  /** Resolves when the background Qwen worker is idle (used by tests and the eval script). */
  idle() {
    return this.pumping ?? Promise.resolve();
  }

  /** Called by the trader for NON-enabled strategies: in shadow mode, keep assessing and logging (no signals, no trading). */
  async observe({ markets }) {
    if (!this.qwen?.cfg.shadow) return;
    const heads = await this.news.headlines();
    if (!heads.length) return;
    for (const c of this.#candidates(markets, heads).slice(0, 50)) for (const { h } of c.hits) this.#enqueue(c.m, h);
    this.#pump();
  }

  #candidates(markets, heads) {
    const cands = [];
    for (const m of markets) {
      const tt = tokens(`${m.title} ${m.subtitle}`);
      if (tt.size < 2) continue;
      const hits = heads.map((h) => ({ h, rel: relevance(tt, h.title) })).filter((x) => x.rel > 0).sort((a, b) => b.rel - a.rel).slice(0, 3);
      if (hits.length) cands.push({ m, hits, best: hits[0].rel });
    }
    return cands.sort((a, b) => b.best - a.best);
  }

  async analyze({ markets, settings }) {
    const heads = await this.news.headlines();
    if (!heads.length) return [];
    const lexicon = this.#lexicon(markets, heads, settings);
    if (!this.qwen) return lexicon;

    // candidate pairs: top-3 lexically relevant headlines for each of the 50 best-matching markets
    const cands = this.#candidates(markets, heads);
    for (const c of cands.slice(0, 50)) for (const { h } of c.hits) this.#enqueue(c.m, h);
    this.#pump();

    if (this.qwen.cfg.shadow) return lexicon; // shadow: lexicon decides, Qwen only observes
    if (this.qwen.circuitOpen) return lexicon; // model unavailable: fall back
    return this.#fromQwen(cands, settings);
  }

  /* ── background worker ─────────────────────────────────────────── */
  #enqueue(m, h) {
    const k = `${m.ticker}|${h.title}`;
    if (this.queued.has(k) || this.queue.length >= 60 || this.qwen.peek(m, h)) return;
    this.queued.add(k);
    this.queue.push({ k, market: { ticker: m.ticker, title: m.title, subtitle: m.subtitle, mid: m.mid }, h });
  }

  #pump() {
    if (this.pumping || !this.queue.length) return;
    this.pumping = (async () => {
      let budget = this.qwen.cfg.maxPerCycle;
      while (budget > 0 && this.queue.length && !this.qwen.circuitOpen) {
        const item = this.queue.shift();
        this.queued.delete(item.k);
        const r = await this.qwen.assess(item.market, item.h);
        if (r.cached) continue; // free: does not use the budget
        budget -= 1;
        if (r.ok) {
          await this.qwen.record({ t: Date.now(), ticker: item.market.ticker, market: item.market.title, mid: item.market.mid, headline: item.h.title, source: item.h.source, model: this.qwen.cfg.model, shadow: this.qwen.cfg.shadow, ms: r.ms, lexicon: scoreText(`${item.h.title}. ${item.h.summary ?? ''}`), qwen: r.value });
        } else this.logger?.debug?.(`qwen assess failed: ${r.error}`);
      }
    })()
      .catch((e) => this.logger?.warn?.(`qwen worker error: ${e.message}`))
      .finally(() => {
        this.pumping = null;
      });
  }

  /* ── signal builders ───────────────────────────────────────────── */
  #signal(m, shift, confidence, reason) {
    const fairYes = Math.min(0.97, Math.max(0.03, m.mid + shift));
    const side = shift > 0 ? 'yes' : 'no';
    const price = side === 'yes' ? m.yesAsk : m.noAsk;
    if (price === null) return null;
    return {
      id: `news:${m.ticker}`,
      strategy: 'sentiment',
      kind: 'single',
      riskless: false,
      legs: [{ ticker: m.ticker, eventTicker: m.eventTicker, title: m.title, side, price }],
      fairProb: side === 'yes' ? fairYes : 1 - fairYes,
      edge: Math.abs(shift),
      confidence,
      reason,
    };
  }

  #lexicon(markets, heads, settings) {
    const out = [];
    for (const m of markets) {
      const tt = tokens(`${m.title} ${m.subtitle}`);
      if (tt.size < 2) continue;
      const hits = [];
      for (const h of heads) {
        const rel = relevance(tt, h.title);
        if (rel > 0) hits.push({ rel, s: scoreText(`${h.title}. ${h.summary ?? ''}`) });
      }
      if (hits.length < 2) continue;
      const wsum = hits.reduce((a, x) => a + x.rel, 0);
      const mean = hits.reduce((a, x) => a + x.s * x.rel, 0) / wsum;
      const agree = hits.filter((x) => Math.sign(x.s) === Math.sign(mean) && x.s !== 0).length / hits.length;
      const confidence = Math.min(1, (hits.length / 5) * agree);
      if (Math.abs(mean) < settings.newsSentimentThreshold || confidence < 0.5) continue;
      const s = this.#signal(m, 0.1 * mean * confidence, confidence, `${hits.length} relevant headlines, mean tone ${mean.toFixed(2)}, agreement ${(agree * 100).toFixed(0)}%`);
      if (s) out.push(s);
    }
    return out.sort((a, b) => b.confidence - a.confidence);
  }

  #fromQwen(cands, settings) {
    const q = this.qwen.cfg;
    const out = [];
    for (const { m, hits } of cands) {
      const rows = [];
      for (const { h } of hits) {
        const v = this.qwen.peek(m, h);
        if (!v) continue;
        const w = v.relevance * v.confidence * (NOVELTY_WEIGHT[v.novelty] ?? 0.5);
        if (w >= 0.15) rows.push({ v, w, source: h.source });
      }
      if (new Set(rows.map((r) => r.source)).size < q.minSources) continue; // independent confirmation required
      const wsum = rows.reduce((a, r) => a + r.w, 0);
      const mean = rows.reduce((a, r) => a + r.v.stance * r.w, 0) / wsum;
      const agree = rows.filter((r) => r.v.stance !== 0 && Math.sign(r.v.stance) === Math.sign(mean)).length / rows.length;
      const confidence = Math.min(1, wsum / 1.5) * agree;
      if (Math.abs(mean) < settings.newsSentimentThreshold || confidence < q.minConfidence) continue;
      const s = this.#signal(m, 0.1 * mean * confidence, confidence, `Qwen(${q.model}): ${rows.length} assessments from ${new Set(rows.map((r) => r.source)).size} sources, stance ${mean.toFixed(2)}, agreement ${(agree * 100).toFixed(0)}%`);
      if (s) out.push(s);
    }
    return out.sort((a, b) => b.confidence - a.confidence);
  }
}
