/**
 * @file src/strategies/arbitrage.js
 * Docs: README.md §"Statistical Arbitrage Strategy" · docs/ARCHITECTURE.md §"Strategies" · docs/PORT_MAP.md
 *
 * THREE DETECTORS (tree of thought — all emit multi-leg "basket" signals)
 *
 *  A. EXCLUSIVE-EVENT NO-BASKET  (riskless modulo execution)
 *     If an event is flagged mutually_exclusive, at most ONE of its markets can resolve YES.
 *     Buying NO in k of its markets therefore pays at least (k-1) dollars per set, whatever happens.
 *     If  Σ noAsk_i  <  (k-1) − fees − threshold   ⇒ guaranteed profit.   (equivalently Σ yesBid > 1)
 *     Needs only exclusivity — NOT exhaustiveness — so any subset of the event works.
 *
 *  B. DECLARED IMPLICATIONS  (data/relations.json → "implications": [{"if":"A","then":"B"}])
 *     "A implies B" ⇒ P(A) ≤ P(B). This is the README's primary→general-election example.
 *     Buy NO(A) + YES(B): payout is ≥ $1 in every state, cost = (1 − yesBid_A) + yesAsk_B,
 *     so profit ≥ yesBid_A − yesAsk_B − fees. Riskless IF the implication truly holds.
 *
 *  C. COINTEGRATED PAIRS  (data/relations.json → "pairs": [["X","Y"]])  — NOT riskless
 *     Engle-Granger on mid-price history; if cointegrated (5%), half-life short, and |z| ≥ 2,
 *     bet on spread convergence with equal-count opposite legs. Prices of bounded binary contracts
 *     are a poor fit for the I(1) assumption, so this is opt-in, low-confidence, and never
 *     auto-executed live unless ARBITRAGE_AUTOEXEC=true.
 */
import fs from 'node:fs';
import { feePerContract } from '../util/money.js';
import { engleGranger } from '../util/stats.js';

const EST_SETS = 10; // order size assumed when estimating per-contract fee rounding

export function loadRelations(file, logger = null) {
  try {
    const j = JSON.parse(fs.readFileSync(file, 'utf8'));
    return { implications: Array.isArray(j.implications) ? j.implications : [], pairs: Array.isArray(j.pairs) ? j.pairs : [] };
  } catch (e) {
    if (e.code !== 'ENOENT') logger?.warn?.(`relations file unreadable: ${e.message}`);
    return { implications: [], pairs: [] };
  }
}

const leg = (m, side, price) => ({ ticker: m.ticker, eventTicker: m.eventTicker, title: m.title, side, price });

export class ArbitrageStrategy {
  name = 'arbitrage';

  constructor({ relations, feeCoeff = 0.07, logger = null }) {
    this.relations = relations;
    this.feeCoeff = feeCoeff;
    this.logger = logger;
  }

  #fees(legs) {
    return legs.reduce((s, l) => s + feePerContract(l.price, EST_SETS, this.feeCoeff), 0);
  }

  async analyze(ctx) {
    const { settings } = ctx;
    const thr = settings.statArbitrageThreshold;
    return [...this.#exclusiveEvents(ctx, thr), ...this.#implications(ctx, thr), ...this.#pairs(ctx, thr)].sort((a, b) => b.edge - a.edge);
  }

  /* A ───────────────────────────────────────────────────────────── */
  #exclusiveEvents({ markets, events }, thr) {
    const byEvent = new Map();
    for (const m of markets) {
      if (!m.eventTicker || m.noAsk === null) continue;
      if (!events.get(m.eventTicker)?.mutuallyExclusive) continue;
      (byEvent.get(m.eventTicker) ?? byEvent.set(m.eventTicker, []).get(m.eventTicker)).push(m);
    }
    const out = [];
    for (const [ev, ms] of byEvent) {
      if (ms.length < 2) continue;
      const legs = ms.map((m) => leg(m, 'no', m.noAsk));
      const cost = legs.reduce((s, l) => s + l.price, 0);
      const gross = ms.length - 1 - cost;
      const net = gross - this.#fees(legs);
      if (net >= thr) out.push({ id: `excl:${ev}`, strategy: 'arbitrage', kind: 'basket', riskless: true, payoutFloor: ms.length - 1, legs, edge: net, confidence: 0.9, reason: `exclusive event ${ev}: Σ NO ask ${cost.toFixed(3)} < ${(ms.length - 1)} payout floor (net ${net.toFixed(3)}/set)` });
    }
    return out;
  }

  /* B ───────────────────────────────────────────────────────────── */
  #implications({ quotes }, thr) {
    const out = [];
    for (const r of this.relations.implications) {
      const a = quotes.get(r.if);
      const b = quotes.get(r.then);
      if (!a || !b || a.yesBid === null || b.yesAsk === null || a.noAsk === null) continue;
      if (a.status !== 'active' || b.status !== 'active') continue;
      const legs = [leg(a, 'no', a.noAsk), leg(b, 'yes', b.yesAsk)];
      const net = 1 - legs.reduce((s, l) => s + l.price, 0) - this.#fees(legs);
      if (net >= thr) out.push({ id: `impl:${r.if}>${r.then}`, strategy: 'arbitrage', kind: 'basket', riskless: true, payoutFloor: 1, legs, edge: net, confidence: 0.8, reason: `${r.if} ⇒ ${r.then} violated: bid(A) ${a.yesBid.toFixed(3)} > ask(B) ${b.yesAsk.toFixed(3)} (net ${net.toFixed(3)}/set)` });
    }
    return out;
  }

  /* C ───────────────────────────────────────────────────────────── */
  #pairs({ quotes, history }, thr) {
    const out = [];
    for (const [ta, tb] of this.relations.pairs) {
      const a = quotes.get(ta);
      const b = quotes.get(tb);
      const ha = history.get(ta);
      const hb = history.get(tb);
      if (!a || !b || !ha || !hb || Math.min(ha.length, hb.length) < 60) continue;
      if (a.status !== 'active' || b.status !== 'active') continue;
      const eg = engleGranger(ha, hb);
      if (!eg || !eg.cointegrated5 || !eg.halfLife || eg.halfLife > 200 || Math.abs(eg.zLast) < 2 || eg.beta < 0.5 || eg.beta > 2) continue;
      // z>0: A rich vs B → buy NO(A) + YES(B); z<0: A cheap → buy YES(A) + NO(B)
      const legs = eg.zLast > 0 ? [leg(a, 'no', a.noAsk), leg(b, 'yes', b.yesAsk)] : [leg(a, 'yes', a.yesAsk), leg(b, 'no', b.noAsk)];
      if (legs.some((l) => l.price === null)) continue;
      const expected = 0.5 * Math.abs(eg.zLast) * eg.spreadStd - this.#fees(legs);
      if (expected >= thr) out.push({ id: `pair:${ta}~${tb}`, strategy: 'arbitrage', kind: 'basket', riskless: false, payoutFloor: null, legs, edge: expected, confidence: 0.3, reason: `cointegrated pair z=${eg.zLast.toFixed(2)} halfLife=${eg.halfLife.toFixed(0)} samples ADF=${eg.adfStat.toFixed(2)}` });
    }
    return out;
  }
}
