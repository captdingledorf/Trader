import test from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import { Ledger } from '../src/engine/ledger.js';
import { KalshiClient, normalizeMarket, normalizeOrderbook } from '../src/kalshi/client.js';
import { verifySignature } from '../src/kalshi/auth.js';
import { KalshiBroker, PaperBroker } from '../src/engine/broker.js';
import { parseFeed, scoreText, relevance, tokens } from '../src/data/news.js';
import { ArbitrageStrategy } from '../src/strategies/arbitrage.js';
import { MarketScanner } from '../src/data/scanner.js';
import { Trader } from '../src/engine/trader.js';
import { MockClient, rawMarket, silentLogger, tmpDir, baseCfg, FakeSettings } from './helpers.js';

/* ── ledger ─────────────────────────────────────────────────────── */
test('ledger: fee-inclusive cost basis, partial sell, settlement, equity', async () => {
  const L = new Ledger({ dataDir: tmpDir(), startingCash: 1000, name: 't' });
  await L.applyBuy({ ticker: 'T', side: 'yes', qty: 10, price: 0.4, fee: 0.2 });
  assert.ok(Math.abs(L.cash - (1000 - 4.2)) < 1e-9);
  assert.ok(Math.abs(L.getPosition('T', 'yes').avgCost - 0.42) < 1e-9);
  const r = await L.applySell({ ticker: 'T', side: 'yes', qty: 4, price: 0.5, fee: 0.1 });
  assert.ok(Math.abs(r.realized - (4 * 0.5 - 0.1 - 4 * 0.42)) < 1e-9);
  const pnl = await L.settle('T', 'yes'); // 6 contracts pay $1 each
  assert.ok(Math.abs(pnl - (6 - 6 * 0.42)) < 1e-9);
  assert.equal(L.positionList().length, 0);
  assert.ok(L.equity() > 1000);
  await L.save();
  const L2 = await new Ledger({ dataDir: L.file.replace(/\/[^/]+$/, ''), startingCash: 5, name: 't' }).load();
  assert.equal(L2.fresh, false);
  assert.ok(Math.abs(L2.cash - L.cash) < 1e-9, 'state survives restart');
});

test('ledger: losing NO position settles to zero payout', async () => {
  const L = new Ledger({ dataDir: tmpDir(), startingCash: 100, name: 't' });
  await L.applyBuy({ ticker: 'T', side: 'no', qty: 10, price: 0.3, fee: 0 });
  const pnl = await L.settle('T', 'no' === 'no' ? 'yes' : 'no');
  assert.ok(Math.abs(pnl + 3) < 1e-9);
});

/* ── client ─────────────────────────────────────────────────────── */
function mockFetch(handler) {
  const calls = [];
  const fn = async (url, init) => {
    calls.push({ url, init });
    const r = handler(url, init, calls.length);
    return { ok: r.status < 400, status: r.status, headers: { get: (k) => r.headers?.[k.toLowerCase()] ?? null }, text: async () => (r.body === undefined ? '' : JSON.stringify(r.body)) };
  };
  fn.calls = calls;
  return fn;
}

test('client: signs ONLY the path (no query), sends 3 auth headers, signature verifies', async () => {
  const { publicKey, privateKey } = crypto.generateKeyPairSync('rsa', { modulusLength: 2048 });
  const f = mockFetch(() => ({ status: 200, body: { orders: [] } }));
  const c = new KalshiClient({ baseUrl: 'https://demo-api.kalshi.co/trade-api/v2', keyId: 'KID', privateKeyPem: privateKey.export({ type: 'pkcs8', format: 'pem' }), fetchImpl: f, nowMs: () => 1700000000123 });
  await c.getOrders({ status: 'resting', limit: 5 });
  const { url, init } = f.calls[0];
  assert.match(url, /\/portfolio\/orders\?status=resting&limit=5$/);
  assert.equal(init.headers['KALSHI-ACCESS-KEY'], 'KID');
  assert.equal(init.headers['KALSHI-ACCESS-TIMESTAMP'], '1700000000123');
  assert.ok(verifySignature(publicKey, 'rsa', init.headers['KALSHI-ACCESS-SIGNATURE'], '1700000000123', 'GET', '/trade-api/v2/portfolio/orders'));
});

test('client: public endpoints carry no auth headers; 429 is retried; POST is never retried', async () => {
  let n = 0;
  const f = mockFetch(() => (++n === 1 ? { status: 429, headers: { 'retry-after': '0' }, body: {} } : { status: 200, body: { exchange_active: true, trading_active: true } }));
  const c = new KalshiClient({ baseUrl: 'https://demo-api.kalshi.co/trade-api/v2', fetchImpl: f });
  const r = await c.getExchangeStatus();
  assert.equal(r.trading_active, true);
  assert.equal(f.calls.length, 2);
  assert.equal(f.calls[0].init.headers['KALSHI-ACCESS-KEY'], undefined);

  const { privateKey } = crypto.generateKeyPairSync('ed25519');
  const f2 = mockFetch(() => ({ status: 500, body: { message: 'boom' } }));
  const c2 = new KalshiClient({ baseUrl: 'https://demo-api.kalshi.co/trade-api/v2', keyId: 'K', privateKeyPem: privateKey.export({ type: 'pkcs8', format: 'pem' }), fetchImpl: f2 });
  await assert.rejects(c2.createOrder({ ticker: 'X' }), /HTTP 500/);
  assert.equal(f2.calls.length, 1, 'POST must not auto-retry');
});

test('client: authenticated call without credentials fails loudly', async () => {
  const c = new KalshiClient({ baseUrl: 'https://demo-api.kalshi.co/trade-api/v2', fetchImpl: mockFetch(() => ({ status: 200, body: {} })) });
  await assert.rejects(c.getBalance(), /needs Kalshi credentials/);
});

test('normalizers: new fixed-point and legacy cent shapes produce identical markets', () => {
  const fresh = normalizeMarket({ ticker: 'A', status: 'active', yes_bid_dollars: '0.4000', yes_ask_dollars: '0.4200', no_bid_dollars: '0.5800', no_ask_dollars: '0.6000', volume_24h_fp: '12.00' });
  const legacy = normalizeMarket({ ticker: 'A', status: 'active', yes_bid: 40, yes_ask: 42, no_bid: 58, no_ask: 60, volume_24h: 12 });
  assert.deepEqual(fresh, legacy);
  const partial = normalizeMarket({ ticker: 'B', yes_bid_dollars: '0.3000', yes_ask_dollars: '0.3500' }); // derive NO side
  assert.ok(Math.abs(partial.noAsk - 0.7) < 1e-9 && Math.abs(partial.noBid - 0.65) < 1e-9);
  const ob = normalizeOrderbook({ orderbook_fp: { yes_dollars: [['0.4000', '10.00'], ['0.4100', '5.00']], no_dollars: [['0.5000', '7.00']] } });
  assert.equal(ob.yesBids[0].price, 0.41);
  assert.equal(normalizeOrderbook({ orderbook: { yes: [[40, 3]], no: [] } }).yesBids[0].price, 0.4);
});

/* ── brokers ────────────────────────────────────────────────────── */
test('broker: order payload styles (fixed | legacy | both)', () => {
  const o = { ticker: 'T', side: 'no', action: 'buy', count: 7, limitPrice: 0.615, clientOrderId: 'cid' };
  const fixed = new KalshiBroker({ client: {}, fieldStyle: 'fixed' }).buildBody(o);
  assert.deepEqual(fixed, { ticker: 'T', action: 'buy', side: 'no', type: 'limit', time_in_force: 'immediate_or_cancel', client_order_id: 'cid', count_fp: '7.00', no_price_dollars: '0.6200' });
  const legacy = new KalshiBroker({ client: {}, fieldStyle: 'legacy' }).buildBody(o);
  assert.equal(legacy.count, 7);
  assert.equal(legacy.no_price, 62);
  assert.equal(legacy.count_fp, undefined);
  const both = new KalshiBroker({ client: {}, fieldStyle: 'both' }).buildBody(o);
  assert.ok(both.count === 7 && both.count_fp === '7.00' && both.no_price === 62 && both.no_price_dollars === '0.6200');
});

test('broker: Kalshi fill parsing (fixed-point), 409 reconciliation, rejection', async () => {
  const client = {
    createOrder: async () => ({ order: { order_id: 'o1', status: 'executed', fill_count_fp: '5.00', taker_fill_cost_dollars: '2.0000', taker_fees_dollars: '0.0700' } }),
  };
  const r = await new KalshiBroker({ client }).submit({ ticker: 'T', side: 'yes', action: 'buy', count: 5, limitPrice: 0.41, clientOrderId: 'c' });
  assert.ok(r.ok && r.filled === 5 && Math.abs(r.avgPrice - 0.4) < 1e-9 && r.fee === 0.07);

  const dup = {
    createOrder: async () => {
      throw Object.assign(new Error('dup'), { status: 409 });
    },
    getOrders: async () => ({ orders: [{ order_id: 'o9', client_order_id: 'c', status: 'executed', fill_count_fp: '3.00' }] }),
  };
  const r2 = await new KalshiBroker({ client: dup }).submit({ ticker: 'T', side: 'yes', action: 'buy', count: 3, limitPrice: 0.5, clientOrderId: 'c' });
  assert.ok(r2.ok && r2.filled === 3 && r2.note.includes('409'));

  const rej = { createOrder: async () => { throw Object.assign(new Error('bad'), { status: 400 }); } };
  assert.equal((await new KalshiBroker({ client: rej }).submit({ ticker: 'T', side: 'yes', action: 'buy', count: 1, limitPrice: 0.5, clientOrderId: 'c' })).ok, false);
});

test('paper broker: pessimistic slippage, limit must cross, no quote ⇒ reject', async () => {
  const pb = new PaperBroker({ slippage: 0.01 });
  const q = { yesAsk: 0.42, yesBid: 0.4, noAsk: 0.6, noBid: 0.58 };
  const ok = await pb.submit({ side: 'yes', action: 'buy', count: 10, limitPrice: 0.43, clientOrderId: 'x' }, q);
  assert.ok(ok.ok && Math.abs(ok.avgPrice - 0.43) < 1e-9);
  assert.equal((await pb.submit({ side: 'yes', action: 'buy', count: 10, limitPrice: 0.42, clientOrderId: 'x' }, q)).ok, false);
  assert.equal((await pb.submit({ side: 'yes', action: 'buy', count: 1, limitPrice: 0.5, clientOrderId: 'x' }, {})).ok, false);
});

/* ── news ───────────────────────────────────────────────────────── */
test('news: RSS + Atom parsing with CDATA/entities, lexicon sentiment with negation, relevance gate', () => {
  const rss = '<rss><channel><item><title><![CDATA[Senate passes budget deal &amp; avoids shutdown]]></title><description>&lt;p&gt;Good day&lt;/p&gt;</description></item></channel></rss>';
  const atom = '<feed><entry><title>Markets fall sharply</title><summary>Investors fear recession</summary></entry></feed>';
  assert.equal(parseFeed(rss)[0].title, 'Senate passes budget deal & avoids shutdown');
  assert.equal(parseFeed(rss)[0].summary, 'Good day');
  assert.equal(parseFeed(atom)[0].title, 'Markets fall sharply');
  assert.ok(scoreText('Team wins championship in a record victory') > 0.5);
  assert.ok(scoreText('Talks collapse as crisis deepens') < -0.4);
  assert.ok(scoreText('This is not a success') < 0, 'negation flips');
  const tt = tokens('Will the Senate pass the budget bill?');
  assert.ok(relevance(tt, 'Senate passes budget bill after long debate') > 0.4);
  assert.equal(relevance(tt, 'Local bakery wins award'), 0);
});

/* ── arbitrage strategy ─────────────────────────────────────────── */
const mk = (t, bid, ask, event = 'EV') => normalizeMarket(rawMarket(t, { event, yesBid: bid, yesAsk: ask }));

test('arbitrage: exclusive-event NO-basket detected only when net of fees edge clears the threshold', async () => {
  const strat = new ArbitrageStrategy({ relations: { implications: [], pairs: [] } });
  const events = new Map([['EV', { mutuallyExclusive: true }], ['NX', { mutuallyExclusive: false }]]);
  const over = [mk('A', 0.4, 0.42), mk('B', 0.4, 0.42), mk('C', 0.4, 0.42)]; // Σ yes bid = 1.20
  const sigs = await strat.analyze({ markets: over, quotes: new Map(), events, history: new Map(), settings: { statArbitrageThreshold: 0.05 } });
  assert.equal(sigs.length, 1);
  assert.equal(sigs[0].legs.every((l) => l.side === 'no'), true);
  assert.ok(sigs[0].edge > 0.1 && sigs[0].payoutFloor === 2 && sigs[0].riskless);
  const fair = [mk('A', 0.33, 0.35), mk('B', 0.33, 0.35), mk('C', 0.3, 0.32)]; // Σ = 0.96 ⇒ no arb
  assert.equal((await strat.analyze({ markets: fair, quotes: new Map(), events, history: new Map(), settings: { statArbitrageThreshold: 0.05 } })).length, 0);
  const nonExclusive = [mk('A', 0.4, 0.42, 'NX'), mk('B', 0.4, 0.42, 'NX'), mk('C', 0.4, 0.42, 'NX')];
  assert.equal((await strat.analyze({ markets: nonExclusive, quotes: new Map(), events, history: new Map(), settings: { statArbitrageThreshold: 0.05 } })).length, 0, 'non-exclusive events are never arbitraged');
});

test('arbitrage: declared implication A⇒B violated when bid(A) > ask(B)', async () => {
  const strat = new ArbitrageStrategy({ relations: { implications: [{ if: 'GEN', then: 'PRI' }], pairs: [] } });
  const quotes = new Map([['GEN', mk('GEN', 0.7, 0.72)], ['PRI', mk('PRI', 0.55, 0.58)]]);
  const sigs = await strat.analyze({ markets: [], quotes, events: new Map(), history: new Map(), settings: { statArbitrageThreshold: 0.05 } });
  assert.equal(sigs.length, 1);
  assert.deepEqual(sigs[0].legs.map((l) => `${l.side}:${l.ticker}`), ['no:GEN', 'yes:PRI']);
  assert.ok(sigs[0].edge > 0.05);
});

/* ── trader: full cycles against the mock exchange ─────────────── */
async function rig({ events, settings = {}, cfg = {}, strategies }) {
  const dir = tmpDir();
  const config = baseCfg(dir, cfg);
  const client = new MockClient(events);
  const set = new FakeSettings(settings, ['arbitrage']);
  const ledger = new Ledger({ dataDir: dir, startingCash: 1000, name: 'paper' });
  const scanner = new MarketScanner({ client, cfg: config, logger: silentLogger });
  const strat = strategies ?? [new ArbitrageStrategy({ relations: { implications: [], pairs: [] } })];
  const trader = new Trader({ cfg: config, settings: set, ledger, broker: new PaperBroker({ slippage: 0.01 }), client, scanner, strategies: strat, logger: silentLogger });
  return { trader, client, ledger, scanner, dir, set };
}

const overroundEvent = () => ({
  event_ticker: 'ELEC',
  mutually_exclusive: true,
  title: 'Election',
  markets: [rawMarket('A', { event: 'ELEC', yesBid: 0.4, yesAsk: 0.42 }), rawMarket('B', { event: 'ELEC', yesBid: 0.4, yesAsk: 0.42 }), rawMarket('C', { event: 'ELEC', yesBid: 0.4, yesAsk: 0.42 })],
});

test('trader: a stopped bot never trades; once started it executes the riskless basket in paper mode and holds to settlement', async () => {
  const { trader, client, ledger } = await rig({ events: [overroundEvent()] });
  await trader.cycle();
  assert.equal(ledger.positionList().length, 0, 'trading is OFF by default');
  trader.setTrading(true, 'test');
  await trader.cycle();
  const ps = ledger.positionList();
  assert.equal(ps.length, 3);
  assert.ok(ps.every((p) => p.side === 'no' && p.hold && p.qty === 50), 'sized by depth (50) and maxOrderContracts (50)');
  const cashAfter = ledger.cash;
  assert.ok(cashAfter < 1000);
  // collapse the quotes: hold-flagged legs must NOT be stop-lossed
  for (const t of ['A', 'B', 'C']) client.setMarket(t, { no_bid_dollars: '0.1000', yes_ask_dollars: '0.9000' });
  await trader.cycle();
  assert.equal(ledger.positionList().length, 3, 'riskless legs are not stopped out');
  // settle: C wins ⇒ NO(A)+NO(B) pay $1 each per set, NO(C) pays 0 ⇒ payout 2/set
  client.setMarket('A', { status: 'finalized', result: 'no' });
  client.setMarket('B', { status: 'finalized', result: 'no' });
  client.setMarket('C', { status: 'finalized', result: 'yes' });
  await trader.cycle();
  assert.equal(ledger.positionList().length, 0);
  assert.ok(ledger.equity() > 1000 + 5, `locked-in profit expected, equity=${ledger.equity()}`);
});

test('trader: live broker without AUTOSTART of auto-exec only ANNOUNCES baskets (no order sent)', async () => {
  const { trader, client } = await rig({ events: [overroundEvent()] });
  trader.broker = { kind: 'kalshi', submit: async () => assert.fail('must not send an order') };
  client.canSign = true;
  client.getBalance = async () => ({ cash: 1000 });
  const seen = [];
  trader.on('opportunity', (o) => seen.push(o));
  trader.setTrading(true, 'test');
  await trader.cycle();
  assert.equal(seen.length, 1);
  await trader.cycle();
  assert.equal(seen.length, 1, 'deduplicated for 30 minutes');
});

test('trader: stop-loss exits a single-leg position and realises the loss', async () => {
  const ev = { event_ticker: 'E1', mutually_exclusive: false, title: 'E1', markets: [rawMarket('X', { event: 'E1', yesBid: 0.5, yesAsk: 0.52 })] };
  const { trader, client, ledger } = await rig({ events: [ev] });
  await ledger.applyBuy({ ticker: 'X', eventTicker: 'E1', title: 'X', side: 'yes', qty: 20, price: 0.52, fee: 0.2, strategy: 'test' });
  trader.setTrading(true, 'test');
  client.setMarket('X', { yes_bid_dollars: '0.4000', yes_ask_dollars: '0.4200', no_bid_dollars: '0.5800', no_ask_dollars: '0.6000' });
  await trader.cycle();
  assert.equal(ledger.positionList().length, 0, 'stopped out');
  assert.ok(ledger.s.closed.at(-1).reason === 'stop_loss' && ledger.s.closed.at(-1).pnl < 0);
});

test('trader: daily-loss breaker halts NEW entries until /resume; exits stay available', async () => {
  const { trader, ledger } = await rig({ events: [overroundEvent()] });
  ledger.s.dayStart = { date: new Date().toISOString().slice(0, 10), equity: 1000 };
  ledger.s.cash = 970; // −$30 today ≥ 2% of $1000
  const events = [];
  trader.on('risk_event', (e) => events.push(e));
  trader.setTrading(true, 'test');
  await trader.cycle();
  assert.equal(trader.halted, true);
  assert.equal(events[0].kind, 'halt');
  assert.equal(ledger.positionList().length, 0, 'no entries while halted');
  trader.resume('test');
  assert.equal(trader.halted, false);
});

test('trader: exchange reporting trading_active=false blocks orders', async () => {
  const { trader, client, ledger } = await rig({ events: [overroundEvent()] });
  client.exchange = { exchange_active: true, trading_active: false };
  trader.setTrading(true, 'test');
  await trader.cycle();
  assert.equal(ledger.positionList().length, 0);
});

test('trader: API outage is contained — cycle records the error and the next one recovers', async () => {
  const { trader, client } = await rig({ events: [overroundEvent()] });
  const errors = [];
  trader.on('bot_error', (e) => errors.push(e));
  client.getExchangeStatus = async () => {
    throw new Error('network down');
  };
  await trader.cycle();
  assert.equal(trader.apiConnected, false);
  assert.equal(errors.length, 1);
  client.getExchangeStatus = async () => ({ exchange_active: true, trading_active: true });
  await trader.cycle();
  assert.equal(trader.apiConnected, true);
});

/* ── shutdown + reconciliation (added after review) ───────────────── */
test('client: abortAll() cancels pending reads and suppresses retries, but never aborts a POST', async () => {
  let posted = 0;
  const f = async (url, init) => {
    if (init.method === 'POST') {
      posted += 1;
      return { ok: true, status: 200, headers: { get: () => null }, text: async () => JSON.stringify({ order: { order_id: 'o', status: 'executed', fill_count_fp: '1.00' } }) };
    }
    return { ok: false, status: 503, headers: { get: () => null }, text: async () => '{}' };
  };
  const { privateKey } = crypto.generateKeyPairSync('ed25519');
  const c = new KalshiClient({ baseUrl: 'https://demo-api.kalshi.co/trade-api/v2', keyId: 'K', privateKeyPem: privateKey.export({ type: 'pkcs8', format: 'pem' }), fetchImpl: f });
  c.abortAll();
  await assert.rejects(c.getExchangeStatus(), /shutting down/);
  const r = await c.createOrder({ ticker: 'T' });
  assert.equal(r.order.status, 'executed');
  assert.equal(posted, 1);
});

test('trader: exchange-vs-ledger position mismatch raises ONE deduplicated alert and never auto-trades to fix it', async () => {
  const { trader, client } = await rig({ events: [overroundEvent()] });
  trader.broker = { kind: 'kalshi', submit: async () => assert.fail('reconciliation must never place orders') };
  client.canSign = true;
  client.getBalance = async () => ({ cash: 1000 });
  client.getPositions = async () => [{ ticker: 'MANUAL-1', position: 5, exposure: 2, realizedPnl: 0 }];
  const alerts = [];
  trader.on('risk_event', (e) => alerts.push(e));
  await trader.cycle(); // cycleCount 0 → reconcile runs
  assert.equal(alerts.filter((a) => a.kind === 'position_mismatch').length, 1);
  assert.match(alerts[0].reason, /MANUAL-1 exchange 5 vs bot 0/);
  assert.equal(trader.status().reconcile.mismatches, 1);
  trader.cycleCount = 3;
  await trader.cycle();
  assert.equal(alerts.filter((a) => a.kind === 'position_mismatch').length, 1, 'same diff is not re-announced');
  client.getPositions = async () => [];
  trader.cycleCount = 6;
  await trader.cycle();
  assert.equal(trader.status().reconcile.mismatches, 0);
});

test('trader: heartbeat timer is ref\'d (regression — bot exited silently when neither API nor Telegram was configured)', async () => {
  const { trader } = await rig({ events: [] });
  trader.start();
  assert.equal(trader.timer.hasRef(), true);
  await trader.stop();
});
