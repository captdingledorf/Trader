// Stand-in for an Ollama / OpenAI-compatible server speaking the shapes src/ai/qwen.js uses. Its "model" is a keyword
// heuristic — enough to exercise parsing, validation, caching, circuit breaking and the strategy; it says NOTHING about
// real Qwen quality (that is scripts/qwen-eval.mjs against the real model).
import http from 'node:http';

const POS = /\b(passes|passed|aprueba|record|clinches|favourites?|signals? (?:a )?(?:rate )?cut|intensifies|reaffirm|calm|skeptic|zinssenkung|récord|record)\b/i;
const NEG = /\b(fail|fails|stalls?|rejects?|rechaza|rejette|weakens?|warn|warns|rule out|ruled out|jeopardy|strike down|declining|cuts? revenue)\b|暂无降息/i;
const toks = (s) => new Set(String(s).toLowerCase().replace(/[^\p{L}\p{N} ]+/gu, ' ').split(/\s+/).filter((w) => w.length >= 3));

export function heuristic(user) {
  const market = (user.match(/<market>([\s\S]*?)<\/market>/) ?? [])[1] ?? '';
  const head = (user.match(/<headline[^>]*>([\s\S]*?)<\/headline>/) ?? [])[1] ?? '';
  const a = toks(market);
  let shared = 0;
  for (const t of toks(head)) if (a.has(t)) shared += 1;
  const relevant = shared >= 2;
  const stance = !relevant ? 0 : POS.test(head) ? 0.8 : NEG.test(head) ? -0.8 : 0;
  return { relevance: relevant ? 0.9 : 0.05, stance, sentiment: POS.test(head) ? 0.6 : NEG.test(head) ? -0.6 : 0, confidence: relevant ? 0.8 : 0.3, event_type: 'other', novelty: /breaking/i.test(head) ? 'breaking' : 'developing', language: 'en', entities: [], rationale: 'mock heuristic' };
}

export async function startMockOllama({ mode = 'ok', delayMs = 0 } = {}) {
  const st = { mode, delayMs, requests: [] };
  const server = http.createServer(async (req, res) => {
    const c = [];
    req.on('data', (d) => c.push(d));
    await new Promise((r) => req.on('end', r));
    const body = c.length ? JSON.parse(Buffer.concat(c)) : {};
    st.requests.push({ path: req.url, body });
    const send = (code, obj) => { const s = JSON.stringify(obj); res.writeHead(code, { 'Content-Type': 'application/json' }); res.end(s); };
    if (req.url === '/api/tags') return send(200, { models: [{ name: 'qwen3:1.7b' }, { name: 'kalshi-news:latest' }] });
    if (req.url === '/v1/models') return send(200, { data: [{ id: 'qwen3-1.7b' }] });
    if (st.delayMs) await new Promise((r) => setTimeout(r, st.delayMs));
    const user = (body.messages ?? []).find((m) => m.role === 'user')?.content ?? '';
    let content;
    switch (st.mode) {
      case 'http500': return send(500, { error: 'model crashed' });
      case 'garbage': content = 'Sorry, I cannot help with that.'; break;
      case 'think': content = `<think>The headline is about the market. Let me reason {not json}...</think>\n\`\`\`json\n${JSON.stringify(heuristic(user))}\n\`\`\``; break;
      case 'oor': content = JSON.stringify({ ...heuristic(user), stance: 99, confidence: -5, relevance: 7, sentiment: -50 }); break;
      case 'strings': content = JSON.stringify({ ...heuristic(user), stance: '0.9' }); break;
      case 'bullish': content = JSON.stringify({ ...heuristic(user), relevance: 1, stance: 1, sentiment: 1, confidence: 1, novelty: 'breaking' }); break;
      default: content = JSON.stringify(heuristic(user));
    }
    if (req.url === '/api/chat') return send(200, { model: body.model, message: { role: 'assistant', content }, done: true });
    if (req.url === '/v1/chat/completions') return send(200, { choices: [{ message: { role: 'assistant', content } }] });
    return send(404, { error: 'not found' });
  });
  await new Promise((r) => server.listen(0, '127.0.0.1', r));
  return { state: st, url: `http://127.0.0.1:${server.address().port}`, close: () => new Promise((r) => { server.closeAllConnections?.(); server.close(r); }) };
}
