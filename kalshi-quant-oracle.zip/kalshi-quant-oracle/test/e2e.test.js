import test from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import net from 'node:net';
import fs from 'node:fs';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { KalshiClient } from '../src/kalshi/client.js';
import { KalshiBroker } from '../src/engine/broker.js';
import { startMockKalshi, startMockTelegram, KEY_ID } from './mockKalshi.js';
import { rawMarket, tmpDir } from './helpers.js';

const ROOT = path.resolve(import.meta.dirname, '..');
const TOKEN = 'E'.repeat(32);

const events = () => [
  {
    event_ticker: 'ELEC',
    mutually_exclusive: true,
    title: 'Election',
    markets: ['A', 'B', 'C'].map((t) => rawMarket(t, { event: 'ELEC', yesBid: 0.4, yesAsk: 0.42 })),
  },
];
const rsa = () => crypto.generateKeyPairSync('rsa', { modulusLength: 2048 });
const pem = (k) => k.export({ type: 'pkcs8', format: 'pem' });
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
async function until(fn, ms = 20000, step = 150) {
  const t0 = Date.now();
  for (;;) {
    const v = await fn();
    if (v) return v;
    if (Date.now() - t0 > ms) return null;
    await sleep(step);
  }
}
const freePort = () => new Promise((r) => { const s = net.createServer(); s.listen(0, '127.0.0.1', () => { const p = s.address().port; s.close(() => r(p)); }); });

function spawnBot(env) {
  const child = spawn(process.execPath, ['src/index.js'], { cwd: ROOT, env: { PATH: process.env.PATH, LOG_LEVEL: 'info', ...env } });
  const logs = [];
  child.stdout.on('data', (d) => logs.push(String(d)));
  child.stderr.on('data', (d) => logs.push(String(d)));
  const exited = new Promise((r) => child.on('exit', (code, sig) => r({ code, sig })));
  return { child, logs, exited, text: () => logs.join(''), async stop() { child.kill('SIGTERM'); return Promise.race([exited, sleep(15000).then(() => { child.kill('SIGKILL'); return { code: 'KILLED' }; })]); } };
}

/* ── real HTTP: signing is verified server-side ───────────────────── */
test('e2e: signed requests over real HTTP are verified by the server (RSA-PSS); unsigned/tampered ones are 401', async () => {
  const k = rsa();
  const mock = await startMockKalshi({ publicKey: k.publicKey, events: events() });
  try {
    const good = new KalshiClient({ baseUrl: mock.url, keyId: KEY_ID, privateKeyPem: pem(k.privateKey) });
    assert.equal((await good.getBalance()).cash, 1000);
    assert.deepEqual(await good.getPositions(), []);
    const other = rsa();
    const bad = new KalshiClient({ baseUrl: mock.url, keyId: KEY_ID, privateKeyPem: pem(other.privateKey) });
    await assert.rejects(bad.getBalance(), /HTTP 401/);
    const wrongId = new KalshiClient({ baseUrl: mock.url, keyId: 'NOPE', privateKeyPem: pem(k.privateKey) });
    await assert.rejects(wrongId.getBalance(), /HTTP 401/);
    const skew = new KalshiClient({ baseUrl: mock.url, keyId: KEY_ID, privateKeyPem: pem(k.privateKey), nowMs: () => Date.now() - 10 * 60 * 1000 });
    await assert.rejects(skew.getBalance(), /HTTP 401/, 'clock skew is rejected like the real exchange');
    const authed = mock.state.log.filter((l) => l.path.includes('/portfolio/') && l.authed);
    assert.ok(authed.length >= 2);
  } finally {
    await mock.close();
  }
});

test('e2e: Ed25519 keys sign correctly over real HTTP', async () => {
  const k = crypto.generateKeyPairSync('ed25519');
  const mock = await startMockKalshi({ publicKey: k.publicKey, keyType: 'ed25519', events: events() });
  try {
    const c = new KalshiClient({ baseUrl: mock.url, keyId: KEY_ID, privateKeyPem: pem(k.privateKey) });
    assert.equal((await c.getBalance()).cash, 1000);
  } finally {
    await mock.close();
  }
});

test('e2e: broker places IOC orders (fixed & legacy payloads), handles no-fill, duplicate ids and style rejection', async () => {
  const k = rsa();
  const mock = await startMockKalshi({ publicKey: k.publicKey, events: events() });
  try {
    const client = new KalshiClient({ baseUrl: mock.url, keyId: KEY_ID, privateKeyPem: pem(k.privateKey) });
    const order = (over = {}) => ({ ticker: 'A', side: 'no', action: 'buy', count: 7, limitPrice: 0.61, clientOrderId: crypto.randomUUID(), ...over });
    const fixed = new KalshiBroker({ client, fieldStyle: 'fixed' });
    const r = await fixed.submit(order());
    assert.ok(r.ok && r.filled === 7 && Math.abs(r.avgPrice - 0.6) < 1e-9, JSON.stringify(r));
    assert.equal(mock.state.positions.get('A'), -7, 'NO contracts are negative on the exchange');
    assert.equal((await fixed.submit(order({ limitPrice: 0.5 }))).ok, false, 'limit below the ask must not fill');
    const legacy = await new KalshiBroker({ client, fieldStyle: 'legacy' }).submit(order({ ticker: 'B' }));
    assert.ok(legacy.ok && legacy.filled === 7);
    const cid = crypto.randomUUID();
    await fixed.submit(order({ clientOrderId: cid }));
    const dup = await fixed.submit(order({ clientOrderId: cid }));
    assert.ok(dup.ok && /409/.test(dup.note), 'duplicate id is reconciled, not double-filled');
    assert.equal(mock.state.positions.get('A'), -14, 'exactly two fills on A (the third was the duplicate)');
    mock.state.rejectStyles.add('fixed');
    const rej = await fixed.submit(order());
    assert.equal(rej.ok, false);
    assert.match(rej.note, /not accepted/);
  } finally {
    await mock.close();
  }
});

test('e2e: scripts/smoke-demo.mjs passes against the mock (incl. --place-test-order)', async () => {
  const k = rsa();
  const mock = await startMockKalshi({ publicKey: k.publicKey, events: events() });
  const dir = tmpDir();
  const keyFile = path.join(dir, 'k.pem');
  fs.writeFileSync(keyFile, pem(k.privateKey), { mode: 0o600 });
  try {
    const child = spawn(process.execPath, ['scripts/smoke-demo.mjs', '--place-test-order'], { cwd: ROOT, env: { PATH: process.env.PATH, KALSHI_BASE_URL: mock.url, KALSHI_API_KEY_ID: KEY_ID, KALSHI_PRIVATE_KEY_PATH: keyFile } });
    let out = '';
    child.stdout.on('data', (d) => (out += d));
    child.stderr.on('data', (d) => (out += d));
    const code = await new Promise((r) => child.on('exit', r));
    assert.equal(code, 0, out);
    assert.match(out, /public: exchange status/);
    assert.match(out, /signed: balance \(rsa key\) — cash \$1000\.00/);
    assert.match(out, /order payload "fixed" — accepted/);
    assert.match(out, /KALSHI_ORDER_FIELD_STYLE=fixed/);
    // when the exchange rejects the fixed style the script must recommend another one
    mock.state.rejectStyles.add('fixed');
    const c2 = spawn(process.execPath, ['scripts/smoke-demo.mjs', '--place-test-order'], { cwd: ROOT, env: { PATH: process.env.PATH, KALSHI_BASE_URL: mock.url, KALSHI_API_KEY_ID: KEY_ID, KALSHI_PRIVATE_KEY_PATH: keyFile } });
    let out2 = '';
    c2.stdout.on('data', (d) => (out2 += d));
    await new Promise((r) => c2.on('exit', r));
    assert.match(out2, /order payload "fixed"/);
    assert.match(out2, /KALSHI_ORDER_FIELD_STYLE=(both|legacy)/);
  } finally {
    await mock.close();
  }
});

test('e2e: the smoke script refuses a non-demo host', async () => {
  const child = spawn(process.execPath, ['scripts/smoke-demo.mjs'], { cwd: ROOT, env: { PATH: process.env.PATH, KALSHI_BASE_URL: 'https://api.elections.kalshi.com/trade-api/v2' } });
  let err = '';
  child.stderr.on('data', (d) => (err += d));
  const code = await new Promise((r) => child.on('exit', r));
  assert.equal(code, 2);
  assert.match(err, /REFUSING/);
});

/* ── whole process, paper mode, + Telegram over real HTTP ───────────── */
test('e2e: whole process in PAPER mode finds and paper-trades the arbitrage basket; Telegram + REST work over real HTTP', async () => {
  const k = rsa();
  const mock = await startMockKalshi({ publicKey: k.publicKey, events: events() });
  const tg = await startMockTelegram();
  const port = await freePort();
  const dir = tmpDir();
  const bot = spawnBot({ DATA_DIR: dir, KALSHI_BASE_URL: mock.url, AUTOSTART_TRADING: 'true', TRADE_INTERVAL_SECONDS: '10', API_TOKEN: TOKEN, API_PORT: String(port), TELEGRAM_BOT_TOKEN: tg.token, TELEGRAM_API_URL: tg.url, TELEGRAM_CHAT_ID: '42' });
  const api = (p, init = {}) => fetch(`http://127.0.0.1:${port}${p}`, { ...init, headers: { Authorization: `Bearer ${TOKEN}`, ...(init.headers ?? {}) } });
  try {
    const positions = await until(async () => {
      try { const r = await (await api('/api/positions')).json(); return r.length === 3 ? r : null; } catch { return null; }
    });
    assert.ok(positions, `3 paper positions expected.\n${bot.text()}`);
    assert.ok(positions.every((p) => p.side === 'no' && p.quantity === 50));
    assert.equal(mock.state.orders.length, 0, 'paper mode must NEVER send an order to the exchange');
    assert.equal(mock.state.log.some((l) => l.method === 'POST'), false);
    const status = await (await api('/api/status')).json();
    assert.equal(status.mode, 'paper');
    assert.equal(status.apiConnected, true);
    assert.equal(status.trading, true);
    const bal = await (await api('/api/balance')).json();
    assert.ok(bal.available < 1000 && bal.totalEquity > 0);
    assert.equal((await fetch(`http://127.0.0.1:${port}/api/status`)).status, 401);
    // dashboard: public page with strict CSP, token-gated data
    const page = await fetch(`http://127.0.0.1:${port}/`);
    assert.equal(page.status, 200);
    assert.match(page.headers.get('content-security-policy'), /script-src 'sha256-/);
    assert.match(await page.text(), /Mission Control/);
    const mk = await (await api('/api/markets')).json();
    assert.equal(mk.events[0].n, 3);
    assert.ok(Math.abs(mk.events[0].overround - 0.2) < 1e-9);
    assert.ok((await (await api('/api/signals')).json()).some((s) => s.outcome === 'executed'));
    assert.ok(Array.isArray(await (await api('/api/equity').then((r) => r.json())).points));
    assert.deepEqual((await (await api('/api/sentiment')).json()).qwen, null, 'Qwen disabled by default');
    assert.ok((await (await api('/api/logs')).json()).length > 0);
    assert.equal((await (await api('/api/status')).json()).risk.maxOpenPositions, 10);

    // Telegram: allowed user is served, a stranger is not
    tg.say('/status', 99);
    tg.say('/status', 42);
    const reply = await until(() => tg.state.sent.find((m) => /Bot status/.test(m.text)), 8000);
    assert.ok(reply, `status reply expected.\n${bot.text()}`);
    assert.equal(String(reply.chat_id), '42');
    assert.ok(!tg.state.sent.some((m) => String(m.chat_id) === '99'), 'strangers get no reply');
    assert.ok(tg.state.sent.some((m) => /Bot started/.test(m.text)), 'startup notification');
    assert.ok(tg.state.sent.some((m) => /BASKET/.test(m.text)), 'basket trade notification pushed to Telegram');
  } finally {
    const r = await bot.stop();
    assert.equal(r.code, 0, `clean shutdown expected.\n${bot.text()}`);
    await mock.close();
    await tg.close();
  }
  const state = JSON.parse(fs.readFileSync(path.join(dir, 'state.paper.json'), 'utf8'));
  assert.equal(Object.keys(state.positions).length, 3, 'state persisted on SIGTERM');
  assert.ok(!bot.text().includes('PRIVATE KEY') && !bot.text().includes(tg.token), 'no secrets in logs');
});

/* ── whole process, LIVE (demo) mode: signed orders hit the exchange ─── */
test('e2e: whole process in LIVE-DEMO mode places signed IOC orders, reconciles positions, and flags an outside position', async () => {
  const k = rsa();
  const mock = await startMockKalshi({ publicKey: k.publicKey, events: events() });
  const port = await freePort();
  const dir = tmpDir();
  const keyFile = path.join(dir, 'k.pem');
  fs.writeFileSync(keyFile, pem(k.privateKey), { mode: 0o600 });
  const bot = spawnBot({ DATA_DIR: path.join(dir, 'data'), TRADING_MODE: 'live', KALSHI_ENV: 'demo', KALSHI_BASE_URL: mock.url, KALSHI_API_KEY_ID: KEY_ID, KALSHI_PRIVATE_KEY_PATH: keyFile, ARBITRAGE_AUTOEXEC: 'true', AUTOSTART_TRADING: 'true', TRADE_INTERVAL_SECONDS: '10', RECONCILE_EVERY_N_CYCLES: '1', API_TOKEN: TOKEN, API_PORT: String(port) });
  const api = async (p) => (await fetch(`http://127.0.0.1:${port}${p}`, { headers: { Authorization: `Bearer ${TOKEN}` } })).json();
  try {
    const positions = await until(async () => { try { const r = await api('/api/positions'); return r.length === 3 ? r : null; } catch { return null; } });
    assert.ok(positions, `3 live positions expected.\n${bot.text()}`);
    const posts = mock.state.log.filter((l) => l.method === 'POST');
    assert.equal(posts.length, 3);
    assert.ok(posts.every((l) => l.authed), 'every order carried a valid signature');
    assert.deepEqual(mock.state.orders.map((o) => `${o.side}:${o.fill_count_fp}`), ['no:50.00', 'no:50.00', 'no:50.00']);
    for (const t of ['A', 'B', 'C']) assert.equal(mock.state.positions.get(t), -50);
    // after the next cycle's reconcile the ledger and exchange agree
    const consistent = await until(async () => { const s = await api('/api/status'); return s.reconcile.at && s.openPositions === 3 && s.reconcile.mismatches === 0 && s.cycle.at ? s : null; }, 25000);
    assert.ok(consistent, bot.text());
    // someone trades outside the bot: the next reconcile must flag it (alert only; no order is sent to "fix" it)
    const before = mock.state.log.filter((l) => l.method === 'POST').length;
    mock.state.positions.set('MANUAL-1', 5);
    const flagged = await until(async () => { const s = await api('/api/status'); return s.reconcile.mismatches === 1 ? s : null; }, 25000);
    assert.ok(flagged, `mismatch expected.\n${bot.text()}`);
    assert.equal(mock.state.log.filter((l) => l.method === 'POST').length, before, 'reconciliation must never place orders');
    assert.equal((await api('/api/balance')).mode, 'live');
  } finally {
    const r = await bot.stop();
    assert.equal(r.code, 0, `clean shutdown expected.\n${bot.text()}`);
    await mock.close();
  }
  assert.ok(!bot.text().includes('BEGIN PRIVATE KEY'));
});
