// Shared test helpers (docs/AUDIT.md §"Verification evidence"). No network, no dependencies.
import os from 'node:os';
import path from 'node:path';
import fs from 'node:fs';
import { EventEmitter } from 'node:events';

export const silentLogger = { debug() {}, info() {}, warn() {}, error() {}, subscribe: () => () => {} };
export const tmpDir = () => fs.mkdtempSync(path.join(os.tmpdir(), 'kq-'));

const FUTURE = new Date(Date.now() + 7 * 24 * 3600 * 1000).toISOString();

/** Raw market object in the NEW fixed-point shape Kalshi returns after the 2026 migration. */
export function rawMarket(ticker, { event = 'EV', yesBid, yesAsk, status = 'active', result = '', vol = 500 } = {}) {
  return {
    ticker,
    event_ticker: event,
    title: `Market ${ticker}`,
    yes_sub_title: ticker,
    status,
    result,
    close_time: FUTURE,
    yes_bid_dollars: yesBid.toFixed(4),
    yes_ask_dollars: yesAsk.toFixed(4),
    no_bid_dollars: (1 - yesAsk).toFixed(4),
    no_ask_dollars: (1 - yesBid).toFixed(4),
    last_price_dollars: ((yesBid + yesAsk) / 2).toFixed(4),
    volume_24h_fp: vol.toFixed(2),
    open_interest_fp: '1000.00',
  };
}

/** In-memory stand-in for KalshiClient exposing exactly the methods the engine calls. */
export class MockClient extends EventEmitter {
  constructor(events = []) {
    super();
    this.events = events; // [{event_ticker, mutually_exclusive, title, markets:[raw]}]
    this.canSign = false;
    this.exchange = { exchange_active: true, trading_active: true };
    this.depth = 50;
  }

  async getExchangeStatus() {
    return this.exchange;
  }

  async getEvents() {
    return { events: this.events, cursor: '' };
  }

  async getMarket(ticker) {
    const { normalizeMarket } = await import('../src/kalshi/client.js');
    for (const e of this.events) for (const m of e.markets) if (m.ticker === ticker) return normalizeMarket({ event_ticker: e.event_ticker, ...m });
    throw new Error(`no market ${ticker}`);
  }

  async getOrderbook() {
    return { yesBids: [{ price: 0.4, size: this.depth }], noBids: [{ price: 0.4, size: this.depth }] };
  }

  async getBalance() {
    return { cash: 1000 };
  }

  async getPositions() {
    return [];
  }

  setMarket(ticker, patch) {
    for (const e of this.events) for (const m of e.markets) if (m.ticker === ticker) Object.assign(m, patch);
  }
}

export function baseCfg(dataDir, over = {}) {
  return Object.freeze({
    mode: 'paper',
    live: false,
    kalshiEnv: 'demo',
    dataDir,
    autostart: false,
    exitsWhenStopped: false,
    feeCoeff: 0.07,
    scan: { maxPages: 1, pageLimit: 100, minVolume24h: 0, maxSpread: 0.08, minMinutesToClose: 30, historyMax: 400, historyTickers: 300 },
    paper: { slippage: 0.01, assumedDepth: 20 },
    arbitrageAutoExec: false,
    maxNewTradesPerCycle: 3,
    timeStopHours: 0,
    ...over,
  });
}

export const defaultSettings = () => ({
  bankroll: 1000,
  tradeInterval: 60,
  maxPositionSize: 0.1,
  stopLoss: 0.05,
  newsSentimentThreshold: 0.6,
  statArbitrageThreshold: 0.05,
  volatilityThreshold: 0.1,
  maxDailyLoss: 0.02,
  maxOpenPositions: 10,
  correlationLimit: 0.7,
  kellyScale: 0.25,
  maxOrderContracts: 50,
  maxDrawdown: 0.1,
  minEdge: 0.03,
});

/** Minimal SettingsStore double. */
export class FakeSettings extends EventEmitter {
  constructor(over = {}, strategies = ['arbitrage']) {
    super();
    this.v = { ...defaultSettings(), ...over };
    this.strategies = new Set(strategies);
  }

  get() {
    return { ...this.v };
  }

  isEnabled(n) {
    return this.strategies.has(n);
  }

  enabledStrategies() {
    return [...this.strategies];
  }

  async patch(p) {
    Object.assign(this.v, p);
    return { applied: p, errors: [] };
  }

  async setStrategy(n, on) {
    if (on) this.strategies.add(n);
    else this.strategies.delete(n);
    return true;
  }
}
