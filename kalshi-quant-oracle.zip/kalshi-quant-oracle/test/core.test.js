import test from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import { dollars, fp, takerFee, toCents } from '../src/util/money.js';
import { createSigner, verifySignature } from '../src/kalshi/auth.js';
import { ols, adf, engleGranger, garch11, pearson, ewmaVol, logit } from '../src/util/stats.js';
import { kellyBinary, kellyGeneric, sizeSingle, exitDecision } from '../src/engine/risk.js';
import { redact } from '../src/logger.js';
import { defaultSettings } from './helpers.js';

/* seeded PRNG so statistical tests are deterministic */
function rng(seed) {
  let s = seed >>> 0;
  return () => {
    s = (s * 1664525 + 1013904223) >>> 0;
    return s / 2 ** 32;
  };
}
const gauss = (r) => Math.sqrt(-2 * Math.log(r() || 1e-9)) * Math.cos(2 * Math.PI * r());

test('money: prefers *_dollars / *_fp, falls back to legacy cents/ints', () => {
  assert.equal(dollars({ yes_bid_dollars: '0.6500', yes_bid: 99 }, 'yes_bid'), 0.65);
  assert.equal(dollars({ yes_bid: 65 }, 'yes_bid'), 0.65);
  assert.equal(dollars({}, 'yes_bid'), null);
  assert.equal(fp({ count_fp: '10.00', count: 3 }, 'count'), 10);
  assert.equal(fp({ count: 3 }, 'count'), 3);
});

test('fees: 100 contracts @ 50c = $1.75 (published formula); 1 contract rounds up to a cent', () => {
  assert.equal(takerFee(100, 0.5), 1.75);
  assert.equal(takerFee(1, 0.5), 0.02);
  assert.equal(takerFee(0, 0.5), 0);
  assert.equal(toCents(0.6149), 0.61);
});

test('auth: RSA-PSS signature verifies with salt=digest, message = ts+METHOD+path', () => {
  const { publicKey, privateKey } = crypto.generateKeyPairSync('rsa', { modulusLength: 2048 });
  const signer = createSigner(privateKey.export({ type: 'pkcs8', format: 'pem' }));
  assert.equal(signer.keyType, 'rsa');
  const sig = signer.sign('1700000000000', 'get', '/trade-api/v2/portfolio/balance');
  assert.ok(verifySignature(publicKey, 'rsa', sig, '1700000000000', 'GET', '/trade-api/v2/portfolio/balance'));
  assert.ok(!verifySignature(publicKey, 'rsa', sig, '1700000000001', 'GET', '/trade-api/v2/portfolio/balance'), 'timestamp is bound');
  assert.ok(!verifySignature(publicKey, 'rsa', sig, '1700000000000', 'POST', '/trade-api/v2/portfolio/balance'), 'method is bound');
});

test('auth: Ed25519 keys are detected and sign correctly', () => {
  const { publicKey, privateKey } = crypto.generateKeyPairSync('ed25519');
  const signer = createSigner(privateKey.export({ type: 'pkcs8', format: 'pem' }));
  assert.equal(signer.keyType, 'ed25519');
  const sig = signer.sign('1', 'POST', '/trade-api/v2/portfolio/orders');
  assert.ok(verifySignature(publicKey, 'ed25519', sig, '1', 'POST', '/trade-api/v2/portfolio/orders'));
});

test('stats: OLS recovers a known line; pearson sanity', () => {
  const x = Array.from({ length: 50 }, (_, i) => i / 10);
  const y = x.map((v) => 2 + 3 * v);
  const fit = ols(x.map((v) => [1, v]), y);
  assert.ok(Math.abs(fit.beta[0] - 2) < 1e-9 && Math.abs(fit.beta[1] - 3) < 1e-9);
  assert.ok(Math.abs(pearson(x, y) - 1) < 1e-9);
  assert.equal(pearson([1, 1, 1], [1, 2, 3]), null);
});

test('stats: ADF separates a mean-reverting AR(1) from a random walk', () => {
  const r = rng(7);
  const ar = [0];
  const rw = [0];
  for (let i = 1; i < 400; i++) {
    ar.push(0.5 * ar[i - 1] + gauss(r));
    rw.push(rw[i - 1] + gauss(r));
  }
  assert.ok(adf(ar, 1).stat < -3.5, `AR(1) should reject unit root, got ${adf(ar, 1).stat}`);
  assert.ok(adf(rw, 1).stat > -3.3, `random walk should not reject, got ${adf(rw, 1).stat}`);
});

test('stats: Engle-Granger flags a cointegrated pair and not independent walks', () => {
  const r = rng(11);
  const x = [0];
  for (let i = 1; i < 300; i++) x.push(x[i - 1] + gauss(r));
  const noise = [0];
  for (let i = 1; i < 300; i++) noise.push(0.4 * noise[i - 1] + 0.5 * gauss(r));
  const y = x.map((v, i) => 1 + 1.5 * v + noise[i]);
  const eg = engleGranger(y, x);
  assert.ok(eg.cointegrated5, `adf=${eg.adfStat}`);
  assert.ok(Math.abs(eg.beta - 1.5) < 0.1);
  const w = [0];
  for (let i = 1; i < 300; i++) w.push(w[i - 1] + gauss(r));
  assert.equal(engleGranger(w, x).cointegrated5, false);
});

test('stats: GARCH(1,1) fit is stable and responds to a volatility burst', () => {
  const r = rng(3);
  const calm = Array.from({ length: 150 }, () => 0.01 * gauss(r));
  const burst = [...calm, ...Array.from({ length: 10 }, () => 0.08 * gauss(r))];
  const g1 = garch11(calm);
  const g2 = garch11(burst);
  assert.ok(g1 && g2 && g1.persistence < 0.995);
  assert.ok(g2.forecastVar > g1.forecastVar * 3, 'forecast variance rises after a burst');
  assert.ok(ewmaVol(burst) > ewmaVol(calm));
  assert.ok(Number.isFinite(logit(0.3)));
});

test('risk: binary Kelly equals the generic README formula', () => {
  const c = 0.4;
  const p = 0.55;
  assert.ok(Math.abs(kellyBinary(p, c) - kellyGeneric(p, 1 - c, c)) < 1e-12);
  assert.equal(kellyBinary(0.3, 0.4), 0, 'no edge ⇒ no bet');
});

test('risk: sizing respects edge floor, per-position cap and cash', () => {
  const s = defaultSettings();
  assert.equal(sizeSingle({ fairProb: 0.41, price: 0.4, capital: 1000, cash: 1000, settings: s }).count, 0);
  const big = sizeSingle({ fairProb: 0.8, price: 0.4, capital: 1000, cash: 1000, settings: s });
  assert.ok(big.count > 0 && big.stake <= 1000 * s.maxPositionSize + 1e-9, `stake ${big.stake}`);
  assert.equal(sizeSingle({ fairProb: 0.8, price: 0.4, capital: 1000, cash: 0.2, settings: s }).count, 0);
});

test('risk: stop-loss, trailing stop, hold flag', () => {
  const s = defaultSettings();
  const pos = { avgCost: 0.5, peakBid: 0.5, openedAt: 0, hold: false };
  assert.equal(exitDecision(pos, 0.47, s, 1)?.reason, 'stop_loss');
  assert.equal(exitDecision(pos, 0.49, s, 1), null);
  assert.equal(exitDecision({ ...pos, peakBid: 0.62 }, 0.58, s, 1)?.reason, 'trailing_stop');
  assert.equal(exitDecision({ ...pos, hold: true }, 0.1, s, 1), null);
  assert.equal(exitDecision(pos, 0.5, s, 3 * 3600 * 1000, 2)?.reason, 'time_stop');
});

test('logger: secrets never survive redact()', () => {
  const dirty = 'key -----BEGIN PRIVATE KEY-----\nMIIabc\n-----END PRIVATE KEY----- tok bot123456789:AAAAAAAAAAAAAAAAAAAAAAAA hdr Bearer abcdefghijklmnop';
  const clean = redact(dirty);
  assert.ok(!/MIIabc|AAAAAAAA|abcdefghijklmnop/.test(clean), clean);
});
