// The dashboard cannot be opened in a browser inside this build environment, so these tests run its real script in a
// Node VM against a small DOM shim and (for the live path) against the REAL API server — which pins the contract between
// the UI's expectations and the server's actual payloads, and proves the strict CSP is satisfiable (no inline style="").
import test from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import { EventEmitter } from 'node:events';
import { createApiServer, uiCsp } from '../src/api/server.js';
import { Trader } from '../src/engine/trader.js';
import { Ledger } from '../src/engine/ledger.js';
import { PaperBroker } from '../src/engine/broker.js';
import { MarketScanner } from '../src/data/scanner.js';
import { ArbitrageStrategy } from '../src/strategies/arbitrage.js';
import { QwenProvider } from '../src/ai/qwen.js';
import { MockClient, rawMarket, silentLogger, tmpDir, baseCfg, FakeSettings } from './helpers.js';

const HTML = fs.readFileSync(path.resolve(import.meta.dirname, '../src/ui/index.html'), 'utf8');
const SCRIPT = HTML.match(/<script>([\s\S]*?)<\/script>/)[1];
const STYLE = HTML.match(/<style>([\s\S]*?)<\/style>/)[1];

class El {
  constructor(tag) { this.tag = tag; this.kids = []; this.attrs = {}; this.t = ''; this.html = ''; this.style = { props: {}, setProperty(k, v) { this.props[k] = v; } }; this.dataset = {}; this.className = ''; this.scrollTop = 0; this.clientHeight = 10; this.scrollHeight = 10; this.onclick = null; this.value = ''; }
  set textContent(v) { this.t = String(v); this.kids = []; }
  get textContent() { return this.t + this.kids.map((k) => k.textContent).join(''); }
  set innerHTML(v) { this.html = String(v); this.kids = []; }
  get innerHTML() { return this.html; }
  setAttribute(k, v) { this.attrs[k] = String(v); }
  append(...k) { for (const c of k) this.kids.push(typeof c === 'string' ? Object.assign(new El('#text'), { t: c }) : c); }
  replaceChildren(...k) { this.kids = []; this.t = ''; this.append(...k); }
  querySelectorAll() { return []; }
}
function loadUi({ search = '?demo', fetchImpl = async () => { throw new Error('no network'); }, token = '' } = {}) {
  const els = new Map();
  const timers = [];
  const doc = { hidden: false, documentElement: new El('html'), querySelector: (s) => { if (!els.has(s)) els.set(s, new El(s)); return els.get(s); }, createElement: (t) => new El(t), createElementNS: (_n, t) => new El(t) };
  const store = { kq: token };
  const ctx = vm.createContext({ document: doc, location: { search }, sessionStorage: { getItem: (k) => store[k] ?? null, setItem: (k, v) => { store[k] = v; } }, fetch: fetchImpl, setTimeout: (fn, ms) => { timers.push({ fn, ms }); return timers.length; }, clearTimeout() {}, matchMedia: () => ({ matches: false }), innerWidth: 1000, alert() {}, URLSearchParams, Date, Math, Number, Object, Promise, console, String, Array, JSON, isNaN });
  vm.runInContext(SCRIPT, ctx);
  return { els, doc, timers, $: (s) => doc.querySelector(s), ctx };
}
const until = async (fn, ms = 4000) => { const t0 = Date.now(); while (Date.now() - t0 < ms) { if (fn()) return true; await new Promise((r) => setTimeout(r, 15)); } return false; };

test('ui: static page is self-contained and CSP-clean (no external URLs, no inline style attributes, no inline handlers)', () => {
  assert.ok(!/(?:src|href)=["']https?:/.test(HTML), 'no external resources');
  assert.ok(!/\sstyle=["']/.test(HTML), 'inline style attributes are blocked by the CSP');
  assert.ok(!/\son[a-z]+=["']/.test(HTML), 'inline event-handler attributes are blocked by the CSP');
  assert.ok(!/innerHTML\s*=\s*[^;]*\$\{\s*(?:m|x|a|e)\.(?:title|headline|reason|ticker|source|msg)/.test(SCRIPT), 'untrusted fields never reach innerHTML');
  assert.match(HTML, /viewport-fit=cover/);
  assert.match(HTML, /prefers-color-scheme:dark/);
  assert.ok(HTML.length < 30000);
});

test('ui: server delivers the page with a strict CSP whose hashes match the inline script and style', async () => {
  const csp = uiCsp(HTML);
  const h = (s) => `'sha256-${crypto.createHash('sha256').update(s).digest('base64')}'`;
  assert.ok(csp.includes(`script-src ${h(SCRIPT)}`));
  assert.ok(csp.includes(`style-src ${h(STYLE)}`));
  assert.ok(!/unsafe-inline|unsafe-eval|\*/.test(csp.replace("img-src 'self' data:", '')));
  assert.match(csp, /default-src 'none'/);
  assert.match(csp, /frame-ancestors 'none'/);
  const T = 'U'.repeat(32);
  const trader = Object.assign(new EventEmitter(), { halted: false, haltText: '', stopped: false, status: () => ({}), balanceView: () => ({}), positionsView: () => [], performanceView: () => ({}), setTrading() {} });
  const api = createApiServer({ cfg: { live: false, kalshiEnv: 'demo', api: { host: '127.0.0.1', port: 0, token: T } }, trader, settings: new FakeSettings(), logger: silentLogger });
  const addr = await api.listen();
  try {
    const r = await fetch(`http://127.0.0.1:${addr.port}/`);
    assert.equal(r.status, 200);
    assert.equal(r.headers.get('content-security-policy'), csp);
    assert.equal(r.headers.get('x-frame-options'), 'DENY');
    assert.equal(await r.text(), HTML);
    assert.equal((await fetch(`http://127.0.0.1:${addr.port}/ui`)).status, 200);
    const head = await fetch(`http://127.0.0.1:${addr.port}/`, { method: 'HEAD' });
    assert.equal(head.status, 200);
    assert.equal(head.headers.get('content-security-policy'), csp);
    assert.equal(await head.text(), '', 'HEAD carries no body');
    assert.equal((await fetch(`http://127.0.0.1:${addr.port}/api/equity`)).status, 401, 'the page is public, the data is not');
  } finally {
    await api.close();
  }
});

test('ui: demo mode renders every widget, keeps ticking, and emits no inline styles', async () => {
  const ui = loadUi();
  await until(() => ui.$('#heat').kids.length > 0);
  assert.match(ui.$('#k1').textContent, /^\$\d/);
  assert.equal(ui.$('#mode').textContent, 'PAPER');
  assert.equal(ui.$('#trd').textContent, 'TRADING ON');
  assert.equal((ui.$('#gauges').innerHTML.match(/<svg/g) ?? []).length, 3);
  assert.match(ui.$('#eq').innerHTML, /<path class="la"/);
  assert.match(ui.$('#pnl').innerHTML, /cumulative/);
  assert.match(ui.$('#rad').innerHTML, /Σ = 1\.00/);
  assert.equal(ui.$('#heat').kids.length, 40);
  assert.equal(ui.$('#pos').kids.length, 6, 'header + 5 positions');
  assert.equal(ui.$('#news').kids.length, 6);
  assert.equal(ui.$('#log').kids.length, 14);
  assert.match(ui.$('#ban').textContent, /DEMO DATA/);
  assert.match(ui.$('#qs').textContent, /Qwen · shadow/);
  const before = ui.$('#eq').innerHTML;
  for (let i = 0; i < 4; i++) { const t = ui.timers.pop(); await t.fn(); }
  assert.notEqual(ui.$('#eq').innerHTML, before, 'the chart updates on every tick');
  const all = [...ui.els.values()].map((e) => e.innerHTML).join('');
  assert.ok(!/\sstyle="/.test(all), 'generated markup must not contain inline style attributes (CSP)');
  assert.ok(!/NaN|undefined|Infinity/.test(all), 'no NaN/undefined leaked into charts');
  ui.$('#stop').onclick();
  await until(() => ui.$('#trd').textContent === 'TRADING OFF');
  assert.equal(ui.$('#trd').textContent, 'TRADING OFF');
});

/** Minimal XML well-formedness check for the SVG we generate (balanced tags, no bare ampersands, quoted attributes). */
function assertWellFormedSvg(name, markup) {
  assert.ok(!/&(?!(?:amp|lt|gt|quot|apos|#\d+|#x[0-9a-fA-F]+);)/.test(markup), `${name}: bare ampersand (malformed as XML)`);
  const stack = [];
  for (const m of markup.matchAll(/<(\/?)([a-zA-Z][\w:-]*)((?:\s+[\w:-]+="[^"]*")*)\s*(\/?)>/g)) {
    const [, close, tag, , self] = m;
    if (self) continue;
    if (close) assert.equal(stack.pop(), tag, `${name}: unbalanced </${tag}>`);
    else stack.push(tag);
  }
  assert.equal(stack.length, 0, `${name}: unclosed <${stack.at(-1)}>`);
  assert.ok(!/<[a-zA-Z][^>]*="[^"]*$/.test(markup), `${name}: truncated attribute`);
}

test('ui: every generated SVG chart is well-formed (found a bare "&" in an aria-label during review)', async () => {
  const ui = loadUi();
  await until(() => ui.$('#heat').kids.length > 0);
  for (const id of ['#eq', '#pnl', '#rad', '#gauges', '#s1']) assertWellFormedSvg(id, ui.$(id).innerHTML);
});

test('ui: untrusted text (market titles, headlines, log lines) is inserted as text, never as markup', async () => {
  const ui = loadUi();
  await until(() => ui.$('#heat').kids.length > 0);
  // every dynamic text path goes through textContent/h(): feed hostile strings through the same renderer
  const evil = '<img src=x onerror=alert(1)>';
  ui.ctx.__evil = evil;
  const h = vm.runInContext("(t,a,...k)=>{const e=document.createElement(t);for(const[x,v]of Object.entries(a||{}))x==='text'?e.textContent=v:e.setAttribute(x,v);e.append(...k);return e}", ui.ctx);
  const el = h('div', { text: evil });
  assert.equal(el.innerHTML, '');
  assert.equal(el.textContent, evil);
});

test('ui: LIVE mode against the real API server — payload contract, token gate, rendering', async () => {
  const dir = tmpDir();
  const ev = [{ event_ticker: 'ELEC', mutually_exclusive: true, title: 'Election', markets: ['A', 'B', 'C'].map((t) => rawMarket(t, { event: 'ELEC', yesBid: 0.4, yesAsk: 0.42 })) }];
  const client = new MockClient(ev);
  const cfg = baseCfg(dir);
  const settings = new FakeSettings({}, ['arbitrage']);
  const ledger = new Ledger({ dataDir: dir, startingCash: 1000, name: 'paper' });
  const trader = new Trader({ cfg, settings, ledger, broker: new PaperBroker({}), client, scanner: new MarketScanner({ client, cfg, logger: silentLogger }), strategies: [new ArbitrageStrategy({ relations: { implications: [], pairs: [] } })], logger: silentLogger });
  trader.setTrading(true, 'test');
  await trader.cycle();
  await trader.cycle();
  const qwen = new QwenProvider({ cfg: { enabled: true, backend: 'ollama', url: 'http://127.0.0.1:1', model: 'qwen3:1.7b', shadow: true, timeoutMs: 100 } });
  await qwen.record({ t: Date.now(), headline: 'Senate passes budget bill', source: 'bbc', lexicon: 0.5, qwen: { stance: 0.8, confidence: 0.9, novelty: 'breaking', language: 'en' } });
  const T = 'L'.repeat(32);
  const api = createApiServer({ cfg: { live: false, kalshiEnv: 'demo', api: { host: '127.0.0.1', port: 0, token: T } }, trader, settings, logger: silentLogger, qwen });
  const addr = await api.listen();
  const base = `http://127.0.0.1:${addr.port}`;
  const fetchImpl = (p, init) => fetch(base + p, init);
  try {
    const noTok = loadUi({ search: '', fetchImpl });
    await until(() => noTok.$('#lock').style.props.display === 'flex');
    assert.equal(noTok.$('#lock').style.props.display, 'flex', 'without a token the page asks for one');
    const bad = loadUi({ search: '', fetchImpl, token: 'wrong' });
    await until(() => bad.$('#lock').style.props.display === 'flex');
    assert.equal(bad.$('#lock').style.props.display, 'flex');

    const ui = loadUi({ search: '', fetchImpl, token: T });
    assert.ok(await until(() => ui.$('#pos').kids.length === 4), `positions table (header + 3) expected, got ${ui.$('#pos').kids.length}`);
    assert.equal(ui.$('#mode').textContent, 'PAPER');
    assert.equal(ui.$('#trd').textContent, 'TRADING ON');
    assert.equal(ui.$('#ban').kids.length, 0, 'no demo banner in live mode');
    assert.match(ui.$('#k1').textContent, /^\$99\d\.\d\d$|^\$1,00\d\.\d\d$|^\$\d/);
    assert.equal(ui.$('#heat').kids.length, 3, 'three tradable markets');
    assert.match(ui.$('#rad').innerHTML, /1\.200 · 3/, 'radar shows the exclusive event with Σ YES bids 1.200 over 3 markets');
    assert.ok(ui.$('#sig').kids.length >= 1);
    assert.match(ui.$('#sig').textContent, /executed/);
    assert.match(ui.$('#qs').textContent, /Qwen · shadow/);
    assert.equal(ui.$('#news').kids.length, 1);
    assert.ok(ui.$('#log').kids.length >= 0);
    assert.match(ui.$('#gauges').innerHTML, /positions/);
    // controls
    ui.$('#stop').onclick();
    assert.ok(await until(() => ui.$('#trd').textContent === 'TRADING OFF'), 'Stop button reaches the bot');
    assert.equal(trader.trading, false);
  } finally {
    await api.close();
  }
});

test('ui: hostile strings anywhere in the API payloads are rendered as text — no element ever receives markup', async () => {
  const EVIL = '<img src=x onerror=alert(1)>';
  const now = Date.now();
  const payload = {
    status: { mode: 'paper', kalshiEnv: 'demo', trading: true, halted: true, haltReason: EVIL, apiConnected: true, uptime: EVIL, activeStrategies: [EVIL], tradesCount: 1, openPositions: 1, cycle: { ms: 10, tradable: 1 }, reconcile: { mismatches: 1 }, risk: { dailyPnl: -1, dailyLossLimit: 20, drawdown: 0.01, maxDrawdown: 0.1, openPositions: 1, maxOpenPositions: 10 } },
    balance: { totalEquity: 1000, todayPnL: 1, unrealizedPnL: 1 },
    performance: { winRate: 50, totalTrades: 1, sharpeRatio: null },
    positions: [{ ticker: EVIL, eventName: EVIL, side: 'yes', quantity: 1, entryPrice: 0.5, currentPrice: 0.5, pnl: 0 }],
    equity: { points: [{ t: now - 6e5, equity: 1000 }, { t: now, equity: 1001 }] },
    trades: [{ ticker: EVIL, pnl: 1 }],
    markets: { top: [{ ticker: EVIL, title: EVIL, mid: 0.5, spread: 0.01, volume24h: 1 }], events: [{ eventTicker: EVIL, title: EVIL, n: EVIL, sumYesBid: 1.1, overround: 0.1 }] },
    signals: [{ id: EVIL, strategy: EVIL, reason: EVIL, outcome: EVIL, edge: 0.1, confidence: 0.5 }],
    sentiment: { qwen: { model: EVIL, shadow: true, circuitOpen: false }, recent: [{ headline: EVIL, source: EVIL, lexicon: 0.2, qwen: { stance: 0.5, confidence: 0.5, novelty: EVIL, language: EVIL } }] },
    logs: [{ ts: new Date().toISOString(), lvl: EVIL, msg: EVIL }],
  };
  const fetchImpl = async (p) => ({ ok: true, status: 200, json: async () => (p === '/api/health' ? { status: 'healthy' } : payload[p.replace('/api/', '')]) });
  const ui = loadUi({ search: '', fetchImpl, token: 't' });
  assert.ok(await until(() => ui.$('#heat').kids.length === 1));
  const walk = (e, f) => { f(e); e.kids.forEach((k) => walk(k, f)); };
  let sawText = 0;
  for (const root of ui.els.values()) walk(root, (e) => {
    assert.ok(!/<img/i.test(e.html), `markup injected via innerHTML on <${e.tag}>`);
    if (e.t.includes(EVIL)) sawText += 1;
    assert.ok(!/[<>]/.test(e.attrs.class ?? ''), 'untrusted values never become CSS class names');
  });
  assert.ok(sawText >= 5, `hostile strings should be shown as text in several widgets (saw ${sawText})`);
  assert.ok(!/<img/i.test(ui.$('#rad').innerHTML), 'chart markup built with innerHTML contains numbers only');
});
