// Regression tests for the defects found in audit pass 2 (docs/AUDIT.md §4). Each test names the bug it pins.
import test from 'node:test';
import assert from 'node:assert/strict';
import net from 'node:net';
import http from 'node:http';
import crypto from 'node:crypto';
import { parseFeed, NewsFeed } from '../src/data/news.js';
import { readTextCapped } from '../src/util/http.js';
import { WsHub } from '../src/util/wsHub.js';
import { createApiServer } from '../src/api/server.js';
import { loadConfig, coerceSetting, ConfigError } from '../src/config.js';
import { KalshiClient } from '../src/kalshi/client.js';
import { Ledger } from '../src/engine/ledger.js';
import { PaperBroker } from '../src/engine/broker.js';
import { MarketScanner } from '../src/data/scanner.js';
import { Trader } from '../src/engine/trader.js';
import { ArbitrageStrategy } from '../src/strategies/arbitrage.js';
import { MockClient, rawMarket, silentLogger, tmpDir, baseCfg, FakeSettings } from './helpers.js';
import { EventEmitter } from 'node:events';

const ms = (fn) => { const t = performance.now(); fn(); return performance.now() - t; };

test('D1 RSS parser is linear-time on hostile input (was 37–76 s of CPU for 1 MB)', () => {
  const hostile = {
    'unclosed <item> x170k': '<item '.repeat(170_000),
    'unclosed <title> x120k': `<item>${'<title>'.repeat(120_000)}</item>`,
    '"<" x500k without ">"': `<item><title>${'<'.repeat(500_000)}</title></item>`,
    'unclosed CDATA x80k': `<item><title>${'<![CDATA['.repeat(80_000)}</title></item>`,
    '<titleX> x100k': `<item>${'<titleX>a'.repeat(100_000)}</item>`,
    '<items> x100k': '<items>'.repeat(100_000),
  };
  for (const [name, xml] of Object.entries(hostile)) assert.ok(ms(() => parseFeed(xml)) < 1000, `${name} took too long`);
});

test('D1 RSS parser: correct output, entity hardening, item/field caps', () => {
  const x = '<rss><item><title><![CDATA[Senate passes deal &amp; avoids shutdown]]></title><description>&lt;p&gt;Good &#65;&#x42;&lt;/p&gt;</description><pubDate>Mon</pubDate></item><entry><title>Markets fall</title><summary>fear</summary><updated>t</updated></entry><item><title></title></item></rss>';
  const r = parseFeed(x, 'src');
  assert.deepEqual(r.map((i) => i.title), ['Senate passes deal & avoids shutdown', 'Markets fall']);
  assert.equal(r[0].summary, 'Good AB');
  assert.equal(r[0].published, 'Mon');
  assert.equal(r[0].source, 'src');
  assert.doesNotThrow(() => parseFeed('<item><title>a &#99999999999; &#xD800; &#0; b</title></item>'), 'out-of-range numeric entities must not throw');
  assert.equal(parseFeed('<item><title>a &#9999999; b</title></item>')[0].title, 'a \uFFFD b', 'out-of-range code point → U+FFFD');
  assert.equal(parseFeed('<item><title>a &#99999999999; b</title></item>')[0].title, 'a &#99999999999; b', 'absurdly long references stay literal text');
  assert.equal(parseFeed('<item><title>a</title></item>'.repeat(5000)).length, 100, 'item cap');
  assert.equal(parseFeed(`<item><title>${'x'.repeat(100000)}</title></item>`)[0].title.length, 400, 'title cap');
});

test('D1 NewsFeed: streams with a byte cap, enforces https, survives a failing feed', async () => {
  const big = `<rss>${'<item><title>Peace deal reached today</title></item>'.repeat(40000)}</rss>`; // ≈ 2 MB
  let served = 0;
  const f = async (url) => {
    if (url.includes('bad')) throw new Error('boom');
    const enc = new TextEncoder().encode(big);
    const body = new ReadableStream({ start(c) { for (let i = 0; i < enc.length; i += 65536) { c.enqueue(enc.slice(i, i + 65536)); served += 65536; } c.close(); } });
    return { ok: true, status: 200, body, text: async () => big };
  };
  const warns = [];
  const nf = new NewsFeed({ feeds: ['https://good.example/rss', 'https://bad.example/rss', 'http://insecure.example/rss'], fetchImpl: f, logger: { warn: (m) => warns.push(m) } });
  const items = await nf.headlines();
  assert.equal(items.length, 100);
  assert.equal(warns.length, 2, 'failing and non-https feeds are logged, not fatal');
  assert.ok(warns.some((w) => /must be https/.test(w)));
  const cap = await readTextCapped({ body: new ReadableStream({ start(c) { c.enqueue(new Uint8Array(5000).fill(97)); c.close(); } }) }, 1000);
  assert.equal(cap.text.length, 1000);
  assert.equal(cap.truncated, true);
  assert.ok(served >= 0);
});

test('D2 setting keys are validated as OWN properties (constructor/__proto__/toString used to pass)', async () => {
  for (const k of ['constructor', 'toString', '__proto__', 'hasOwnProperty', 'valueOf']) assert.equal(coerceSetting(k, '5').ok, false, k);
  assert.equal(coerceSetting('maxPositionSize', '0.2').ok, true);
});

test('D3 API: non-object bodies are 400 (null used to be a 500); prototype keys are ignored; no pollution', async () => {
  const trader = Object.assign(new EventEmitter(), { halted: false, haltText: '', stopped: false, status: () => ({}), balanceView: () => ({}), positionsView: () => [], performanceView: () => ({}), setTrading() {} });
  const seen = [];
  const settings = Object.assign(new EventEmitter(), { values: { stopLoss: 0.05 }, get() { return { ...this.values }; }, enabledStrategies: () => [], async patch(p) { seen.push(p); return { applied: p, errors: [] }; } });
  const T = 'T'.repeat(32);
  const api = createApiServer({ cfg: { live: false, kalshiEnv: 'demo', api: { host: '127.0.0.1', port: 0, token: T } }, trader, settings, logger: silentLogger });
  const addr = await api.listen();
  const post = (body) => fetch(`http://127.0.0.1:${addr.port}/api/config`, { method: 'POST', headers: { Authorization: `Bearer ${T}`, 'Content-Type': 'application/json' }, body });
  try {
    for (const b of ['null', '[1,2]', '5', '"x"']) assert.equal((await post(b)).status, 400, b);
    assert.equal((await post('{"__proto__":{"polluted":1},"constructor":7,"toString":1}')).status, 200);
    assert.deepEqual(seen.at(-1), {}, 'prototype-chain keys never reach the settings store');
    assert.equal(({}).polluted, undefined);
    assert.equal((await post('{"stopLoss":0.07}')).status, 200);
    assert.deepEqual(seen.at(-1), { stopLoss: 0.07 });
    const big = await post(JSON.stringify({ p: 'x'.repeat(20000) }));
    assert.equal(big.status, 413);
  } finally {
    await api.close();
  }
});

test('D4 WebSocket hub reaps half-open / abruptly closed clients immediately (they used to linger up to 60 s)', async () => {
  const hub = new WsHub({ authenticate: () => true, maxClients: 5, pingMs: 60000 });
  const srv = http.createServer();
  srv.on('upgrade', (req, s) => hub.handleUpgrade(req, s));
  await new Promise((r) => srv.listen(0, '127.0.0.1', r));
  const hs = `GET /ws HTTP/1.1\r\nHost: x\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Key: ${crypto.randomBytes(16).toString('base64')}\r\nSec-WebSocket-Version: 13\r\n\r\n`;
  const open = () => new Promise((res) => { const s = net.connect(srv.address().port, '127.0.0.1', () => s.write(hs)); s.once('data', () => res(s)); });
  try {
    const socks = await Promise.all([open(), open(), open()]);
    assert.equal(hub.clients.size, 3);
    for (const s of socks) s.destroy();
    const t0 = Date.now();
    while (hub.clients.size && Date.now() - t0 < 2000) await new Promise((r) => setTimeout(r, 20));
    assert.equal(hub.clients.size, 0);
    // and the cap is enforced for live clients
    const live = await Promise.all([1, 2, 3, 4, 5].map(open));
    const sixth = net.connect(srv.address().port, '127.0.0.1', () => sixth.write(hs));
    const first = await new Promise((r) => sixth.once('data', (d) => r(String(d).split('\r\n')[0])));
    assert.match(first, /503/);
    live.forEach((s) => s.destroy());
    sixth.destroy();
  } finally {
    hub.close();
    srv.close();
  }
});

test('D5 config: an explicit but invalid value is a startup error, never a silent default', async () => {
  const dir = tmpDir();
  const bad = [
    [{ AUTOSTART_TRADING: 'ture' }, /AUTOSTART_TRADING=ture/],
    [{ SCAN_MAX_PAGES: 'three' }, /SCAN_MAX_PAGES/],
    [{ SCAN_MAX_PAGES: '0' }, /SCAN_MAX_PAGES/],
    [{ STOP_LOSS_PERCENTAGE: '5' }, /stopLoss must be between/],
    [{ MAX_DAILY_LOSS: 'abc' }, /MAX_DAILY_LOSS/],
    [{ STRATEGIES: 'arbitrage,magic' }, /unknown strategy/],
    [{ KALSHI_ORDER_FIELD_STYLE: 'weird' }, /fixed, legacy or both/],
    [{ LOG_LEVEL: 'verbose' }, /LOG_LEVEL/],
    [{ TELEGRAM_CHAT_ID: '12,abc' }, /numeric user ID/],
    [{ TELEGRAM_API_URL: 'https://evil.example.com' }, /api\.telegram\.org/],
    [{ TRADING_MODE: 'live', KALSHI_ENV: 'prod', KALSHI_API_KEY_ID: 'k', I_UNDERSTAND_LIVE_TRADING_RISK: 'yes', AUTOSTART_TRADING: 'true' }, /not allowed with real money/],
    [{ QWEN_ENABLED: 'true', QWEN_URL: 'http://203.0.113.9:11434' }, /not loopback/],
  ];
  for (const [env, re] of bad) await assert.rejects(loadConfig({ DATA_DIR: dir, ...env }), (e) => e instanceof ConfigError && re.test(e.message), JSON.stringify(env));
  const ok = await loadConfig({ DATA_DIR: dir, KALSHI_API_KEY_ID: '', KALSHI_API_KEY: 'legacy-alias', STOP_LOSS_PERCENTAGE: '' });
  assert.equal(ok.cfg.keyId, 'legacy-alias', 'empty KALSHI_API_KEY_ID falls through to the alias');
  assert.equal(ok.settings.get().stopLoss, 0.05, 'empty value means default');
  const loop = await loadConfig({ DATA_DIR: dir, KALSHI_BASE_URL: 'http://127.0.0.1:9/trade-api/v2' });
  assert.equal(loop.cfg.baseUrl, 'http://127.0.0.1:9/trade-api/v2');
});

test('D6 client: oversized responses are rejected, not buffered', async () => {
  const f = async () => ({ ok: true, status: 200, headers: { get: () => null }, body: new ReadableStream({ start(c) { c.enqueue(new Uint8Array(4096).fill(32)); c.enqueue(new Uint8Array(4096).fill(32)); c.close(); } }), text: async () => '' });
  const c = new KalshiClient({ baseUrl: 'https://demo-api.kalshi.co/trade-api/v2', fetchImpl: f, maxResponseBytes: 5000 });
  await assert.rejects(c.getExchangeStatus(), /exceeded/);
});

async function rig(events, settings = {}) {
  const dir = tmpDir();
  const client = new MockClient(events);
  const set = new FakeSettings(settings, []);
  const cfg = baseCfg(dir);
  const ledger = new Ledger({ dataDir: dir, startingCash: 1000, name: 'paper' });
  const trader = new Trader({ cfg, settings: set, ledger, broker: new PaperBroker({}), client, scanner: new MarketScanner({ client, cfg, logger: silentLogger }), strategies: [], logger: silentLogger });
  return { trader, ledger, client };
}
const ev = (...ms) => [{ event_ticker: 'E', mutually_exclusive: false, title: 'E', markets: ms }];

test('D7 /resume re-baselines loss and drawdown, otherwise the breaker re-halts next cycle and can never be resumed', async () => {
  const { trader, ledger } = await rig(ev(rawMarket('X', { event: 'E', yesBid: 0.5, yesAsk: 0.52 })));
  ledger.s.dayStart = { date: new Date().toISOString().slice(0, 10), equity: 1000 };
  ledger.s.cash = 960;
  ledger.s.peakEquity = 1000;
  trader.setTrading(true, 'test');
  await trader.cycle();
  assert.equal(trader.halted, true);
  await trader.cycle();
  assert.equal(trader.halted, true, 'still halted without a resume');
  trader.resume('test');
  await trader.cycle();
  assert.equal(trader.halted, false, 'a resume must stick');
  assert.equal(ledger.dailyPnl(), 0);
  ledger.s.cash -= 30; // a NEW loss beyond 2% of bankroll after the resume halts again
  await trader.cycle();
  assert.equal(trader.halted, true);
});

test('D8 settlement: scalar/void results raise ONE alert instead of leaving a ghost position; settle is once per ticker', async () => {
  const m = rawMarket('S', { event: 'E', yesBid: 0.5, yesAsk: 0.52, status: 'finalized', result: 'scalar' });
  const { trader, ledger } = await rig(ev(m));
  await ledger.applyBuy({ ticker: 'S', eventTicker: 'E', title: 'S', side: 'yes', qty: 5, price: 0.5, fee: 0 });
  const alerts = [];
  trader.on('risk_event', (e) => alerts.push(e));
  await trader.cycle();
  await trader.cycle();
  assert.equal(alerts.filter((a) => a.kind === 'unsettleable').length, 1);
  assert.equal(ledger.positionList().length, 1, 'left for a human');
  const m2 = rawMarket('T', { event: 'E', yesBid: 0.5, yesAsk: 0.52, status: 'finalized', result: 'yes' });
  const r2 = await rig(ev(m2));
  await r2.ledger.applyBuy({ ticker: 'T', eventTicker: 'E', title: 'T', side: 'yes', qty: 4, price: 0.5, fee: 0 });
  await r2.ledger.applyBuy({ ticker: 'T', eventTicker: 'E', title: 'T', side: 'no', qty: 2, price: 0.4, fee: 0 });
  const settled = [];
  r2.trader.on('trade_executed', (e) => e.type === 'settled' && settled.push(e));
  await r2.trader.cycle();
  assert.equal(settled.length, 1, 'one settlement event per ticker, not per leg');
  assert.equal(r2.ledger.positionList().length, 0);
});

test('D9 scanner: bounded history, eviction of dropped tickers, tradability filters, persistence round-trip', async () => {
  const dir = tmpDir();
  const mk = (t, bid, ask, over = {}) => ({ ...rawMarket(t, { event: 'E', yesBid: bid, yesAsk: ask, vol: 100 }), ...over });
  const client = new MockClient(ev(mk('OK', 0.4, 0.42), mk('WIDE', 0.3, 0.5), mk('EXTREME', 0.01, 0.03), mk('CLOSED', 0.4, 0.42, { status: 'closed' }), mk('SOON', 0.4, 0.42, { close_time: new Date(Date.now() + 5 * 60000).toISOString() })));
  const cfg = baseCfg(dir, { scan: { maxPages: 1, pageLimit: 100, minVolume24h: 0, maxSpread: 0.08, minMinutesToClose: 30, historyMax: 5, historyTickers: 300 } });
  const sc = new MarketScanner({ client, cfg, logger: silentLogger });
  for (let i = 0; i < 8; i++) await sc.scan();
  const r = await sc.scan();
  assert.deepEqual(r.markets.map((m) => m.ticker), ['OK'], 'wide spread, extreme mid, closed and about-to-close markets are filtered');
  assert.equal(sc.history.get('OK').length, 5, 'ring buffer is bounded');
  await sc.save();
  const sc2 = await new MarketScanner({ client, cfg, logger: silentLogger }).load();
  assert.equal(sc2.history.get('OK').length, 5);
  client.events[0].markets = client.events[0].markets.filter((m) => m.ticker !== 'OK');
  await sc.scan();
  assert.equal(sc.history.has('OK'), false, 'tickers that disappear are evicted');
});

test('D10 broker clamps limit prices into the tradable range [0.01, 0.99] (a $1.00 limit would be rejected)', () => {
  const b = new (class extends Object {})();
  return import('../src/engine/broker.js').then(({ KalshiBroker }) => {
    const k = new KalshiBroker({ client: {}, fieldStyle: 'fixed' });
    const o = (p) => k.buildBody({ ticker: 'T', side: 'yes', action: 'buy', count: 1, limitPrice: p, clientOrderId: 'c' }).yes_price_dollars;
    assert.equal(o(1.0), '0.9900');
    assert.equal(o(1.2), '0.9900');
    assert.equal(o(0.001), '0.0100');
    assert.equal(o(0.614), '0.6100');
    assert.ok(b);
  });
});

/* ── failure containment (audit pass 2, round 2) ─────────────────────── */
const ev2 = (...m) => [{ event_ticker: 'E', mutually_exclusive: true, title: 'E', markets: m }];

test('D11 /close_all never races a running cycle (a manual close + a stop-loss exit could sell the same position twice)', async () => {
  const { trader, ledger, client } = await rig(ev2(rawMarket('X', { event: 'E', yesBid: 0.5, yesAsk: 0.52 })));
  await ledger.applyBuy({ ticker: 'X', eventTicker: 'E', title: 'X', side: 'yes', qty: 10, price: 0.52, fee: 0 });
  trader.setTrading(true, 'test');
  const sells = [];
  const real = trader.broker.submit.bind(trader.broker);
  trader.broker.submit = async (o, q) => { if (o.action === 'sell') sells.push(o.ticker); return real(o, q); };
  client.setMarket('X', { yes_bid_dollars: '0.3000', yes_ask_dollars: '0.3200', no_bid_dollars: '0.6800', no_ask_dollars: '0.7000' }); // stop-loss territory
  const slow = client.getExchangeStatus.bind(client);
  client.getExchangeStatus = async () => { await new Promise((r) => setTimeout(r, 120)); return slow(); };
  const cyc = trader.cycle();
  await new Promise((r) => setTimeout(r, 20));
  const closing = trader.closeAll('test'); // issued while the cycle is mid-flight
  await Promise.all([cyc, closing]);
  assert.equal(sells.length, 1, `the position must be sold exactly once, saw ${sells.length}`);
  assert.equal(ledger.positionList().length, 0);
});

test('D12 repeated state-save failures halt trading (trading without persistence loses positions after a crash)', async () => {
  const { trader, ledger } = await rig(ev2(rawMarket('X', { event: 'E', yesBid: 0.5, yesAsk: 0.52 })));
  ledger.save = async () => { throw new Error('ENOSPC: no space left on device'); };
  const alerts = [];
  trader.on('risk_event', (e) => alerts.push(e));
  trader.setTrading(true, 'test');
  for (let i = 0; i < 3; i++) await trader.cycle();
  assert.equal(trader.halted, true);
  assert.match(trader.haltText, /cannot persist state/);
  assert.equal(alerts.filter((a) => a.kind === 'halt').length, 1);
  ledger.save = async () => {};
  trader.resume('test');
  await trader.cycle();
  assert.equal(trader.halted, false, 'recovers once saving works again');
});

test('D13 a partially filled basket keeps stop-loss protection on the legs it holds; a completed riskless basket does not', async () => {
  const mk = (t) => rawMarket(t, { event: 'E', yesBid: 0.4, yesAsk: 0.42 });
  const { trader, ledger, client } = await rig(ev2(mk('A'), mk('B'), mk('C')));
  trader.strategies = [new ArbitrageStrategy({ relations: { implications: [], pairs: [] } })];
  trader.settings.strategies = new Set(['arbitrage']);
  const alerts = [];
  trader.on('risk_event', (e) => alerts.push(e));
  const real = trader.broker.submit.bind(trader.broker);
  let n = 0;
  trader.broker.submit = async (o, q) => (++n === 2 ? { ok: false, filled: 0, status: 'canceled', note: 'no fill' } : real(o, q));
  trader.setTrading(true, 'test');
  await trader.cycle();
  assert.equal(alerts.some((a) => a.kind === 'partial_basket' && /stop-loss protection is ACTIVE/.test(a.reason)), true);
  const held = ledger.positionList();
  assert.equal(held.length, 1, 'only the first leg filled');
  assert.equal(held[0].hold, false, 'unhedged leg is NOT exempt from stop-loss');
  client.setMarket(held[0].ticker, { no_bid_dollars: '0.3500', yes_ask_dollars: '0.6500' }); // leg loses ~40%
  await trader.cycle();
  assert.equal(ledger.positionList().length, 0, 'stop-loss closed the orphan leg');
  assert.ok(ledger.s.closed.at(-1).reason === 'stop_loss');
});

test('D14 an exception thrown by the broker is contained, reported and cannot abort the cycle', async () => {
  const { trader, ledger } = await rig(ev2(rawMarket('X', { event: 'E', yesBid: 0.5, yesAsk: 0.52 })));
  await ledger.applyBuy({ ticker: 'X', eventTicker: 'E', title: 'X', side: 'yes', qty: 10, price: 0.52, fee: 0 });
  trader.broker.submit = async () => { throw new TypeError('boom'); };
  const alerts = [];
  const errors = [];
  trader.on('risk_event', (e) => alerts.push(e));
  trader.on('bot_error', (e) => errors.push(e));
  trader.setTrading(true, 'test');
  trader.settings.v.stopLoss = 0.005;
  trader.client.setMarket('X', { yes_bid_dollars: '0.3000', yes_ask_dollars: '0.3200', no_bid_dollars: '0.6800', no_ask_dollars: '0.7000' });
  await trader.cycle();
  assert.equal(errors.length, 0, 'the cycle itself completed');
  assert.ok(alerts.some((a) => a.kind === 'order_error' && /boom/.test(a.reason)));
  assert.equal(ledger.positionList().length, 1, 'position untouched: the exit did not happen');
});

test('D15 broker: an unreadable response AFTER a successful POST is reported as "unknown", never thrown', async () => {
  const { KalshiBroker } = await import('../src/engine/broker.js');
  const client = { createOrder: async () => ({ order: null }), getOrder: async () => { throw new Error('x'); } };
  const r = await new KalshiBroker({ client, logger: silentLogger }).submit({ ticker: 'T', side: 'yes', action: 'buy', count: 1, limitPrice: 0.5, clientOrderId: 'c' });
  assert.equal(r.ok, false);
  assert.equal(r.status, 'unknown');
  assert.match(r.note, /order sent/);
});

test('D16 the trader raises an immediate alert when an order outcome is unknown', async () => {
  const { trader, ledger } = await rig(ev2(rawMarket('X', { event: 'E', yesBid: 0.5, yesAsk: 0.52 })));
  await ledger.applyBuy({ ticker: 'X', eventTicker: 'E', title: 'X', side: 'yes', qty: 10, price: 0.52, fee: 0 });
  trader.broker.submit = async () => ({ ok: false, filled: 0, status: 'unknown', note: 'order sent; response unreadable' });
  const alerts = [];
  trader.on('risk_event', (e) => alerts.push(e));
  trader.setTrading(true, 'test');
  trader.client.setMarket('X', { yes_bid_dollars: '0.3000', yes_ask_dollars: '0.3200', no_bid_dollars: '0.6800', no_ask_dollars: '0.7000' });
  await trader.cycle();
  assert.ok(alerts.some((a) => a.kind === 'order_unknown' && /X/.test(a.reason)));
  assert.equal(ledger.positionList().length, 1, 'ledger is not changed on an unknown outcome');
});
