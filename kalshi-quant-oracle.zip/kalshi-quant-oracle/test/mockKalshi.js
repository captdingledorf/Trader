// A small but strict stand-in for Kalshi's Trade API v2 used by the end-to-end tests.
// It VERIFIES request signatures (RSA-PSS or Ed25519) with the matching public key, enforces the order-body
// contract the broker must satisfy, and matches IOC taker orders against the quotes — so the real KalshiClient,
// KalshiBroker, signing and reconciliation code run over genuine HTTP. It encodes MY reading of Kalshi's docs,
// so it proves integration correctness, not that Kalshi agrees (that is what `npm run smoke:demo` is for).
import http from 'node:http';
import { verifySignature } from '../src/kalshi/auth.js';
import { takerFee } from '../src/util/money.js';

export const KEY_ID = 'TESTKEY';
const BASE = '/trade-api/v2';

export async function startMockKalshi({ publicKey, keyType = 'rsa', events, balanceCents = 100000, depth = 50 }) {
  const st = { balanceCents, positions: new Map(), orders: [], cids: new Set(), log: [], events, rejectStyles: new Set() };
  const markets = () => events.flatMap((e) => e.markets.map((m) => ({ e, m })));
  const find = (t) => markets().find((x) => x.m.ticker === t);
  const dollars = (m, k) => Number(m[`${k}_dollars`]);

  const send = (res, code, obj) => {
    const b = JSON.stringify(obj);
    res.writeHead(code, { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(b) });
    res.end(b);
  };
  const body = (req) => new Promise((r) => { const c = []; req.on('data', (d) => c.push(d)); req.on('end', () => r(c.length ? JSON.parse(Buffer.concat(c)) : {})); });

  const server = http.createServer(async (req, res) => {
    const url = new URL(req.url, 'http://x');
    const path = url.pathname;
    const rel = path.startsWith(BASE) ? path.slice(BASE.length) : null;
    const entry = { method: req.method, path, query: Object.fromEntries(url.searchParams), authed: false };
    st.log.push(entry);
    if (rel === null) return send(res, 404, { error: { message: 'not found' } });
    if (rel.startsWith('/portfolio')) {
      const ts = req.headers['kalshi-access-timestamp'];
      const sig = req.headers['kalshi-access-signature'];
      const ok = req.headers['kalshi-access-key'] === KEY_ID && ts && sig && Math.abs(Date.now() - Number(ts)) < 60000 && (() => { try { return verifySignature(publicKey, keyType, sig, ts, req.method, path); } catch { return false; } })();
      if (!ok) return send(res, 401, { error: { message: 'invalid signature' } });
      entry.authed = true;
    }
    try {
      if (rel === '/exchange/status') return send(res, 200, { exchange_active: true, trading_active: true });
      if (rel === '/events') return send(res, 200, { events: st.events.map((e) => ({ event_ticker: e.event_ticker, title: e.title, mutually_exclusive: e.mutually_exclusive, markets: e.markets })), cursor: '' });
      let m;
      if ((m = rel.match(/^\/markets\/([^/]+)\/orderbook$/))) {
        const f = find(decodeURIComponent(m[1]));
        if (!f) return send(res, 404, { error: { message: 'no market' } });
        return send(res, 200, { orderbook_fp: { yes_dollars: [[f.m.yes_bid_dollars, depth.toFixed(2)]], no_dollars: [[f.m.no_bid_dollars, depth.toFixed(2)]] } });
      }
      if ((m = rel.match(/^\/markets\/([^/]+)$/))) {
        const f = find(decodeURIComponent(m[1]));
        return f ? send(res, 200, { market: { event_ticker: f.e.event_ticker, ...f.m } }) : send(res, 404, { error: { message: 'no market' } });
      }
      if (rel === '/portfolio/balance') return send(res, 200, { balance: st.balanceCents, portfolio_value: 0 });
      if (rel === '/portfolio/positions') {
        return send(res, 200, { market_positions: [...st.positions].filter(([, v]) => v !== 0).map(([ticker, v]) => ({ ticker, position: v, market_exposure: 0, realized_pnl: 0 })) });
      }
      if (rel === '/portfolio/orders' && req.method === 'GET') return send(res, 200, { orders: st.orders });
      if ((m = rel.match(/^\/portfolio\/orders\/([^/]+)$/)) && req.method === 'GET') {
        const o = st.orders.find((x) => x.order_id === m[1]);
        return o ? send(res, 200, { order: o }) : send(res, 404, { error: { message: 'no order' } });
      }
      if (rel === '/portfolio/orders' && req.method === 'POST') return send(res, ...(await createOrder(await body(req))));
      return send(res, 404, { error: { message: 'unknown route' } });
    } catch (e) {
      return send(res, 500, { error: { message: e.message } });
    }
  });

  async function createOrder(b) {
    const must = (c, msg) => { if (!c) throw Object.assign(new Error(msg), { code: 400 }); };
    try {
      must(b.ticker && ['buy', 'sell'].includes(b.action) && ['yes', 'no'].includes(b.side), 'ticker/action/side');
      must(b.type === 'limit' && b.time_in_force === 'immediate_or_cancel', 'type/time_in_force');
      must(/^[0-9a-f-]{36}$/.test(b.client_order_id ?? ''), 'client_order_id must be a UUID');
      const fixed = 'count_fp' in b;
      const priceKey = `${b.side}_price`;
      if (fixed) { must(/^\d+\.\d{2}$/.test(b.count_fp), 'count_fp format'); must(/^0\.\d{4}$|^1\.0000$/.test(b[`${priceKey}_dollars`] ?? ''), 'price dollars format'); }
      else { must(Number.isInteger(b.count) && Number.isInteger(b[priceKey]), 'legacy ints'); }
      const style = fixed ? 'fixed' : 'legacy';
      if (st.rejectStyles.has(style)) throw Object.assign(new Error(`${style} fields not accepted`), { code: 400 });
      if (st.cids.has(b.client_order_id)) throw Object.assign(new Error('duplicate client_order_id'), { code: 409 });
      st.cids.add(b.client_order_id);
      const count = fixed ? Number(b.count_fp) : b.count;
      const limit = fixed ? Number(b[`${priceKey}_dollars`]) : b[priceKey] / 100;
      const f = find(b.ticker);
      must(f, 'unknown ticker');
      const ask = dollars(f.m, `${b.side}_ask`);
      const bid = dollars(f.m, `${b.side}_bid`);
      const pos = st.positions.get(b.ticker) ?? 0;
      let filled = 0;
      let px = 0;
      if (b.action === 'buy' && limit >= ask - 1e-9) { filled = Math.min(count, depth); px = ask; }
      if (b.action === 'sell' && limit <= bid + 1e-9) { px = bid; filled = Math.min(count, Math.abs(b.side === 'yes' ? Math.max(pos, 0) : Math.max(-pos, 0))); }
      const fee = takerFee(filled, px);
      if (filled > 0) {
        const signed = (b.side === 'yes' ? 1 : -1) * (b.action === 'buy' ? 1 : -1) * filled;
        st.positions.set(b.ticker, pos + signed);
        st.balanceCents += Math.round((b.action === 'buy' ? -1 : 1) * (filled * px + (b.action === 'buy' ? fee : -fee)) * 100) * (b.action === 'buy' ? 1 : 1);
      }
      const order = { order_id: `ord-${st.orders.length + 1}`, ticker: b.ticker, client_order_id: b.client_order_id, side: b.side, action: b.action, status: filled > 0 ? 'executed' : 'canceled', initial_count_fp: count.toFixed(2), fill_count_fp: filled.toFixed(2), remaining_count_fp: '0.00', taker_fill_cost_dollars: (filled * px).toFixed(4), taker_fees_dollars: fee.toFixed(4) };
      st.orders.push(order);
      return [201, { order }];
    } catch (e) {
      return [e.code ?? 500, { error: { message: e.message } }];
    }
  }

  await new Promise((r) => server.listen(0, '127.0.0.1', r));
  const port = server.address().port;
  return {
    state: st,
    port,
    url: `http://127.0.0.1:${port}${BASE}`,
    setMarket(ticker, patch) { Object.assign(find(ticker).m, patch); },
    close: () => new Promise((r) => { server.closeAllConnections?.(); server.close(r); }),
  };
}

/** Minimal Telegram Bot API stand-in: queues updates for getUpdates, records sendMessage calls. */
export async function startMockTelegram({ token = '123456:TESTTOKENTESTTOKENTESTTOKEN12345' } = {}) {
  const st = { updates: [], sent: [], calls: [], nextId: 1 };
  const server = http.createServer(async (req, res) => {
    const m = req.url.match(/^\/bot([^/]+)\/(\w+)/);
    const c = [];
    req.on('data', (d) => c.push(d));
    await new Promise((r) => req.on('end', r));
    const b = c.length ? JSON.parse(Buffer.concat(c)) : {};
    const out = (result) => { const s = JSON.stringify({ ok: true, result }); res.writeHead(200, { 'Content-Type': 'application/json' }); res.end(s); };
    if (!m || m[1] !== token) { res.writeHead(401); return res.end(JSON.stringify({ ok: false, description: 'Unauthorized' })); }
    st.calls.push(m[2]);
    if (m[2] === 'getMe') return out({ id: 1, is_bot: true, username: 'mockbot' });
    if (m[2] === 'sendMessage') { st.sent.push(b); return out({ message_id: st.sent.length }); }
    if (m[2] === 'getUpdates') {
      const wait = Date.now() + Math.min((b.timeout ?? 0) * 1000, 400);
      while (Date.now() < wait && !st.updates.some((u) => u.update_id >= (b.offset ?? 0))) await new Promise((r) => setTimeout(r, 20));
      return out(st.updates.filter((u) => u.update_id >= (b.offset ?? 0)));
    }
    return out(true);
  });
  await new Promise((r) => server.listen(0, '127.0.0.1', r));
  return {
    state: st,
    token,
    url: `http://127.0.0.1:${server.address().port}`,
    say(text, userId) { st.updates.push({ update_id: st.nextId++, message: { text, date: Math.floor(Date.now() / 1000), from: { id: userId }, chat: { id: userId, type: 'private' } } }); },
    close: () => new Promise((r) => { server.closeAllConnections?.(); server.close(r); }),
  };
}
