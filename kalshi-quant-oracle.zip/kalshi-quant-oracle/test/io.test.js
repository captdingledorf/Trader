import test from 'node:test';
import assert from 'node:assert/strict';
import path from 'node:path';
import { EventEmitter } from 'node:events';
import { TelegramBot, formatEvent, esc } from '../src/telegram/bot.js';
import { createApiServer } from '../src/api/server.js';
import { loadConfig, ConfigError, coerceSetting, SettingsStore } from '../src/config.js';
import { silentLogger, tmpDir, FakeSettings } from './helpers.js';

/* ── Telegram ───────────────────────────────────────────────────── */
function stubTrader({ live = false } = {}) {
  const t = new EventEmitter();
  Object.assign(t, {
    trading: false,
    halted: false,
    haltText: '',
    closed: 0,
    ledger: { positionList: () => [1, 2] },
    status: () => ({ trading: t.trading, halted: t.halted, haltReason: t.haltText, mode: live ? 'live' : 'paper', kalshiEnv: live ? 'prod' : 'demo', lastUpdate: new Date().toISOString(), uptime: '0h 1m', apiConnected: true, activeStrategies: ['arbitrage'], tradesCount: 3, openPositions: 2, cycle: { error: null } }),
    balanceView: () => ({ available: 900, totalEquity: 1010, unrealizedPnL: 10, todayPnL: 5, mode: 'paper' }),
    positionsView: () => [{ side: 'yes', ticker: 'T-1', quantity: 5, entryPrice: 0.4, currentPrice: 0.45, pnl: 0.25 }],
    performanceView: () => ({ totalReturn: 1, sharpeRatio: null, maxDrawdown: 0.5, winRate: 50, totalTrades: 4, avgTrade: 1, bestTrade: 3, worstTrade: -1 }),
    setTrading(on) {
      t.trading = on;
    },
    resume() {
      t.halted = false;
    },
    async closeAll() {
      t.closed += 1;
      return 2;
    },
  });
  return t;
}

function tgRig({ allowed = ['42'], live = false } = {}) {
  const sent = [];
  const fetchImpl = async (url, init) => {
    const method = String(url).split('/').pop();
    const body = JSON.parse(init.body);
    if (method === 'sendMessage') sent.push(body);
    return { ok: true, json: async () => ({ ok: true, result: method === 'getMe' ? { username: 'testbot' } : [] }) };
  };
  const trader = stubTrader({ live });
  const settings = new FakeSettings();
  const cfg = { dataDir: tmpDir(), live, kalshiEnv: live ? 'prod' : 'demo', mode: live ? 'live' : 'paper' };
  const bot = new TelegramBot({ token: '123456:ABC', allowedIds: allowed, trader, settings, cfg, logger: silentLogger, fetchImpl, minIntervalMs: 0 });
  return { bot, sent, trader, settings };
}
const msg = (text, { id = 42, type = 'private', date = Math.floor(Date.now() / 1000) } = {}) => ({ update_id: 1, message: { text, date, from: { id }, chat: { id, type } } });
const press = (data, id = 42) => ({ update_id: 2, callback_query: { id: 'cb', data, from: { id }, message: { chat: { id, type: 'private' } } } });

test('telegram: allowlist — strangers and group chats get no reply at all', async () => {
  const { bot, sent } = tgRig();
  await bot.handleUpdate(msg('/status', { id: 999 }));
  await bot.handleUpdate(msg('/start_trading', { id: 999 }));
  await bot.handleUpdate(msg('/status', { type: 'group' }));
  assert.equal(sent.length, 0);
});

test('telegram: setup mode answers only /id and executes nothing', async () => {
  const { bot, sent, trader } = tgRig({ allowed: [] });
  await bot.handleUpdate(msg('/start_trading', { id: 7 }));
  assert.equal(trader.trading, false);
  assert.equal(sent.length, 0);
  await bot.handleUpdate(msg('/id', { id: 7 }));
  assert.match(sent[0].text, /TELEGRAM_CHAT_ID=7/);
});

test('telegram: allowed user gets status/balance/positions/performance/settings/help; stale messages are dropped', async () => {
  const { bot, sent } = tgRig();
  for (const c of ['/status', '/balance', '/positions', '/performance', '/settings', '/help']) await bot.handleUpdate(msg(c));
  assert.equal(sent.length, 6);
  assert.match(sent[0].text, /Bot status/);
  assert.match(sent[1].text, /Equity/);
  assert.match(sent[4].text, /maxPositionSize/);
  await bot.handleUpdate(msg('/status', { date: Math.floor(Date.now() / 1000) - 600 }));
  assert.equal(sent.length, 6, 'replay guard ignores 10-minute-old commands');
});

test('telegram: paper start is immediate; real-money start needs a fresh confirmation button', async () => {
  const paper = tgRig();
  await paper.bot.handleUpdate(msg('/start_trading'));
  assert.equal(paper.trader.trading, true);
  await paper.bot.handleUpdate(msg('/stop_trading'));
  assert.equal(paper.trader.trading, false);

  const live = tgRig({ live: true });
  await live.bot.handleUpdate(msg('/start_trading'));
  assert.equal(live.trader.trading, false, 'not started yet');
  const nonce = live.sent.at(-1).reply_markup.inline_keyboard[0][0].callback_data;
  assert.match(nonce, /^confirm:/);
  await live.bot.handleUpdate(press(nonce));
  assert.equal(live.trader.trading, true);
  await live.bot.handleUpdate(press(nonce));
  assert.match(live.sent.at(-1).text, /expired/, 'a confirmation is single-use');
});

test('telegram: /close_all confirms; /set validates; /strategy toggles; halted blocks start', async () => {
  const { bot, sent, trader, settings } = tgRig();
  await bot.handleUpdate(msg('/close_all'));
  assert.equal(trader.closed, 0);
  await bot.handleUpdate(press(sent.at(-1).reply_markup.inline_keyboard[0][0].callback_data));
  assert.equal(trader.closed, 1);
  await bot.handleUpdate(msg('/set stopLoss 0.07'));
  assert.equal(settings.v.stopLoss, '0.07');
  await bot.handleUpdate(msg('/strategy volatility on'));
  assert.ok(settings.isEnabled('volatility'));
  await bot.handleUpdate(msg('/strategy bogus on'));
  assert.match(sent.at(-1).text, /Usage/);
  trader.halted = true;
  trader.haltText = 'daily loss';
  await bot.handleUpdate(msg('/start_trading'));
  assert.equal(trader.trading, false);
  assert.match(sent.at(-1).text, /halted/i);
});

test('telegram: user-controlled text is HTML-escaped in notifications', () => {
  assert.equal(esc('<b>&'), '&lt;b&gt;&amp;');
  const out = formatEvent('trade_executed', { type: 'entry', strategy: 's', side: 'yes', ticker: 'T', quantity: 1, price: 0.5, event: '<script>x</script>', reason: 'a<b' });
  assert.ok(!out.includes('<script>') && out.includes('&lt;script&gt;'));
});

/* ── REST + WebSocket ───────────────────────────────────────────── */
const TOKEN = 'T'.repeat(32);
async function apiRig({ live = false } = {}) {
  const trader = stubTrader({ live });
  const settings = new FakeSettings();
  const cfg = { live, kalshiEnv: live ? 'prod' : 'demo', api: { host: '127.0.0.1', port: 0, token: TOKEN } };
  const api = createApiServer({ cfg, trader, settings, logger: silentLogger });
  const addr = await api.listen();
  const base = `http://127.0.0.1:${addr.port}`;
  const call = (p, init = {}, auth = true) => fetch(base + p, { ...init, headers: { ...(auth ? { Authorization: `Bearer ${TOKEN}` } : {}), 'Content-Type': 'application/json', ...(init.headers ?? {}) } });
  return { api, trader, settings, base, call, port: addr.port };
}

test('api: health is open; everything else needs the bearer token', async () => {
  const { api, call } = await apiRig();
  try {
    assert.equal((await call('/api/health', {}, false)).status, 200);
    assert.equal((await call('/api/status', {}, false)).status, 401);
    assert.equal((await call('/api/status', { headers: { Authorization: 'Bearer wrong' } }, false)).status, 401);
    const ok = await call('/api/status');
    assert.equal(ok.status, 200);
    assert.equal((await ok.json()).tradesCount, 3);
    assert.equal((await call('/api/nope')).status, 404);
  } finally {
    await api.close();
  }
});

test('api: control endpoints, config validation, body limits; real-money start refused over REST', async () => {
  const { api, call, trader, settings } = await apiRig();
  try {
    assert.equal((await call('/api/start-trading', { method: 'POST' })).status, 200);
    assert.equal(trader.trading, true);
    assert.equal((await call('/api/stop-trading', { method: 'POST' })).status, 200);
    assert.equal((await call('/api/config', { method: 'POST', body: JSON.stringify({ stopLoss: 0.08 }) })).status, 200);
    assert.equal(settings.v.stopLoss, 0.08);
    assert.equal((await call('/api/config', { method: 'POST', body: '{bad' })).status, 400);
    assert.equal((await call('/api/config', { method: 'POST', body: JSON.stringify({ pad: 'x'.repeat(20000) }) })).status, 413);
    const cfg = await (await call('/api/config')).json();
    assert.ok('maxPositionSize' in cfg && Array.isArray(cfg.strategies));
  } finally {
    await api.close();
  }
  const live = await apiRig({ live: true });
  try {
    assert.equal((await live.call('/api/start-trading', { method: 'POST' })).status, 403);
    assert.equal(live.trader.trading, false);
  } finally {
    await live.api.close();
  }
});

function openWs(url) {
  return new Promise((resolve, reject) => {
    const ws = new WebSocket(url);
    const inbox = [];
    ws.onmessage = (e) => inbox.push(JSON.parse(e.data));
    ws.onopen = () => resolve({ ws, inbox });
    ws.onerror = () => reject(new Error('ws rejected'));
  });
}
const until = async (fn, ms = 2000) => {
  const t0 = Date.now();
  while (Date.now() - t0 < ms) {
    if (fn()) return true;
    await new Promise((r) => setTimeout(r, 20));
  }
  return false;
};

test('websocket: token required; subscribe handshake; events are pushed in the original message shape', async () => {
  const { api, trader, port } = await apiRig();
  try {
    await assert.rejects(openWs(`ws://127.0.0.1:${port}/ws`), /rejected/);
    await assert.rejects(openWs(`ws://127.0.0.1:${port}/ws?token=nope`), /rejected/);
    const { ws, inbox } = await openWs(`ws://127.0.0.1:${port}/ws?token=${TOKEN}`);
    ws.send(JSON.stringify({ type: 'subscribe' }));
    assert.ok(await until(() => inbox.some((m) => m.type === 'subscribed')));
    trader.emit('trade_executed', { type: 'entry', ticker: 'T' });
    trader.emit('bot_error', { message: 'x' });
    assert.ok(await until(() => inbox.some((m) => m.type === 'trade_executed' && m.data.ticker === 'T')));
    assert.ok(await until(() => inbox.some((m) => m.type === 'bot_error')));
    ws.close();
  } finally {
    await api.close();
  }
});

/* ── config safety gates ────────────────────────────────────────── */
const envWith = (over) => ({ DATA_DIR: tmpDir(), ...over });

test('config: defaults are paper/demo with trading never auto-starting', async () => {
  const { cfg, settings } = await loadConfig(envWith({}));
  assert.equal(cfg.mode, 'paper');
  assert.equal(cfg.live, false);
  assert.equal(cfg.autostart, false);
  assert.match(cfg.baseUrl, /demo-api\.kalshi\.co/);
  assert.deepEqual(settings.enabledStrategies(), ['arbitrage']);
});

test('config: every unsafe combination is refused at startup', async () => {
  const bad = [
    [{ TRADING_MODE: 'live', KALSHI_ENV: 'prod', KALSHI_API_KEY_ID: 'k' }, /REAL-MONEY MODE BLOCKED/],
    [{ TRADING_MODE: 'live', KALSHI_ENV: 'demo' }, /requires KALSHI_API_KEY_ID/],
    [{ TRADING_MODE: 'yolo' }, /paper.*live/],
    [{ KALSHI_BASE_URL: 'http://api.elections.kalshi.com/trade-api/v2' }, /https/],
    [{ KALSHI_BASE_URL: 'https://evil.example.com/trade-api/v2' }, /not a kalshi/],
    [{ API_TOKEN: 'short' }, /24 characters/],
    [{ API_HOST: '0.0.0.0' }, /not loopback/],
  ];
  for (const [env, re] of bad) await assert.rejects(loadConfig(envWith(env)), (e) => e instanceof ConfigError && re.test(e.message), JSON.stringify(env));
  const ok = await loadConfig(envWith({ TRADING_MODE: 'live', KALSHI_ENV: 'prod', KALSHI_API_KEY_ID: 'k', I_UNDERSTAND_LIVE_TRADING_RISK: 'yes' }));
  assert.equal(ok.cfg.live, true);
});

test('config: setting validation and persistence (file beats env across restarts)', async () => {
  assert.equal(coerceSetting('stopLoss', '0.2').value, 0.2);
  assert.equal(coerceSetting('stopLoss', '7').ok, false);
  assert.equal(coerceSetting('maxOpenPositions', '2.5').ok, false);
  assert.equal(coerceSetting('nope', '1').ok, false);
  const dir = tmpDir();
  const a = await loadConfig({ DATA_DIR: dir, STOP_LOSS_PERCENTAGE: '0.04' });
  assert.equal(a.settings.get().stopLoss, 0.04);
  await a.settings.patch({ stopLoss: 0.09, nonsense: 1 });
  await a.settings.setStrategy('volatility', true);
  const b = await loadConfig({ DATA_DIR: dir, STOP_LOSS_PERCENTAGE: '0.04' });
  assert.equal(b.settings.get().stopLoss, 0.09);
  assert.ok(b.settings.isEnabled('volatility'));
  assert.ok(SettingsStore && path.basename(a.settings.file) === 'bot_settings.json');
});
