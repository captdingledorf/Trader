# Comprehensive audit — kalshi-quant-telebot-node v1.1.0

Auditor: the author of the port (self-audit — **not independent**; an independent review before real money is advised).
Two passes: **pass 1** (v1.0 build) and **pass 2** (adversarial re-audit + new features: dashboard, Qwen).
Scope: all source in `src/`, tests, scripts, deployment files, the dashboard and docs in this archive.

**Verdict.** Suitable for **paper trading and Kalshi-demo trading** after you pass `npm run smoke:demo` (Step 8) and look at the dashboard.
**Not recommended for real money** until: that smoke test passes on your VM, you have ≥ 2–4 weeks of paper and ≥ 1–2 weeks of demo evidence you
understand, you have confirmed Kalshi’s current fee schedule and terms, and (ideally) someone else has reviewed `src/engine/{risk,broker,trader}.js`.
The optional **Qwen** model stays in shadow mode until `npm run qwen:shadow-report` shows it beats the market price. Nothing here claims profitability.

Severity: **Critical** can lose money/secrets unexpectedly · **High** likely to mislead or cause loss if ignored · **Medium** · **Low** · **Info**.

---

## 1. Findings register

| ID | Sev | Finding | Status / mitigation |
|---|---|---|---|
| **F-01** | **High** | **Nothing was exercised against the real Kalshi API, Telegram API, Ollama/Qwen or an Oracle VM** (no network in the build sandbox). | *Narrowed in pass 2:* the whole process now runs end-to-end against strict mocks that **verify request signatures** and the order-body contract. Real-exchange acceptance remains open: `npm run smoke:demo [--place-test-order]` (Step 8). |
| **F-02** | **High** | **Paper P&L is optimistic**: instant fills at ask+1¢/bid−1¢, no queue position or latency, no impact. | Documented (Step 13). Treat paper as an *upper bound*; require a demo-exchange phase. |
| **F-03** | **High** | **Upstream source files were unreadable**; the port implements the README’s *documented* behaviour (PORT_MAP §0, §3). | Disclosed in README, NOTICE, PORT_MAP. |
| **F-04** | Medium | Home-grown WebSocket server and HTTP API surface. | Loopback bind, bearer token (timing-safe), 10-client cap, 64 KiB frames, mandatory masking, slow-consumer drop, rate limit, 16 KB body cap, clean 413/400, no inbound OCI port. **Pass 2:** WS fuzzed (300 hostile connections: no crash, server stayed healthy), half-open sockets now reaped; API fuzzed (odd bodies/methods/headers). Residual: not fuzzed at scale. |
| **F-05** | **High** | **Financial risk**: strategies unproven; fixed stops on binary markets whipsaw; Kelly depends on an estimated p. | Layered controls (ARCHITECTURE §7). Defaults conservative; arbitrage (alert-only live) is the only default-on strategy. |
| **F-06** | Medium | systemd hardening and SELinux labelling unverified on target. | Ubuntu 24.04 primary; `systemd-analyze security`; Appendix B fixes. `MemoryDenyWriteExecute` omitted (V8 JIT). |
| **F-07** | Medium | **Fee model is an assumption.** | *Checked in pass 2 against secondary sources quoting Kalshi’s fee schedule (Feb and Jul 2026 versions):* taker ≈ `0.07 × M × C × P × (1−P)`, maker `0.0175 × M` with a default maker multiplier of 0, rounded **up** (whole cent in the Feb version; reportedly to a centicent on fee+cost in the Jul version); `M` is a per-series multiplier. Our model: taker, whole-cent round-up, one global `FEE_COEFFICIENT` ⇒ **conservative** but not exact (no per-series `M`, no maker path). Step 13 still requires checking the live schedule. |
| **F-08** | Medium | **API drift.** | Kalshi’s current “Fixed-Point Representation” page (read Nov 2026) documents `*_dollars`/`*_fp`; whole-cent prices are valid on every price grid; fills may be fractional. Parsers prefer new fields, fall back to legacy; order style switchable; limit prices clamped to [0.01, 0.99] (pass 2). Blast radius: `client.js`, `broker.js`, `money.js`. |
| **F-09** | Low | Rate limits vary by Kalshi tier. | Conservative defaults, `Retry-After`, jittered GET retries. |
| **F-10** | Medium | **Strategy validity**: lexicon/GARCH heuristics unproven; cointegration of bounded prices questionable. | Shipped **off**. |
| **F-11** | Medium | **Oracle policy risk**: A1 free allowance now 2 OCPU/12 GB (page rev. 12 Jun 2026); idle reclamation can remove a quiet bot; “out of capacity” is common. | Documented (Steps 0, 10, 12); rebuildable design; alarm; optional PAYG. No artificial load shipped. |
| **F-12** | Medium | **Ledger vs exchange divergence** (lost response, partial basket, manual trades, crash mid-cycle). | Idempotent ids + 409 reconciliation; position reconciliation (alert only, cadence configurable). **Pass 2:** unknown-outcome orders raise an immediate alert instead of being read as “no fill”; broker exceptions contained; scalar/void settlements alert; persistence failure halts trading; `/close_all` can no longer race a cycle. |
| **F-13** | Low | No HA; two instances would double-trade. | Documented; Telegram 409 is a tripwire. |
| **F-14** | Low | Supply chain: zero npm deps; Node from nodejs.org with HTTPS-sourced SHA-256 (no GPG check); root `curl` installers (Node tarball, optional Ollama). | Read the scripts first; stricter provenance options in §7. |
| **F-15** | Low | Upstream licence unconfirmed (README says MIT, no LICENSE file). | NOTICE; no upstream source copied or read. |
| **F-16** | Info | Defects found and fixed during build and re-audit. | §4 (28). |
| **F-17** | Medium | Terms/legality of automated trading are the user’s responsibility. | Step 13; LICENSE disclaimer. |
| **F-18** | Low | Clock skew breaks request signing. | Step 3; the mock exchange rejects a 10-minute skew like the real one should. |
| **F-19** | Info | Developer-support comment blocks (owner’s request) at the end of 7 source files; comments only. The “Coinbase” entry supplied is an **e-mail address, not a Bitcoin address**. | Remove freely. |
| **F-20** | **High → fixed** | **A hostile or corrupt RSS feed froze the event loop**: four regexes were quadratic (1 MB inputs took 37 s; an 80 000-fold unclosed CDATA took 76 s of CPU while the trading loop, Telegram polling and exits share that thread). Also unbounded response buffering and a `RangeError` on absurd numeric entities. | Parser rewritten with `indexOf` scans (milliseconds on every probe), byte/item/field caps, **streamed capped reads** for feeds and Kalshi responses, safe code-point decoding. Regression tests use the same hostile inputs. |
| **F-21** | Medium | **LLM-in-the-loop risks (Qwen):** prompt injection via headlines, wrong stance, hung model, headlines leaving the machine, over-trust in “confidence”. | Shadow-by-default; sanitised + capped untrusted text in data tags; schema-constrained **and** re-validated/clamped output; ±10-point bound; ≥ 2 independent sources; background worker + timeout + circuit breaker; loopback-only; falsifiable `shadow-report`. **Unverified against a real Qwen** (docs/QWEN.md L1–L2). Mutants for sanitiser, shadow mode, min-sources, clamps, breaker all caught. |
| **F-22** | Medium | **Dashboard attack surface** (XSS via market titles/headlines/logs; token handling; clickjacking; CSP breakage). | Page public but empty; all data needs the bearer token (sessionStorage only); strict **hash-based CSP** (no `unsafe-inline`; 11 inline `style=""` attributes that the CSP would have blocked were removed); all dynamic text via `textContent`; charts from numbers only; `frame-ancestors 'none'`; hostile-payload test through every widget. **Never opened in a real browser by the author.** |
| **F-23** | Medium → fixed | Setting keys were validated with `in`: `constructor`, `toString`, `__proto__` passed validation and were written to the settings store (and file). | `Object.hasOwn`; API ignores prototype-chain keys; tests. |
| **F-24** | Medium → fixed | **Invalid explicit env values silently became defaults** (`AUTOSTART_TRADING=ture`, `SCAN_MAX_PAGES=three`, `STOP_LOSS_PERCENTAGE=5`). | Strict parsing: startup aborts naming the variable; ranges enforced; unknown strategy names, bad IDs, bad URLs refused. |
| **F-25** | **High → fixed** | `AUTOSTART_TRADING=true` was allowed with real money, contradicting the documented “trading is OFF after every restart; real money only via the Telegram confirmation”. | Refused at startup for `live`+`prod`. |
| **F-26** | Medium → fixed | **Execution-state integrity:** legs of a *partial* arbitrage basket were exempt from stop-loss (unhedged yet unprotected); an unreadable 2xx order response was read as “no fill” (a live order could be orphaned); a throwing broker aborted the cycle; trading continued when state could not be saved; `/resume` could never stick. | Exemption applied only once the basket completes; “unknown” outcome + alert; `#submit` containment; 3 failed saves ⇒ halt; `/resume` re-baselines loss/drawdown. Tests D7–D16. |
| **F-27** | Info | **Primary-source checks (pass 2):** Oracle Always Free page (rev. 12 Jun 2026, read twice); Kalshi docs on auth, create-order, fixed-point/price grids; Ollama library sizes (registry mirror). | Results recorded where used; Kalshi fee details come from secondary sources quoting the schedule (see F-07). |
| **F-28** | Low | Loopback-only test hooks exist in production code (`KALSHI_BASE_URL`, `TELEGRAM_API_URL`, `QWEN_URL` may be `http://127.0.0.1`). | Deliberate: loopback traffic cannot leave the host; any non-loopback value must be https on the documented hosts or startup aborts (tested). |
| **F-29** | Medium | **Qwen’s multilingual strength is only partly realised**: candidate pairing uses lexical overlap on ASCII tokens, so most non-English headlines never reach the model; stance is per headline, not per article; “independent sources” counts hostnames, not originality. | Documented (docs/QWEN.md L3–L6); LLM-based pairing is future work. |
| **F-30** | Low | Fee model is global (`FEE_COEFFICIENT`); no per-series multipliers, no maker orders. | See F-07; conservative by construction. |

## 2. Security review

| Area | Check | Result |
|---|---|---|
| Secrets at rest | Kalshi key `root:root 600` via systemd `LoadCredential`; none in env/`DATA_DIR`/ZIP/logs | ✅ by design (unverified on a live VM) |
| Secrets in logs | PEM, bot token, bearer, signature headers redacted; e2e asserts no key/token in process output | ✅ tested |
| Telegram authZ | numeric-ID allowlist, private chats only, strangers get **no reply** (verified over real HTTP against a mock Telegram), setup mode executes nothing, replay guard, single-use confirmations | ✅ tested |
| REST authN | bearer (≥ 24 chars), timing-safe, off without token; real-money start impossible over REST; non-object bodies → 400 | ✅ tested |
| Dashboard | public shell, token-gated data, hash CSP, text-only rendering, SVG well-formedness, frame denial | ✅ tested via DOM shim + real API (no real browser) |
| WebSocket | pre-upgrade auth, masked frames, caps, heartbeat, half-open reaping | ✅ tested + fuzzed |
| Injection / DoS | hostile feeds (linear parser, caps), hostile LLM output (strict extraction, clamps), hostile settings keys, oversized bodies/responses | ✅ tested (timings in §6) |
| LLM | untrusted text sanitised and wrapped; no tools/memory; bounded impact; shadow default; loopback only | ✅ tested with mock model; ⚠ real model unverified |
| Egress | Kalshi URL restricted (https `*.kalshi.com/.co`, or loopback); feeds https; Telegram base restricted | ✅ tested |
| Process isolation | unprivileged user, read-only FS, no capabilities, memory cap, code root-owned | ⚠ unverified on target (F-06) |
| Dependencies | none (runtime or dev) | ✅ |
| Crypto | RSA-PSS (SHA-256, salt = digest) and Ed25519 via Node `crypto`; **server-side verification in the mock** accepts good signatures and rejects wrong key / ID / skew | ✅ (real-server acceptance pending, F-01) |
| Fail-safe defaults | paper; trading OFF after start; real money needs ack + no autostart; baskets alert-only live; Qwen shadow | ✅ tested |

## 3. Correctness review

* **Units/prices.** Dollars internally; `*_dollars`/`*_fp` preferred, legacy fallback (both shapes normalise identically); whole-cent order prices clamped to [0.01, 0.99]; fractional fills supported.
* **Kelly / fees / arbitrage identities** as in v1.0 (tested); worked numbers in THESIS §3.
* **Accounting.** Fee-inclusive basis, partial sells, settlement win/loss, restart persistence; `/resume` re-baselines; scalar/void results alert.
* **Statistics.** OLS/ADF/Engle-Granger/GARCH on seeded data; shadow report detects an informative model and does not flatter a noise model (seeded, n = 300).
* **Idempotency / retries.** UUID `client_order_id`; POST never auto-retried; unreadable POST answers become `unknown` + alert; reads aborted on shutdown, orders never.
* **Concurrency.** one cycle at a time; `/close_all` shares the mutex; Qwen calls serialised.

## 4. Defects found and fixed (28)

**Pass 1** — (1) oversized API body → connection reset · (2) **process exited silently when neither Telegram nor API was configured** (`unref`’d heartbeat) · (3) `npm test` found nothing on Node ≥ 21 · (4) reconcile failure aborted the cycle ·
(5) shutdown waited on hung reads · (6) systemd `EnvironmentFile` overrides `Environment=` (DATA_DIR trap) · (7) paper-broker fill-size nonsense · (8) test bug (lexicon).

**Pass 2** — (9) **quadratic RSS parsing (37–76 s per hostile MB)** · (10) `RangeError` on huge numeric entities · (11) prototype-chain setting keys accepted · (12) API 500 on `null`/array bodies · (13) WebSocket half-open clients lingered ·
(14) invalid env values silently defaulted · (15) empty `KALSHI_API_KEY_ID` shadowed the `KALSHI_API_KEY` alias · (16) **autostart allowed with real money** · (17) `/resume` could never stick · (18) scalar/void settlements left ghost positions, duplicate settle events ·
(19) `/close_all` could race a cycle (double sell) · (20) trading continued when state could not be saved · (21) partial baskets exempt from stop-loss · (22) broker exceptions aborted cycles; unreadable POST answer read as “no fill” ·
(23) limit price 1.00 possible · (24) unbounded response buffering (+ heap sizing) · (25) installer: OL9 `curl-minimal` conflict, literal colour escapes, empty-file idiom · (26) `.env` loader expanded `\n` in every value ·
(27) dashboard: malformed SVG (bare `&` in an aria-label), 11 inline styles a CSP would block, hostile string used as a CSS class, unsanitised count interpolation · (28) dead exports and cruft.

## 5. Operational review

| Topic | Assessment |
|---|---|
| Observability | journald, `/status` (+ risk, reconcile), dashboard, Telegram risk events (`halt`, `partial_basket`, `position_mismatch`, `order_unknown`, `order_error`, `unsettleable`), OCI alarm recipe |
| Recovery | restart-on-failure with trading OFF, atomic state, daily archives, 10-minute rebuild |
| Capacity | idle RSS ≈ 64 MB (Node 22 sandbox); 100 GARCH fits ≈ 0.27 s; heap 256 MB / unit cap 512 MB; Qwen needs the A1 shape (model 1.4–2.5 GB + runtime) |
| Change management | idempotent installer; manifest hashes every file (`--check`) |
| Cost | $0 on Always Free; keep a budget alert if you ever upgrade |

## 6. Verification evidence (what actually ran)

```
npm test                    → 92 tests, 92 pass, 0 fail  (core 12 · engine 21 · io 12 · e2e 7 · hardening 18 · qwen 15 · ui 7; no external network)
e2e (real HTTP, whole process): signed requests verified server-side (RSA-PSS + Ed25519; wrong key / wrong ID / 10-min skew → 401); IOC broker payloads (fixed/legacy), no-fill,
                              duplicate-id reconciliation, style rejection; paper process finds + paper-trades the basket and sends NO order; live-demo process places 3 signed
                              orders, reconciles (0 mismatches), then flags an outside position without placing any order; Telegram (stranger ignored, status reply,
                              notifications); dashboard + CSP + data endpoints; clean SIGTERM with state persisted
mutation check              → 20 deliberately broken variants of safety-critical code (allowlist, real-money gate, stop-loss, breaker, hold flag, REST auth, signature path, paper mode,
                              sanitiser, shadow mode, min-sources, clamps, circuit breaker, CSP, key validation, WS reaping, response cap, autostart, innerHTML) → 20/20 caught
                              (one survived at first — UI titles via innerHTML — and a test was added)
hostile-input probes        → RSS parser: 37 291 ms → 3 ms (unclosed <item> ×170k), 33 690 → 3 ms (unclosed <title>), 76 618 → 4 ms (unclosed CDATA ×80k); WS fuzz: 300 hostile connections, no crash
node scripts/lint-syntax.mjs → 40/40 files pass node --check ; bash -n on bootstrap.sh, install-ollama.sh, backup.sh ; static scan: 0 unused imports
installer logic (isolated)  → tarball regex picks node-v24.*-linux-{x64,arm64}.tar.xz; SHA-256 accepts a good file and rejects a tampered one
UI                          → page script run in a Node VM: demo + live (against the real API) render every widget; all SVG well-formed; hostile payloads inert; CSP hashes match
```
Test environment: Node v22.22.2 (x86_64, 4 GB). No Node-24-only APIs are used; `engines` declares ≥ 24.

**Not run:** real Kalshi / Telegram / Ollama / Qwen calls · a real browser · an OCI VM, systemd unit, SELinux · Docker build · soak/load/large-scale fuzz · any backtest · Node 24.

## 7. Recommendations before real money

1. Step 8 smoke test; fix what it flags. 2. Open the dashboard and report visual problems. 3. Paper ≥ 2–4 weeks; demo ≥ 1–2 weeks. 4. Confirm fee schedule/terms/jurisdiction (F-07, F-17).
5. Start tiny; keep `ARBITRAGE_AUTOEXEC=false`; keep Qwen in shadow until `qwen:shadow-report` justifies otherwise. 6. Independent review of risk/broker/trader. 7. For stricter provenance, verify Node’s
`SHASUMS256.txt.sig` and read Ollama’s installer before running it. 8. Consider OCI Vault for secrets and an off-box backup target. 9. Obtain the upstream source and close PORT_MAP §3.
