# Architecture and design rationale

Code comments cite sections of this file (`ARCHITECTURE §"The trading cycle"`, `§"Risk layers"`, …). Each decision is
recorded as **chain of thought** (the reasoning that led to it) and **tree of thought** (the alternatives that were
considered and why they lost). "✗" = rejected, "✓" = chosen.

## 1. Constraints that shaped everything

| Constraint | Source | Consequence |
|---|---|---|
| 1 GB RAM, 1/8 OCPU burst (Micro) — or 2 OCPU/12 GB (A1) | Oracle Always Free page | one process, no ML stack, bounded buffers |
| Idle reclamation may remove the VM | same page | state must be small, atomic, backup-able; rebuild in ~10 min |
| Real money on the other end | the domain | fail safe: paper default, trading OFF after start, halts, allowlist |
| No outbound network in the build sandbox | build environment | everything testable offline; real-API proof deferred to `smoke:demo` |
| Original source unreadable | GitHub tooling | implement the *documented* behaviour; catalogue differences (PORT_MAP) |
| User preference: Node ≥ 24, deployable to Oracle | request | ESM, `engines.node >=24`, no native modules (runs on x64 **and** arm64) |

## 2. Process model

*Chain of thought.* The original ran a Python trading engine, a Node REST/WebSocket server and a Node Telegram bot,
connected by child processes and local sockets. On a 1 GB VM that means three runtimes' baseline memory, two IPC
channels that can fail independently, and a supervisor to babysit them.
*Tree.* ✗ keep three processes (RAM, IPC failure modes) · ✗ Python-only rewrite (Telegram + WS + REST would need
packages; heavy deps) · ✓ **single Node 24 process** (built-in `fetch`, `crypto`, `http`, `node:test`; V8 handles
the I/O-bound workload comfortably).
*Consequence.* A crash takes everything down together — acceptable, because systemd restarts it in 10 s with trading OFF and
all state is on disk.

## 3. Zero dependencies

*Chain of thought.* The bot holds an exchange private key. Every npm package is code that runs with that key in memory;
transitive dependency compromises are a real class of incident. Node 24 provides HTTP client, crypto (RSA-PSS, Ed25519),
WebSocket *client*, test runner, and `AbortSignal.any`. What it lacks: a WebSocket *server* and numeric/statistics libraries.
*Tree.* ✗ `ws` + `telegraf` + `node-fetch` + `mathjs` (≥ 100 transitive packages) · ✗ vendored copies (still unaudited code) ·
✓ **write the ~120-line WS hub and ~150 lines of statistics ourselves, with tests** (`src/util/wsHub.js`, `src/util/stats.js`).
*Cost.* The WS hub supports only single-frame text messages; documented in AUDIT F-04.

## 4. The trading cycle  <a id="the-trading-cycle"></a>

```
every tradeInterval s (setTimeout chain, never overlapping):
  1 exchange status ── public GET /exchange/status; honours exchange/trading halts
  2 live only: cash ← exchange balance; every 3rd cycle: reconcile exchange vs ledger positions (ALERT only)
  3 scan ───────────── GET /events?with_nested_markets (≤ SCAN_MAX_PAGES), + per-ticker quotes for holdings
  4 settle ─────────── status ∈ {determined, finalized, settled} + result → ledger.settle()
  5 mark-to-market ─── value at the BID; update peak for trailing stops
  6 halt check ─────── daily loss ≥ maxDailyLoss×bankroll  or  drawdown ≥ maxDrawdown  → halted (manual /resume)
  7 exits ───────────── stop-loss / trailing / time stop        (only while trading, or EXITS_WHEN_STOPPED)
  8 entries ─────────── strategies → signals ranked by edge×confidence → risk-sized execution (≤ N per cycle)
  9 persist + emit ──── atomic ledger write; events → Telegram + WebSocket
```
*Chain of thought on ordering.* Settlement before exits (don't stop-loss a market that already resolved); halt check
before entries but **not** before exits (a halt must not trap you in a losing position); reconcile before scan (stale
ledger must not drive decisions); exchange-status first (cheapest call, and it proves connectivity).
*Tree on scheduling.* ✗ `setInterval` (a slow cycle would overlap the next → double orders) · ✗ cron-style external
trigger (more moving parts) · ✓ self-rescheduling `setTimeout` + `busy` guard. The timer is **ref'd** — an unref'd one made the
process exit silently when neither Telegram nor the API was configured (bug found during review, regression-tested).

## 5. Exchange adapter  <a id="exchange-adapter"></a>

*Chain of thought.* The only parts of the program that know Kalshi's wire format are `src/kalshi/client.js` (reads,
normalisers), `src/engine/broker.js` (order payload + fill parsing) and `src/util/money.js` (units). Kalshi has been
migrating its schema (fixed-point `*_dollars`/`*_fp` fields; a newer order model with `bid`/`ask` sides exists in
SDKs). Keeping the blast radius to three small files makes the next migration a one-file change.
Normalisers **prefer new fields and fall back to legacy ones**, so either vintage of response parses identically (tested).
*Order semantics.* IOC taker orders; idempotency via `client_order_id`; POST never auto-retried; a 409 is reconciled by
lookup; fill price comes from the order's reported fill cost, else conservatively the limit. *Shutdown.* `abortAll()`
cancels READS only — an in-flight order must finish so the ledger records it.
*Tree on order type.* ✗ resting limit orders (queue, cancel/amend, partial-fill state machine) · ✗ market orders (not a
Kalshi primitive; price risk) · ✓ marketable limit + IOC (bounded price, no residual state).

## 6. Ledger  <a id="ledger"></a>

The bot keeps **its own** book in paper *and* live mode. *Chain of thought:* identical strategy/risk code in both modes;
survives a Kalshi portfolio-endpoint outage; lets stop-loss know *our* cost basis (fees included). In live mode cash is
overwritten from the exchange (truth) and positions are *compared*, never silently overwritten — with real money, a
discrepancy needs a human, because guessing which side is right can double a mistake. Marks use the **bid** (what we can
actually sell into), not the mid. State is per mode so a switch can't mix books.

## 7. Risk layers  <a id="risk-layers"></a>

```
L0 mode gate           paper | live+demo | live+prod(+explicit ack)         config.js
L1 halts               daily-loss, drawdown → block NEW entries until /resume  risk.haltReason
L2 portfolio caps      max positions · per-event concentration (2× cap) · return-correlation limit
L3 position sizing     fractional Kelly net of fees · maxPositionSize · maxOrderContracts · cash
L4 exits               stop-loss · trailing (arms at +2×stop) · optional time stop · riskless legs exempt
```
*Why layered and independent:* any single control can be wrong (mis-estimated edge, stale price, bug); the next one still
bounds the loss. *Why correlation uses return differences:* price **levels** of two drifting series correlate spuriously.
*Why riskless-basket legs are exempt from stop-loss:* their value is the guaranteed payout at settlement; stopping out one
leg destroys the hedge. **But only once the basket is complete** (audit pass 2): the legs of a partially filled basket are *not* hedged, so they keep
stop-loss protection until a human decides — the exemption is applied after the last leg fills, not before.

## 8. Strategies  <a id="strategies"></a>

Interface: `analyze(ctx) → signal[]` where a signal is `{id, strategy, kind: single|basket, riskless, payoutFloor?, legs, fairProb?, edge, confidence, reason}`.
The strategy only *proposes*; the trader re-quotes, re-checks edge, sizes, caps and executes. This keeps every strategy
unable to bypass risk controls.
*Tree on the "stat-arb" label.* The README calls it cointegration-based; the examples it gives (primary ⇒ general election)
are **logical-bound** violations, which are exact, need no estimation, and are the only genuinely riskless class. We therefore
ship (A) exclusive-event NO-baskets and (B) declared implications as the core, and (C) Engle-Granger pairs as an opt-in
low-confidence extra. Baskets are announced, not executed, in live mode unless `ARBITRAGE_AUTOEXEC=true`, because multi-leg
execution can leave a partial basket (alerted as a `risk_event`).
*Sentiment/volatility* are retained for parity but disabled by default (no evidence of edge — AUDIT F-10).

## 9. Security architecture  <a id="security"></a>

| Surface | Control |
|---|---|
| Kalshi private key | systemd `LoadCredential` (file root:root 600 → private tmpfs for the service); never in env/logs; redacted if it ever appears |
| Telegram | numeric-user allowlist, private chats only, setup mode executes nothing, replay guard (offset persisted + 120 s freshness), confirmation buttons for real money / close-all |
| REST/WS | bearer token (timing-safe compare), loopback bind, no inbound port in OCI, 16 KB body cap, 120 req/min/IP, real-money start refused over REST |
| Process | unprivileged user, read-only FS except state dir, no capabilities, `NoNewPrivileges`, memory cap |
| Code integrity | app tree root-owned (service can't modify its code); Node from nodejs.org verified by SHA-256 |
| Supply chain | zero npm dependencies |

## 10. Failure-mode analysis

| Failure | Detection | Behaviour |
|---|---|---|
| Kalshi/API outage | cycle error, `apiConnected=false` | cycle skipped, de-duplicated alert, retry next cycle |
| Order response lost | 409 on retry / reconcile every 3rd cycle | looked up by `client_order_id`; mismatch → alert, no auto-fix |
| Partial basket | leg fill < sets | stop placing legs, `risk_event` with legs held |
| Process crash / VM reboot | systemd | restart in 10 s, **trading OFF**, state from disk |
| Broker throws / order outcome unknown | `#submit` wrapper; `status:'unknown'` | contained, immediate `risk_event` (`order_error` / `order_unknown`); ledger untouched; next reconcile shows any difference |
| State cannot be saved (disk full) | 3 consecutive save failures | trading **halts** (`cannot persist state`), alert; `/resume` after fixing |
| `/close_all` while a cycle runs | shared `busy` mutex | waits for the cycle; a position can never be sold twice |
| Hostile / oversized feed or API body | linear-time parser, byte + item + field caps, streamed reads | milliseconds, not minutes; oversized Kalshi responses are rejected, not buffered |
| Qwen slow / down / wrong | background worker, timeout, circuit breaker, shadow mode | trading cycle never waits for the model; lexicon fallback |
| Corrupt state file | JSON parse error | moved aside (`.corrupt-<ts>`), start fresh, log loudly |
| Stale Telegram command | `message.date` > 120 s | ignored |
| Clock skew | HTTP 401 on signed calls | surfaces as cycle errors; Step 3 checks sync |
| Instance reclaimed | OCI alarm (Step 10) | rebuild from backups (Step 12) |

## 11. Manifest  <a id="manifest"></a>

`PROJECT_MANIFEST.json` is the permanent project memory: **scope** (in/out), **decisions** (with rationale and
alternatives), **assumptions**, **constraints**, a **verified / not-verified ledger**, **open items**, a **change log** and a
hashed **file inventory**. Narrative sections are hand-editable ("upon response can be altered"); `scripts/build-manifest.mjs`
refreshes only the inventory. Start a new work session by handing the manifest back.

## 12. Deliberately out of scope (v1.0)

HA / multi-instance (a second instance trading the same account would double orders — needs leader election) · websockets
from Kalshi (polling is enough at 60 s) · resting-order market making · backtesting against historical data · OCI Vault for
secrets (150 free secrets exist; a good next step) · Terraform/Resource Manager stack (couldn't be validated offline) ·
GUI dashboard.

## 13. Dashboard UI  <a id="dashboard"></a>

*Chain of thought.* An operator wants to *see* equity, risk headroom, what the strategies are proposing and whether the news model is healthy — without reading logs.
The bot already runs an HTTP server, so the page is served from it.
*Tree.* ✗ a separate web app / framework build (dependencies, a build step, another process on a 1 GB VM) · ✗ chart library from a CDN (supply chain, CSP, offline use) ·
✓ **one self-contained HTML file**: vanilla JS, SVG charts generated from numbers, DOM text only via `textContent`.
*Security.* The page is public (it holds nothing); data calls need the bearer token, kept in `sessionStorage`. The server computes a **CSP by hash** of the page’s one inline
script and style at startup (`default-src 'none'`, `connect-src 'self'`, no `unsafe-inline`), which is why the page may not contain inline `style=""` attributes or inline handlers
(tested). Polling every 5 s instead of WebSocket keeps the page simple and works through any tunnel; the WebSocket feed remains for other clients.
*Verification.* No browser is available in the build sandbox, so tests run the page’s real script in a Node VM with a DOM shim — against mock data **and against the real API
server** (contract test) — plus well-formedness checks of every generated SVG and a hostile-payload test. Layout/visual quality is **unverified**.
*Data views.* `Trader.equityView/tradesView/marketsView/signalsView` are read-only projections; `signalLog` keeps what strategies proposed and the outcome (executed / alert / skipped).

## 14. Qwen subsystem  <a id="qwen"></a>

*Chain of thought.* Lexicon tone cannot tell “bad news” from “bad for YES”, and keyword overlap misses paraphrase. A small local LLM can judge stance and relevance and return
structured output — but it is slow on CPU, can be wrong, and reads attacker-controllable text. So the design puts **evidence and containment before capability**.
*Decisions.* (1) **Local, not a hosted API** — headlines and strategy interest stay on the box; no per-call cost; loopback-only enforced. (2) **Shadow by default**, with an
*observer hook* so data is collected even while the strategy is off. (3) **Background worker + cache**: `analyze()` only peeks the cache, so the 60 s trading cycle never waits on a multi-second model call.
(4) **Schema-constrained output re-validated and clamped** — the schema is a request, not a trust boundary. (5) **Bounded influence**: ±10 probability points, ≥ 2 independent sources,
novelty weighting. (6) **Falsifiable evaluation** (`shadowReport`): Brier of market vs Qwen-adjusted vs lexicon-adjusted with a *cluster* bootstrap over markets.
*Rejected.* ✗ model inside the cycle (latency, stalls exits) ✗ hosted LLM API (privacy, key to manage, cost) ✗ trusting the model’s “confidence” without an outcome test ✗ shipping weights / claiming a trained model.
See [QWEN.md](QWEN.md) for install, evaluation and limits (notably L3: multilingual pairing is lexical).

## 15. Audit pass 2 — structural changes

Linear-time feed parsing and capped streamed reads · own-property validation of setting keys · strict env parsing (no silent defaults), real-money autostart refused · loopback-only test hooks
(`KALSHI_BASE_URL`, `TELEGRAM_API_URL`, `QWEN_URL`) so the whole process can be tested against mocks · `/resume` re-baselines loss/drawdown · scalar/void settlements alert instead of leaving ghosts ·
persistence-failure halt · broker-exception and unknown-outcome containment · half-open WebSocket reaping · position reconciliation cadence configurable. Details and the defect log: [AUDIT.md](AUDIT.md) §4.
