# Deployment guide — Oracle Cloud Infrastructure (Always Free)

Step-by-step, with a checkpoint after every step. Code comments in the project cite these step numbers.
Facts about Oracle's free tier were read from Oracle's own page
[Always Free Resources](https://docs.oracle.com/en-us/iaas/Content/FreeTier/resourceref.htm)
(page revision dated **12 Jun 2026**, re-read Nov 2026). **Re-read it before you start — Oracle changes it**, and many
blog posts still quote the old 4 OCPU / 24 GB Ampere allowance.

> **What was and was not tested.** `bootstrap.sh`'s checksum/regex logic, the unit-file substitution, config
> validation, the process lifecycle and all application code were tested in a sandbox. The installer and the systemd unit
> were **not executed on a real OCI VM** (no cloud access) — Step 5/8/9 are where you find out. Everything marked
> ✅ *Checkpoint* tells you what "working" looks like so you can spot a deviation early.

---

## Step 0 — Decide (tree of thought)

```
Do you have a payment card Oracle will accept for identity verification?
├─ no  → stop: Oracle requires one at sign-up (Always Free resources are not charged).
└─ yes
    Which VM shape?
    ├─ VM.Standard.A1.Flex (Arm)  — Always Free total = 1,500 OCPU-h + 9,000 GB-h per month
    │     = 2 OCPUs + 12 GB for Always-Free-only tenancies (older guides say 4/24 — outdated).
    │     + more RAM, full cores        − "Out of host capacity" is common
    │     → choose 1 OCPU / 6 GB (leaves half the allowance free) — or the full 2 OCPU / 12 GB if you want the
    │       optional local Qwen news model (Appendix E; it cannot run on the Micro)
    └─ VM.Standard.E2.1.Micro (AMD) — up to two instances, 1/8 OCPU (burstable), 1 GB RAM, 50 Mbps
          + creatable when A1 is out of capacity (one availability domain only)   − 1 GB: needs the swap the installer adds
          → perfectly adequate for this bot (idle ≈ 64 MB RSS measured in the build sandbox; unit caps the process at 512 MB, Node heap 256 MB)
    Which OS image?
    ├─ Ubuntu 24.04 (Canonical)  ← primary path of this guide (SSH user: ubuntu)
    └─ Oracle Linux 9            ← supported by the installer (SSH user: opc; SELinux enforcing — see Appendix B)
```

**Sizing evidence.** Idle RSS 64 MB; 100 GARCH fits over 399-sample series = 271 ms on a sandbox core (even ×8 for a
throttled 1/8 OCPU ≈ 2 s ≪ the 60 s cycle). Network is a few dozen small HTTPS calls per minute (Oracle gives 10 TB/month outbound).

> ⚠️ **Idle reclamation — read before you rely on this.** Oracle may reclaim an Always Free instance that is "idle":
> over a 7-day period, 95th-percentile CPU < 20 % **and** network < 20 % **and** (A1 only) memory < 20 %. A small
> trading bot is *by design* below those thresholds, so **assume it can be reclaimed**. Oracle's page does not exempt
> upgraded accounts from this rule. Mitigations, best first: (1) keep the system **rebuildable** (Step 12: daily backups + a
> 10-minute redeploy), (2) set an **OCI alarm** that e-mails you if the instance stops (Step 10), (3) optionally upgrade
> to *Pay As You Go* — Oracle says it then charges only for usage *above* the Always Free limits (set a budget alert; many
> users report upgraded accounts are not reclaimed, but Oracle's page doesn't promise it). This guide does **not**
> recommend artificial CPU/network "keep-alive" load: it games Oracle's policy and can starve a 1/8-OCPU micro.

## Step 1 — Create the Oracle Cloud account

1. Go to <https://www.oracle.com/cloud/free/> → **Start for free**.
2. Choose your **Home Region** carefully: it **cannot be changed**, and Always Free compute and block volumes must be
   created in the home region. Pick a region close to you (Kalshi is US-hosted; latency is not critical for this bot).
3. Verify the card. Wait for the "account ready" e-mail; sign in to the Console.
4. See your real limits: ☰ **Governance & Administration → Tenancy Management → Limits, Quotas and Usage**.

✅ *Checkpoint:* Console loads; you can open ☰ → **Compute → Instances**.

## Step 2 — Create the network and the instance

☰ → **Compute → Instances → Create instance** (labels vary slightly by Console version):

| Field | Value |
|---|---|
| Name | `kalshi-bot` |
| Image | **Change image → Canonical Ubuntu 24.04** (look for the *Always Free eligible* label) |
| Shape | **Change shape** → *Ampere* → `VM.Standard.A1.Flex` **1 OCPU, 6 GB**; **or** *Specialty and previous generation* → `VM.Standard.E2.1.Micro` |
| Networking | **Create new virtual cloud network** + **public subnet**; *Assign a public IPv4 address* = **Yes** |
| SSH keys | **Generate a key pair for me** → *Save private key* (and public key). Or paste your own `.pub`. |
| Boot volume | default (≈ 47–50 GB; the free pool is 200 GB total) |

Click **Create**; wait for state **Running**; copy the **Public IP address**.

* *"Out of host capacity"* (common on A1): try another availability domain, wait and retry, or use the Micro shape.
* **Networking/firewall — do nothing more.** The wizard's default security list allows inbound SSH (22) and all
  outbound. This bot needs **no inbound ports** (Telegram uses outbound long-polling; the API is reached through an SSH
  tunnel). *Optional hardening:* edit the subnet's security list and restrict the port-22 source CIDR to `your.ip/32`.

✅ *Checkpoint:* instance **Running** with a public IP.

## Step 3 — Connect and prepare the OS

On your computer:

```bash
chmod 600 ~/Downloads/ssh-key-*.key                       # the private key you saved
ssh -i ~/Downloads/ssh-key-XXXX.key ubuntu@<PUBLIC_IP>    # Oracle Linux: opc@<PUBLIC_IP>
```

On the VM:

```bash
sudo apt-get update && sudo apt-get -y upgrade            # Oracle Linux: sudo dnf -y upgrade
sudo timedatectl set-timezone UTC                         # the bot's "day" boundaries are UTC
timedatectl                                               # MUST show: System clock synchronized: yes
```

**Why the clock matters:** every Kalshi request is signed with a millisecond timestamp; a skewed clock makes signed
calls fail with HTTP 401. On Ubuntu `systemd-timesyncd` handles it; on Oracle Linux `chronyd`
(`sudo systemctl enable --now chronyd`).

✅ *Checkpoint:* `timedatectl` shows `Time zone: UTC` and `System clock synchronized: yes`.

## Step 4 — Upload the project

From your computer (where `kalshi-quant-oracle.zip` is):

```bash
scp -i ~/Downloads/ssh-key-XXXX.key kalshi-quant-oracle.zip ubuntu@<PUBLIC_IP>:~
```

On the VM:

```bash
sudo apt-get install -y unzip            # Oracle Linux: sudo dnf install -y unzip
unzip -q kalshi-quant-oracle.zip && cd kalshi-quant-oracle && ls
```

✅ *Checkpoint:* you see `package.json src deploy docs scripts README.md …`.
Optional integrity check: `node scripts/build-manifest.mjs --check` after Step 5 (needs Node), or compare file hashes in
`PROJECT_MANIFEST.json`.

## Step 5 — Run the installer

```bash
sudo bash deploy/oracle/bootstrap.sh
```

What it does (all steps idempotent; it never overwrites your env file or key, opens no port, starts nothing):
prerequisites → **1 GiB swap if RAM < 2 GB** → **Node.js 24 from nodejs.org (official tarball, SHA-256 verified)** →
user `kalshi` (no shell) → app in `/opt/kalshi-bot` (root-owned) → `/etc/kalshi-bot/` secrets scaffold →
systemd units + daily backup timer. On Oracle Linux with SELinux enforcing it labels the Node binary so systemd may
execute it.

Re-running it later is also how you **update** (Step 12).

✅ *Checkpoint:*
```bash
node -v                                  # v24.x.y
systemctl is-enabled kalshi-bot          # enabled
systemctl is-active kalshi-bot           # inactive   (not started yet — correct)
ls -l /etc/kalshi-bot                    # kalshi-bot.env and kalshi_private_key.pem, both -rw------- root root
```

## Step 6 — Credentials and the environment file

### 6a — Kalshi **demo** key (do demo first; real money comes in Step 13)
1. Create a **demo** account at <https://demo.kalshi.co> (separate from production).
2. In its account settings open **API Keys → create**. You get a **Key ID** and a **private key PEM shown once** —
   save the PEM immediately. Official guide: <https://docs.kalshi.com/getting_started/api_keys>.
3. Put the PEM on the VM **without it touching the environment or shell history**:
   ```bash
   sudo nano /etc/kalshi-bot/kalshi_private_key.pem     # paste, including -----BEGIN/END----- lines; save
   sudo chmod 600 /etc/kalshi-bot/kalshi_private_key.pem && sudo chown root:root /etc/kalshi-bot/kalshi_private_key.pem
   ```
   (systemd's `LoadCredential` exposes it to the service only as `$CREDENTIALS_DIRECTORY/kalshi_key`.)

### 6b — API token (optional, for the REST/WebSocket API)
```bash
openssl rand -hex 24          # copy the 48-character output → API_TOKEN
```

### 6c — Edit the env file
```bash
sudo nano /etc/kalshi-bot/kalshi-bot.env
```
Set at least:
```ini
TRADING_MODE=paper          # start in paper mode — always
KALSHI_ENV=demo
KALSHI_API_KEY_ID=<your demo key id>
API_TOKEN=<from 6b>         # optional
TELEGRAM_BOT_TOKEN=<from Step 7a>
# TELEGRAM_CHAT_ID=<from Step 7b>   (leave empty until then)
```
Rules: **no trailing comments** on a line (systemd doesn't support them), **don't** set `DATA_DIR` (the unit sets
it), keep the file `600 root:root`. **Invalid values abort startup** and name the variable (e.g. `AUTOSTART_TRADING=ture`) — they are never
silently replaced by defaults, and `AUTOSTART_TRADING=true` is refused with real money. Every variable is documented in `.env.example`; SCAN_* variables
shrink memory/CPU if you ever need it on the micro shape.

✅ *Checkpoint:* `sudo ls -l /etc/kalshi-bot/kalshi-bot.env` → `-rw------- root root`.

## Step 7 — Telegram: bot, your user ID, allowlist

**7a — create the bot.** In Telegram open **@BotFather** → `/newbot` → pick a name and a username ending in `bot` →
copy the **token** (`123456789:AA…`). Put it in `TELEGRAM_BOT_TOKEN` (Step 6c).

**7b — find your numeric user ID** (the bot serves only IDs you list). Message your new bot once ("hello"), then on the
VM (reads the token without echoing it or saving it in history):
```bash
read -rs TOKEN; echo; curl -s "https://api.telegram.org/bot${TOKEN}/getUpdates" | grep -o '"from":{"id":[0-9]*'; unset TOKEN
```
The number after `"id":` is your **user ID**. (Alternative once the service is running with an *empty* allowlist:
send `/id` to the bot — *setup mode* answers only that and executes nothing.)

**7c — lock the allowlist.** `sudo nano /etc/kalshi-bot/kalshi-bot.env` → `TELEGRAM_CHAT_ID=<your id>` (comma-separate
more IDs). Only listed users, only in private chats, are served.

✅ *Checkpoint:* the env file has both Telegram values; no one else's ID is in it.

## Step 8 — Validate the configuration and test against Kalshi DEMO

```bash
# 8a — config check (prints the safety banner; exit 0 = valid, 2 = CONFIG ERROR)
sudo systemd-run --quiet --wait --pipe -p User=kalshi \
  -p EnvironmentFile=/etc/kalshi-bot/kalshi-bot.env -p Environment=DATA_DIR=/var/lib/kalshi-bot \
  -p LoadCredential=kalshi_key:/etc/kalshi-bot/kalshi_private_key.pem \
  /usr/local/bin/node /opt/kalshi-bot/src/index.js --check

# 8b — the demo smoke test (the first real contact with Kalshi — this is the proof the sandbox could not give)
sudo systemd-run --quiet --wait --pipe -p User=kalshi -p WorkingDirectory=/opt/kalshi-bot \
  -p EnvironmentFile=/etc/kalshi-bot/kalshi-bot.env \
  -p LoadCredential=kalshi_key:/etc/kalshi-bot/kalshi_private_key.pem \
  /usr/local/bin/node scripts/smoke-demo.mjs --place-test-order
```
Expected (8b):
```
✅ public: exchange status — {"exchange_active":true,"trading_active":true}
✅ public: events + market field parsing — N markets, M with quotes; sample …
✅ signed: balance (rsa|ed25519 key) — cash $…
✅ signed: positions — 0 open position(s)
✅ order payload "fixed" — accepted, status=canceled      ← (a 1-contract IOC buy at 1¢ should not fill)
✅ recommended setting — KALSHI_ORDER_FIELD_STYLE=fixed
```
| If you see… | Do this |
|---|---|
| ❌ `HTTP 401` on signed calls | wrong Key ID↔PEM pair; **a prod key used on demo (or vice-versa)**; clock skew (Step 3) |
| ❌ "no bid/ask parsed" | Kalshi changed field names: save the raw `GET /markets?limit=1` JSON and adapt `normalizeMarket` (`src/kalshi/client.js`) |
| order style `fixed` ❌ but `both`/`legacy` ✅ | put the recommended `KALSHI_ORDER_FIELD_STYLE=…` in the env file |
| every style ❌ | Kalshi changed the order schema — **do not go live**; check <https://docs.kalshi.com> create-order |
| `systemd-run: … LoadCredential` unsupported | systemd < 247; copy the PEM to a root-only path and use `KALSHI_PRIVATE_KEY_PATH` instead |

✅ *Checkpoint:* 8a exits 0; 8b has no ❌.

## Step 9 — Start the service

```bash
sudo systemctl start kalshi-bot
sudo systemctl status kalshi-bot --no-pager
sudo journalctl -u kalshi-bot -n 40 --no-pager
```
Expected log lines (abridged):
```
INFO  kalshi-quant-telebot-node v1.0.0 · node v24.x · PAPER MODE — no orders are ever sent to Kalshi
INFO  telegram connected as @yourbot
INFO  API listening on 127.0.0.1:3001 (bearer token required)
INFO  trading is OFF — send /start_trading in Telegram …
```
You should also receive a Telegram message **"🔌 Bot started"**. Send `/status`. Then `/start_trading` (paper mode starts
immediately). After the first cycle (~1 min) `/status` shows `Kalshi API: 🟢 connected`.

Useful: `sudo systemctl restart|stop kalshi-bot`; the service restarts itself on failure (max 5 times / 5 min) and
**always comes back with trading OFF**.

✅ *Checkpoint:* `systemctl is-active kalshi-bot` → `active`; Telegram answers `/status`; a stranger's account gets **no**
reply.

## Step 10 — Logs and monitoring

```bash
sudo journalctl -u kalshi-bot -f                      # live
sudo journalctl -u kalshi-bot --since "1 hour ago"
systemctl show -p MemoryCurrent -p MemoryPeak kalshi-bot
systemd-analyze security kalshi-bot                   # hardening report for the unit
```
* **Cap journald** so logs can't fill the 47 GB disk: `sudo mkdir -p /etc/systemd/journald.conf.d &&
  printf '[Journal]\nSystemMaxUse=200M\n' | sudo tee /etc/systemd/journald.conf.d/size.conf && sudo systemctl restart systemd-journald`.
* **In the bot:** `/status` shows last-cycle duration/errors and exchange-vs-ledger reconciliation; risk events arrive as Telegram alerts.
* **OCI alarm (recommended — covers idle reclamation, host maintenance, crashes):** ☰ → **Observability & Management →
  Monitoring → Alarm definitions → Create alarm**: namespace `oci_computeagent`, metric `CpuUtilization` for your instance,
  trigger on **absent data** (instance stopped/deleted) → destination a **Notifications topic** with your e-mail
  subscription (Oracle's free allowance includes 1,000 e-mail notifications/month). (Metrics need the Oracle Cloud Agent
  *Compute Instance Monitoring* plugin, on by default for Oracle-provided images.)
* **Budget alert (if you upgrade):** ☰ → **Billing & Cost Management → Budgets** → budget of **$1**, alert at 1 %.

## Step 11 — Operating the bot

**From your phone (Telegram)** — see the command table in the README. A sane routine: `/status` morning and evening,
act on 🚨 *risk events*, `/stop_trading` at any doubt (open positions are untouched; `/close_all` flattens them).

**The REST/WebSocket API** is on the VM's loopback only. From your computer:
```bash
ssh -i ~/Downloads/ssh-key-XXXX.key -N -L 3001:127.0.0.1:3001 ubuntu@<PUBLIC_IP>     # leave running
curl -s -H "Authorization: Bearer $API_TOKEN" http://127.0.0.1:3001/api/status
curl -s -H "Authorization: Bearer $API_TOKEN" -H 'Content-Type: application/json' \
     -d '{"stopLoss":0.06}' http://127.0.0.1:3001/api/config
```
**The dashboard** (graphical UI) is the same tunnel: with `ssh … -L 3001:127.0.0.1:3001` running, open **http://127.0.0.1:3001/** in your browser and paste
`API_TOKEN` when asked. You get the equity curve with drawdown shading, risk gauges, positions, closed-trade P&L, the arbitrage radar, a market heat map, signals,
the news-intelligence panel and a live log (see README §Dashboard). Start/Stop work for paper/demo; **real-money start is refused here by design — use Telegram.**
No tunnel? `http://127.0.0.1:3001/?demo` (or any hosted preview of the page) shows clearly-labelled **demo data**. The page was verified against the real API
through a DOM shim only — **it has not been opened in a real browser by the author**, so tell me what looks off.

**Declared relations for arbitrage:** copy `/var/lib/kalshi-bot/relations.example.json` to `relations.json`
(owner `kalshi`), list only relations you verified in the markets' rules, `sudo systemctl restart kalshi-bot`.

**Switching strategies/settings** persists in `/var/lib/kalshi-bot/bot_settings.json` and overrides the env file after a
restart.

## Step 12 — Backups, updates, recovery

* **Daily backup** is installed (`systemctl list-timers kalshi-bot-backup.timer`; archives in `/var/backups/kalshi-bot`,
  newest 14 kept). Manual: `sudo /opt/kalshi-bot/scripts/backup.sh`.
* **Copy backups off the VM** (a reclaimed instance takes local backups with it):
  `scp -i KEY ubuntu@IP:/var/backups/kalshi-bot/kalshi-data-*.tgz .` — or push to Oracle Object Storage (20 GB free) with
  the OCI CLI. The env file/key are *not* in these archives: keep them in your password manager.
* **Update:** upload the new ZIP, `unzip`, `sudo bash deploy/oracle/bootstrap.sh`, `sudo systemctl restart kalshi-bot`.
* **Rebuild after loss/reclamation (≈ 10 min):** new instance (Step 2) → Steps 3–5 → restore
  `sudo systemctl stop kalshi-bot; sudo tar -xzf kalshi-data-….tgz -C /var/lib; sudo chown -R kalshi:kalshi /var/lib/kalshi-bot`
  → recreate env/key (Step 6) → `sudo systemctl start kalshi-bot`. In live modes the first cycle reconciles cash and alerts on
  any exchange-vs-ledger position difference.

## Step 13 — Going live checklist

Do **not** skip. Real money is lost by bots that were never given a chance to fail cheaply.
- [ ] `npm test` passes on your machine and `smoke:demo` passes on the VM (Step 8).
- [ ] ≥ **2–4 weeks** in paper mode with the strategies you intend to use; you have read `/performance` and the trade log
  (`/var/lib/kalshi-bot/trades.paper.jsonl`) and understand *why* each trade fired. Paper P&L is an **upper bound**
  (no queue position, depth or latency) — expect live to be worse.
- [ ] ≥ 1–2 weeks with `TRADING_MODE=live` + `KALSHI_ENV=demo` (checks real order handling, fills, settlement).
- [ ] Confirmed Kalshi's **current fee schedule** and set `FEE_COEFFICIENT` accordingly; confirmed Kalshi's terms for API/automated
  trading and that it is permitted for you where you live.
- [ ] Production key created (kalshi.com), limited funds deposited — **an amount you can afford to lose entirely**.
- [ ] Conservative settings: `bankroll` = that amount, `maxPositionSize` ≤ 0.05, `maxDailyLoss` ≤ 0.02, `kellyScale` ≤ 0.25, `ARBITRAGE_AUTOEXEC=false`.
- [ ] Env file: `TRADING_MODE=live`, `KALSHI_ENV=prod`, `I_UNDERSTAND_LIVE_TRADING_RISK=yes`, prod Key ID, **prod PEM** at
  `/etc/kalshi-bot/kalshi_private_key.pem`. Restart; the banner must read `*** REAL MONEY …`.
- [ ] `/start_trading` → confirm button. Watch the first day closely; keep Telegram notifications on.

---

## Appendix A — Docker (optional)

Lighter on RAM with systemd; use Docker only if you prefer it. **Not built in the author's sandbox (no Docker).**
```bash
sudo apt-get install -y docker.io docker-compose-v2        # Ubuntu 24.04 package names; or follow docs.docker.com
cp .env.example .env && chmod 600 .env && nano .env        # same variables as Step 6 (set API_TOKEN: container binds 0.0.0.0)
mkdir -p secrets && install -m 600 /path/to/key.pem secrets/kalshi_private_key.pem
sudo docker compose -f deploy/docker/docker-compose.yml up -d --build
sudo docker compose -f deploy/docker/docker-compose.yml logs -f
```
The compose file publishes 3001 on the host's **loopback only**, runs read-only with all capabilities dropped and a 450 MB cap.

## Appendix B — Troubleshooting

| Symptom | Cause → fix |
|---|---|
| `Out of host capacity` creating A1 | other AD / retry later / Micro shape / upgrade to PAYG (Oracle: you're charged only above Always Free limits) |
| `ssh: Permission denied (publickey)` | wrong user (`ubuntu` vs `opc`), key file mode not `600`, or wrong key |
| `bootstrap.sh`: `SHA-256 mismatch` | transient download corruption or tampering — re-run; if persistent, stop and investigate |
| service: `status=203/EXEC` | systemd can't execute Node: on Oracle Linux an SELinux label issue — `sudo restorecon -R /opt/node` or `sudo chcon -R -t bin_t /opt/node`; check `ls -l /usr/local/bin/node` resolves |
| service: `status=226/NAMESPACE` or `status=1/FAILURE` right after edits | a hardening directive your kernel lacks — `journalctl -u kalshi-bot`; relax the one named line in `/etc/systemd/system/kalshi-bot.service`, `sudo systemctl daemon-reload` |
| `EACCES` writing state | `DATA_DIR` set in the env file (it overrides the unit) → remove that line |
| `CONFIG ERROR: …` (exit 2) | read the message — it names the exact variable |
| Telegram `409 Conflict` in logs | another process is polling this bot token (a second copy, or a webhook elsewhere) → stop it |
| Kalshi `429` | lower `KALSHI_READ_RPS`, raise `tradeInterval`, reduce `SCAN_MAX_PAGES` |
| Process killed (OOM) | `journalctl -k | grep -i oom`; ensure swap exists (`swapon --show`); lower `SCAN_MAX_PAGES`/`PRICE_HISTORY_TICKERS`; disable volatility |
| Dashboard stuck on the token prompt | token typed wrongly, or the SSH tunnel is down (`curl -s http://127.0.0.1:3001/api/health` on your computer should print `healthy`) |
| Dashboard blank / “Can’t reach the bot” | tunnel down or bot stopped (`systemctl status kalshi-bot`); a browser extension blocking `fetch` to localhost |
| `CONFIG ERROR: QWEN_URL host … is not loopback` | the model server must run on the same VM (or set `QWEN_ALLOW_REMOTE=yes` knowingly) |
| Instance vanished / stopped by Oracle | idle reclamation — rebuild per Step 12; consider PAYG + alarm (Step 10) |

## Appendix C — Current Always Free numbers used here (Oracle page rev. 12 Jun 2026)

Micro: ≤ 2 × `VM.Standard.E2.1.Micro` (1/8 OCPU burst, 1 GB, 50 Mbps), one AD only · A1: first 1,500 OCPU-h and 9,000 GB-h
per month (= 2 OCPU + 12 GB) · Block storage 200 GB total incl. boot volumes (≈ 47–50 GB each), 5 backups · Outbound 10 TB/month ·
Object Storage 20 GB · Notifications 1M HTTPS + 1,000 e-mail/month · Monitoring 500M ingestion points · Vault 150 secrets
(an upgrade path from the env file, not used here) · Bastion free · 2 VCNs on Always-Free-only tenancies · Compute and block
volume only free **in the home region** · images: Oracle Linux, Ubuntu (+ CentOS on Micro).

## Appendix D — Uninstall

```bash
sudo systemctl disable --now kalshi-bot kalshi-bot-backup.timer
sudo rm -f /etc/systemd/system/kalshi-bot*.service /etc/systemd/system/kalshi-bot-backup.timer && sudo systemctl daemon-reload
sudo rm -rf /opt/kalshi-bot            # code
sudo rm -rf /var/lib/kalshi-bot /var/backups/kalshi-bot /etc/kalshi-bot   # state, backups, SECRETS — only if you're sure
sudo userdel kalshi
```
Revoke the Kalshi API key in Kalshi's settings and the bot token with @BotFather (`/revoke`) if you're decommissioning.

## Appendix E — Optional: Qwen news model on the A1 shape

Only on **VM.Standard.A1.Flex with ≥ 6 GB RAM** (the micro cannot). Full guide, limits and the evaluation procedure: **[docs/QWEN.md](QWEN.md)**. Short form:
```bash
sudo bash deploy/qwen/install-ollama.sh                 # Ollama (official installer) + qwen3:1.7b + the pinned `kalshi-news` model definition
sudo nano /etc/kalshi-bot/kalshi-bot.env                # QWEN_ENABLED=true   QWEN_MODEL=kalshi-news     (leave QWEN_TRADE unset = SHADOW mode)
sudo systemctl restart kalshi-bot && sudo journalctl -u kalshi-bot -n 20 | grep -i qwen
npm run qwen:eval                                       # from /opt/kalshi-bot with the env loaded: sanity-check the real model (JSON validity, latency)
```
Rules that matter: **never expose port 11434**; stay in shadow mode for 4–8 weeks; decide with `npm run qwen:shadow-report`, not with intuition. This installer and the
model behaviour were **not executed by the author** (no network in the sandbox).
