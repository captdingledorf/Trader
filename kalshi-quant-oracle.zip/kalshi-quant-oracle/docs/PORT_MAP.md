# Port map: yllvar/Kalshi-Quant-TeleBot → kalshi-quant-telebot-node

## 0. What the analysis could and could not see

| Source | Readable? | Used for |
|---|---|---|
| Repo landing page (README + root file list), Nov 2026 | **yes** | features, config names, API surface, Telegram commands, architecture claims |
| `src/`, `telegram_ui/`, `tests/`, `.vincent/` contents | **no** — per-file GitHub URLs were refused by the fetch tooling and not returned by search | — |
| `DEPLOYMENT_GUIDE.md`, `IMPLEMENTATION_PLAN.md`, `PRODUCT_DOCUMENTATION.md`, `strategy_design.md`, `package.json`, `requirements.txt`, `Procfile`, `railway.toml` | **no** (listed in the root, content unreadable) | — |
| Kalshi docs (docs.kalshi.com: API keys, authenticated requests, create-order, fixed-point migration, subpenny pricing) | yes | authentication, units, order shape |
| Oracle docs (Always Free Resources, rev. 12 Jun 2026) | yes | shapes, limits, idle reclamation |

**Therefore this is an implementation of the *documented* behaviour, not a transliteration.** If the upstream code does
something the README doesn't say, this port doesn't do it either. Treat §3 as the list of known/likely gaps.

Root files noticed in the upstream listing: `.gitignore`, `.vincent/`, `DEPLOYMENT_GUIDE.md`, `IMPLEMENTATION_PLAN.md`,
`PRODUCT_DOCUMENTATION.md`, `Procfile`, `README.md`, `bot_settings.json.example`, `package.json`, `railway.toml`,
`requirements.txt`, `run_phase1_tests.py`, `setup-railway.sh`, `strategy_design.md`, `validate_phase1.py`; **no `LICENSE`**
(the README claims MIT — see NOTICE).

## 1. Component mapping

| Upstream (documented) | This port | Notes |
|---|---|---|
| Python trading engine (`src/…`) | `src/engine/trader.js` + `src/strategies/*` | one process |
| Python data ingestion / Kalshi client | `src/kalshi/client.js`, `src/data/scanner.js` | signed requests (see §2) |
| Strategy modules: news sentiment, stat-arb, volatility | `src/strategies/{sentiment,arbitrage,volatility}.js` | simplified; §3 |
| Risk module (Kelly, stops, limits) | `src/engine/risk.js` | README's `kelly_criterion(win_prob, win_amount, loss_amount)` is `kellyGeneric`; sizing uses the binary closed form |
| Node `telegram_ui/` bot | `src/telegram/bot.js` | allowlist, confirmations, replay guard added |
| Node REST + WebSocket on :3001 | `src/api/server.js`, `src/util/wsHub.js` | same endpoints/messages; token auth |
| `bot_settings.json(.example)` | `data/bot_settings.json` (+ `data/bot_settings.example.json`) | hot-editable via `/set` and `POST /api/config` |
| `.env` variables | same names where documented | see §4 |
| `Procfile`, `railway.toml`, `setup-railway.sh` | `deploy/systemd/*`, `deploy/oracle/bootstrap.sh`, `deploy/docker/*` | target is Oracle |
| `tests/`, `run_phase1_tests.py`, `validate_phase1.py` | `test/*.test.js` (92 tests, `node:test`, incl. whole-process e2e against mock Kalshi/Telegram/Ollama) | new tests; upstream's unread |
| *(no equivalent documented)* | `src/ui/index.html`, `src/ai/*`, `scripts/qwen-*.mjs`, `deploy/qwen/*` | additions beyond the original |

## 2. Money & units

| Topic | Upstream README | Port |
|---|---|---|
| Kalshi auth | `Authorization: Bearer <KALSHI_API_KEY>` | **signed headers** `KALSHI-ACCESS-KEY/TIMESTAMP/SIGNATURE`, RSA-PSS or Ed25519 |
| Prices | not specified | dollars (floats) internally; `*_dollars` strings preferred, legacy cents fallback; order payload fixed-point strings |
| Counts | not specified | `*_fp` preferred, legacy ints fallback |
| Fees | not modelled in README | taker fee `ceil_cent(0.07·C·P·(1−P))` in every edge calculation (configurable) |

## 3. Interpretations, substitutions and gaps (honest list)

| # | Topic | Upstream claim | What this port does | Gap / risk |
|---|---|---|---|---|
| 1 | News sentiment | transformer-based NLP, "sophisticated" | lexicon scorer + relevance gate + ≤ ±10-pt shift **by default**; optional **local Qwen** (stance/relevance/novelty, shadow-first) on the A1 shape | lexicon far less capable; Qwen unverified against a real model (docs/QWEN.md); strategy ships **off** |
| 2 | Stat-arb | cointegration-based; example "primary ⇒ general election" | (A) exclusive-event NO-basket, (B) user-declared implications (exact bound checks), (C) opt-in Engle-Granger pairs | (A) needs Kalshi's `mutually_exclusive` flag to be accurate; (B) needs *you* to declare relations; (C) weak theory for bounded prices |
| 3 | Volatility | GARCH-style regimes | GARCH(1,1) QMLE (grid search, variance targeting) on logit returns, gating a fade of EMA deviations | `volatilityThreshold` is documented only as "volatility threshold"; interpreted as **min \|mid − EMA20\| in probability units** |
| 4 | Thresholds | `NEWS_SENTIMENT_THRESHOLD=0.6`, `STAT_ARBITRAGE_THRESHOLD=0.05` | 0.6 = min \|weighted tone\| (and confidence ≥ 0.5); 0.05 = min **net-of-fee** edge per basket set in dollars | interpretation, not verified against upstream code |
| 5 | Risk | Kelly, stop-loss, daily loss, correlation, position cap | all present; correlation = |ρ| of **price changes** over ≤ 60 samples; daily loss relative to `bankroll` | upstream's exact definitions unknown |
| 6 | Latency claims | "sub-second response" | cycle-based polling (default 60 s) | no HFT behaviour; deliberate |
| 7 | Performance metrics | Sharpe, drawdown, win rate… | same fields; Sharpe annualised √365 from daily equity, needs ≥ 5 days | different from upstream if it used per-trade returns |
| 8 | Local API auth | "IP-based authentication" | bearer token + loopback | **stricter**; breaking for clients that relied on IP trust |
| 9 | Telegram access | no allowlist described | allowlist; empty ⇒ setup mode | **stricter** |
| 10 | Persistence | unspecified | atomic JSON + JSONL per mode | — |
| 11 | `.vincent/` | present in repo | **not inspected** | unknown purpose |
| 12 | Hosting | Railway | Oracle (systemd/Docker) | — |
| 13 | UI | Telegram + REST/WS only (documented) | adds a **graphical dashboard** served by the bot | extra surface; CSP-hardened; never viewed in a real browser by the author |

## 4. Environment variables

Upstream-documented names kept: `BANKROLL`, `MAX_POSITION_SIZE_PERCENTAGE`, `STOP_LOSS_PERCENTAGE`,
`NEWS_SENTIMENT_THRESHOLD`, `STAT_ARBITRAGE_THRESHOLD`, `VOLATILITY_THRESHOLD`, `MAX_DAILY_LOSS`, `MAX_OPEN_POSITIONS`,
`CORRELATION_LIMIT`, `TELEGRAM_BOT_TOKEN`, `TELEGRAM_CHAT_ID`, `TRADE_INTERVAL_SECONDS`.
Changed meaning: `KALSHI_API_KEY` → still accepted as an alias of `KALSHI_API_KEY_ID`, **plus a private key is now required**.
`TELEGRAM_CHAT_ID` → now a comma-separated **allowlist of user IDs**. New: `TRADING_MODE`, `KALSHI_ENV`,
`I_UNDERSTAND_LIVE_TRADING_RISK`, `AUTOSTART_TRADING`, `API_TOKEN`, `API_HOST`, `API_PORT`, `STRATEGIES`, `ARBITRAGE_AUTOEXEC`, risk
additions (`MAX_DRAWDOWN`, `KELLY_SCALING_FACTOR`, `MAX_ORDER_CONTRACTS`, `MIN_EDGE`, …), `SCAN_*`, `PAPER_*`, `FEE_COEFFICIENT`,
`KALSHI_ORDER_FIELD_STYLE`. Full list: `.env.example`.

## 5. Behaviour you may notice differs

* After a restart the bot **does not trade** until told to (upstream: unspecified).
* Live arbitrage baskets are **announced** (Telegram) rather than executed unless you opt in.
* Nothing is sent to Kalshi in paper mode, including cancels.
* Historical-bootstrap of price series isn't done: volatility/cointegration strategies need a live warm-up (≥ 40 / ≥ 60 cycles).

## 6. If you can supply the upstream source

Drop the repo (or its `src/` and `telegram_ui/`) into a new session with this manifest; the differences in §3 can then be
closed one by one against the real code, and `test/` extended with upstream-derived fixtures.
