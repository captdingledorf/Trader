# Reading list — books and textbooks behind this project

Selected for the thesis's disciplines (docs/THESIS.md), **academic-first** (sections A–H and K); a short practitioner list is in section I. "Institution" is the **author's academic home at the time of writing
or the publishing university**, and is given so you can find the research group; faculty move, so confirm on the author's page.
Titles/authors/publishers were written **without a live catalogue lookup** — confirm the current edition and ISBN before buying
or citing. ★ = start here; 🆓 = legally free online from the author/publisher.

## A. Prediction markets, forecasting, information

| Title | Author(s) | Publisher | Institution | Why it matters here |
|---|---|---|---|---|
| ★ *Superforecasting: The Art and Science of Prediction* | P. E. Tetlock, D. Gardner | Crown, 2015 | Univ. of Pennsylvania | calibration, scoring, what good probabilistic forecasting looks like — the benchmark any "probability model" must meet |

## B. Financial economics and market microstructure

| Title | Author(s) | Publisher | Institution | Why |
|---|---|---|---|---|
| ★ *Trading and Exchanges: Market Microstructure for Practitioners* | L. Harris | Oxford UP, 2003 | Univ. of Southern California | order books, spreads, fees, adverse selection — why paper fills lie |
| *Empirical Market Microstructure* | J. Hasbrouck | Oxford UP, 2007 | New York University (Stern) | measuring execution cost and price discovery |
| *Market Microstructure Theory* | M. O'Hara | Blackwell, 1995 | Cornell University | theoretical foundations |
| ★ *Adaptive Markets: Financial Evolution at the Speed of Thought* | A. W. Lo | Princeton UP, 2017 | MIT (Sloan) | why edges decay; efficiency as a moving target |
| *The Econometrics of Financial Markets* | J. Campbell, A. Lo, C. MacKinlay | Princeton UP, 1997 | Harvard / MIT / Univ. of Pennsylvania | testing efficiency and predictability |
| *Options, Futures, and Other Derivatives* | J. C. Hull | Pearson (many eds.) | Univ. of Toronto (Rotman) | binary payoffs, no-arbitrage reasoning (our §3.3–3.4) |

## C. Statistics, econometrics, machine learning

| Title | Author(s) | Publisher | Institution | Why |
|---|---|---|---|---|
| ★ *Time Series Analysis* | J. D. Hamilton | Princeton UP, 1994 | UC San Diego | unit roots (ADF), cointegration, ARCH/GARCH — the maths in `src/util/stats.js` |
| *Analysis of Financial Time Series* | R. S. Tsay | Wiley, 3rd ed. 2010 | Univ. of Chicago (Booth) | applied GARCH and volatility modelling |
| ★ *Advances in Financial Machine Learning* | M. López de Prado | Wiley, 2018 | Cornell University (ORIE) | backtest overfitting, cross-validation for finance — read before trusting any backtest |
| 🆓 *The Elements of Statistical Learning* | T. Hastie, R. Tibshirani, J. Friedman | Springer, 2nd ed. 2009 | Stanford University | statistical foundations of prediction |
| 🆓 *An Introduction to Statistical Learning* | G. James, D. Witten, T. Hastie, R. Tibshirani | Springer, 2nd ed. 2021 | Univ. of Washington / Stanford | gentler companion |
| *Bayesian Data Analysis* | A. Gelman et al. | CRC Press, 3rd ed. 2013 | Columbia University | uncertainty about parameters — the cure for over-confident p̂ |
| *Computer Age Statistical Inference* | B. Efron, T. Hastie | Cambridge UP, 2016 | Stanford University | modern inference in context |
| 🆓 *Speech and Language Processing* (draft 3rd ed.) | D. Jurafsky, J. H. Martin | online | Stanford / Univ. of Colorado Boulder | what the sentiment strategy's lexicon approach leaves out |
| *Artificial Intelligence: A Modern Approach* | S. Russell, P. Norvig | Pearson, 4th ed. 2020 | UC Berkeley | agents under uncertainty; decision theory |

## D. Decision theory, growth-optimal betting, behaviour

| Title | Author(s) | Publisher | Institution | Why |
|---|---|---|---|---|
| ★ *The Kelly Capital Growth Investment Criterion* | L. C. MacLean, E. O. Thorp, W. T. Ziemba (eds.) | World Scientific, 2011 | Dalhousie / UC Irvine & San Diego / Univ. of British Columbia | the definitive Kelly reference incl. fractional Kelly and estimation error (thesis §3.2) |
| *Elements of Information Theory* | T. M. Cover, J. A. Thomas | Wiley, 2nd ed. 2006 | Stanford University | the information-theoretic derivation of Kelly (gambling chapter) |
| *Thinking, Fast and Slow* | D. Kahneman | Farrar, Straus & Giroux, 2011 | Princeton University | biases that corrupt both strategy designers and their overrides |

## E. Distributed systems, reliability, operating systems

| Title | Author(s) | Publisher | Institution | Why |
|---|---|---|---|---|
| ★ *Designing Data-Intensive Applications* | M. Kleppmann | O'Reilly, 2017 (check for a newer edition) | Univ. of Cambridge (at publication) | idempotency, retries, exactly-once myths — the logic of `client_order_id` and reconciliation |
| *Distributed Systems* | A. S. Tanenbaum, M. van Steen | 3rd ed. 2017 | Vrije Universiteit Amsterdam | fundamentals |
| 🆓 *Operating Systems: Three Easy Pieces* | R. H. Arpaci-Dusseau, A. C. Arpaci-Dusseau | Arpaci-Dusseau Books | Univ. of Wisconsin–Madison | memory, scheduling, files — understanding the 1 GB box and swap |
| *Principles of Computer System Design* | J. H. Saltzer, M. F. Kaashoek | Morgan Kaufmann, 2009 | MIT | modularity, atomicity, fault tolerance, security — our design vocabulary |
| *Computer Networking: A Top-Down Approach* | J. F. Kurose, K. W. Ross | Pearson (8th ed. 2020) | Univ. of Massachusetts Amherst | HTTP, TLS, timeouts, DNS |

## F. Safety engineering, human factors, security

| Title | Author(s) | Publisher | Institution | Why |
|---|---|---|---|---|
| ★ *Engineering a Safer World: Systems Thinking Applied to Safety* | N. G. Leveson | MIT Press, 2011 | MIT | STAMP — controls as constraints in a socio-technical system (our risk layers) |
| *Normal Accidents: Living with High-Risk Technologies* | C. Perrow | Basic Books, 1984 (Princeton UP ed. 1999) | Yale University | why tightly coupled automation fails in surprising ways |
| *Human Error* | J. Reason | Cambridge UP, 1990 | Univ. of Manchester | slips vs mistakes; Swiss-cheese model |
| *The Field Guide to Understanding 'Human Error'* | S. Dekker | CRC Press, 3rd ed. 2014 | Griffith University | blameless post-mortems; why alerts must be designed |
| 🆓 ★ *Security Engineering* | R. Anderson | Wiley, 3rd ed. 2020 | Univ. of Cambridge | threat modelling, payments, secrets management |
| 🆓 *Handbook of Applied Cryptography* | A. Menezes, P. van Oorschot, S. Vanstone | CRC Press, 1996 | Waterloo / Carleton | signatures (RSA-PSS), hashes — background for `src/kalshi/auth.js` |

## G. Law & society

| Title | Author(s) | Publisher | Institution | Why |
|---|---|---|---|---|
| *Code and Other Laws of Cyberspace* | L. Lessig | Basic Books, 1999 | Harvard University | code as regulation — our architecture as the user's safety/compliance regime |
| *The Law of Securities Regulation* | T. L. Hazen | West (many eds.) | Univ. of North Carolina at Chapel Hill | orientation in U.S. market regulation (read alongside commodities/derivatives sources and take real legal advice) |

## H. Foundational papers (short list; full citations in docs/THESIS.md)
Kelly 1956 · Thorp 2006 · Engle & Granger 1987 · Bollerslev 1986 · Dickey & Fuller 1979 · Wolfers & Zitzewitz 2004 ·
Arrow et al. 2008 · Hanson 2003/2007 · Snowberg & Wolfers 2010 · Gneiting & Raftery 2007 · Bailey et al. 2014 · Saltzer & Schroeder 1975.

## I. Practitioner companions (not from academic institutions, but standard working references)

| Title | Author(s) | Publisher | Institution | Why |
|---|---|---|---|---|
| *Release It!* (2nd ed.) | M. T. Nygard | Pragmatic, 2018 | (practitioner) | timeouts, circuit breakers, bulkheads — patterns used here |
| *Site Reliability Engineering* | B. Beyer et al. (eds.) | O'Reilly, 2016 | (Google practitioners) | alerting philosophy, postmortems |
| *Accelerate* | N. Forsgren, J. Humble, G. Kim | IT Revolution, 2018 | (research + practice) | deployment practices that reduce incidents |

These are included because the operational patterns (timeouts, circuit breakers, alerting, post-mortems) come mostly from industry practice; the academic-first lists above remain the core.

## J. A 12-week study sequence (≈ 5 h/week)

| Weeks | Topic | Read | Do in this repo |
|---|---|---|---|
| 1–2 | Probabilities, scoring, calibration | Tetlock & Gardner; Gneiting & Raftery | run `/performance` on paper trades; compute Brier score of your beliefs vs outcomes |
| 3–4 | Microstructure & fees | Harris (ch. on order types, costs) | compare paper vs demo fills (AUDIT F-02); recompute edges with the real fee schedule |
| 5–6 | Kelly and estimation error | MacLean–Thorp–Ziemba (fractional Kelly chapters); Cover & Thomas | reproduce thesis §3.2 numbers; vary `kellyScale` |
| 7–8 | Time series | Hamilton (unit roots, ARCH); Tsay | read `src/util/stats.js` with its tests; try the volatility strategy on *recorded* data only |
| 9 | Backtest hygiene | López de Prado; Hastie et al. | write a pre-registered test plan (thesis §8 item 3) |
| 10 | Reliability & idempotency | Kleppmann; Saltzer–Kaashoek | trace a lost-response scenario through `broker.js` |
| 11 | Safety engineering | Leveson; Perrow | list your own hazards and add one control + one test |
| 12 | Security & law | Anderson; Lessig; take legal advice | threat-model your own deployment; re-read AUDIT §1 |

## K. Language models, AI safety and security (added for the Qwen module)

| Title | Author(s) | Publisher | Institution | Why |
|---|---|---|---|---|
| ★ 🆓 *Understanding Deep Learning* | S. J. D. Prince | MIT Press, 2023 | University of Bath | clear modern treatment of transformers/LLMs — what the model in `src/ai/qwen.js` actually is |
| 🆓 *Deep Learning* | I. Goodfellow, Y. Bengio, A. Courville | MIT Press, 2016 | Université de Montréal | foundations, regularisation, optimisation |
| ★ *Adversarial Machine Learning* | A. D. Joseph, B. Nelson, B. I. P. Rubinstein, J. D. Tygar | Cambridge UP, 2019 | UC Berkeley / Univ. of Melbourne | threat models for learning systems — the lens for headline-injection (docs/QWEN.md §7) |
| 🆓 *Forecasting: Principles and Practice* | R. J. Hyndman, G. Athanasopoulos | OTexts (3rd ed.) | Monash University | forecast evaluation, scoring and accuracy measures; how to compare a model against a benchmark |
| *Statistical Rethinking* | R. McElreath | CRC Press, 2nd ed. 2020 | Max Planck Institute for Evolutionary Anthropology | reasoning about uncertainty and model comparison without p-value rituals |

**Papers:** Greshake et al. 2023 (indirect prompt injection in LLM-integrated applications) · Perez & Ribeiro 2022 (“Ignore previous prompt”) · Qwen Team 2025 (*Qwen3 Technical Report*, arXiv:2505.09388) —
citations in docs/THESIS.md; confirm details before formal use.

**Optional weeks 13–14:** Prince (transformer chapters) + Joseph et al. (threat-model chapter), then run `npm run qwen:eval` on a real model, write ten injection headlines of your own, and see which ones move the stance.
