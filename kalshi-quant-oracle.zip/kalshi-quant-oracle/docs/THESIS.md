# Fail-Safe Automation on Event-Contract Markets
## An interdisciplinary study of re-hosting a prediction-market trading bot onto free-tier cloud infrastructure

*A doctoral-style thesis accompanying kalshi-quant-telebot-node v1.0.0.*
*Disciplines: computer systems · financial economics · statistics & econometrics · decision theory · safety engineering & human factors · cloud economics · law & ethics.*

> **Epistemic status (read first).** This is an engineering-science thesis about a *system and its reasoning*, not an
> empirical study of trading performance. No backtest was run, no live market data touched this build, and nothing here
> shows that any strategy earns money. Claims are of three kinds and are labelled: **[T]** theorem or arithmetic that can be
> checked by hand, **[V]** verified by the project's test suite (92 tests, offline, including whole-process runs against mock exchange / Telegram / Ollama servers), **[D]** documented by a primary source
> and not independently re-verified. Citations were written without a live library lookup — verify before formal reuse.

---

## Abstract

Automated trading on event-contract exchanges combines two hazards rarely studied together: **financial** (an unproven
edge, fees, estimation error in position sizing) and **operational** (a remote-controlled program holding exchange
credentials, hosted on infrastructure whose provider can remove it). We study the re-hosting of an open-source Kalshi trading bot
(Python engine plus two Node services) onto Oracle Cloud's Always Free tier, where a 1 GB machine, an idle-reclamation policy and
a reduced Ampere allowance (2 OCPU / 12 GB on Oracle's current page; earlier sources say 4 / 24) constrain design. Using a design-science method we produce a single-process, zero-dependency Node 24
implementation and analyse it across disciplines. We show **[T]** that mutually exclusive event contracts admit an exact,
estimation-free arbitrage condition (Σ best YES bids > 1 + fees) and that declared implications between contracts admit another;
**[T]** that full-Kelly sizing on an *estimated* probability can have negative expected log-growth — in a worked example the
estimate-based stake is 2.56× the true optimum and loses 0.30 % per bet, whereas quarter-Kelly gains 0.18 %; **[V]** that layered,
independent controls (mode gate, halts, caps, sizing, exits, allowlisted control plane, confirmation buttons) can be made testable
offline; and **[D]** that a lightweight bot is, by Oracle's published criteria, indistinguishable from an idle instance — turning
a billing policy into a reliability requirement. Two audit passes surfaced 28 defects; two are instructive — a micro-optimised
timer that made the process exit silently, and an RSS parser whose regexes were quadratic, so that one hostile 1 MB feed froze the single event loop for over a
minute — and show how resource-conscious or merely convenient code defeats operational assumptions. Version 1.1 adds an optional local LLM (Qwen) news analyst
and a dashboard; because a path from untrusted text to orders is a security boundary, the LLM ships in *shadow mode* with a falsifiable scoring-rule evaluation
**[T,V]**. We
conclude that the dominant risks of such a system are not algorithmic but *epistemic* (believing documentation, backtests or paper
P&L) and *socio-technical* (control planes, alert design, provider policy), and we give a falsifiable evaluation agenda.

---

## 1. Introduction

### 1.1 Problem
Prediction markets (event contracts that pay $1 if an event occurs) have moved from academic curiosity to regulated retail
venues. Open-source bots promise "institutional-quality" automation. Three questions follow for anyone who deploys one:
is the claimed capability real; can it be run cheaply and safely; and what can go wrong that the README does not say?

### 1.2 Research questions
* **RQ1 (systems).** Can a documented-behaviour trading system be re-hosted to a resource-constrained free-tier VM without losing its key safety properties?
* **RQ2 (risk).** When strategy edge is *unproven*, which controls matter most, and how should they be structured?
* **RQ3 (economics).** What exact, estimation-free opportunities exist in mutually exclusive event contracts, and how sensitive are they to fees?
* **RQ4 (operations & policy).** How should a provider's resource-reclamation policy be treated by system design?

### 1.3 Contributions
(1) A port with fail-safe defaults and a layered risk architecture; (2) a derivation of two riskless-basket conditions and a
worked fee analysis; (3) a demonstration that Kelly sizing needs fractional scaling under estimation error; (4) an analysis of
idle-reclamation as a design constraint; (5) a catalogue of documentation-vs-reality gaps (PORT_MAP) and a defect log; (6) a
reproducible, offline-testable artefact and a verification agenda for the parts that could not be tested.

### 1.4 Method
Design science (build an artefact, evaluate against requirements, reflect). Evidence: primary documentation (Kalshi's API and
fixed-point-migration pages; Oracle's Always Free page, rev. 12 Jun 2026), the upstream README, automated tests, and review.
**Limitation of the source material:** the upstream repository's individual source files were not retrievable, so the artefact
implements the documented behaviour (PORT_MAP §0) — itself a finding about the fragility of "reading the README" as a
specification.

---

## 2. Background and literature

**2.1 Prediction markets.** Event contracts aggregate dispersed information into prices interpretable as probabilities under
conditions (Wolfers & Zitzewitz 2004; Arrow et al. 2008), with caveats: risk attitudes, bounded budgets and liquidity make the
price-to-probability map imperfect (Manski 2006); the favourite–longshot bias is a documented distortion (Snowberg & Wolfers 2010);
calibration varies by market (Page & Clemen 2013). Hanson's market-scoring rules show how combinatorial markets can be made
coherent (Hanson 2003/2007) — relevant because *incoherence* (probabilities violating logical constraints) is exactly what
arbitrage detects (§3.3–3.4).

**2.2 Efficiency and the limits of edge.** Fama (1970) frames what "beating the market" would require; Grossman & Stiglitz
(1980) argue that perfectly efficient prices are impossible when information is costly — so some edge must exist, but is
competed away to the cost of acquiring it. Lo's adaptive-markets view (2017) predicts edges that decay as they are found. For a
hobbyist bot the prior should be **no edge after fees** until shown otherwise.

**2.3 Position sizing.** Kelly (1956) derived the growth-optimal stake; Thorp (2006) and MacLean, Thorp & Ziemba (2011)
document its power and its fragility — over-betting beyond ≈ 2× the optimum yields negative growth, and estimation error makes
over-betting likely, motivating fractional Kelly.

**2.4 Time series.** Unit-root testing (Dickey & Fuller 1979), cointegration (Engle & Granger 1987; critical values from
MacKinnon), and conditional heteroskedasticity (Engle 1982; Bollerslev 1986) are standard (Hamilton 1994; Tsay 2010).
Their assumptions (I(1) series, stable parameters, ample data) fit bounded, short, regime-prone event-contract prices poorly.

**2.5 Safety engineering and human factors.** Accidents in tightly coupled systems are "normal" (Perrow 1984); error is a
property of system design not operators (Reason 1990; Dekker 2014); safety is a control problem over a socio-technical
structure (Leveson 2011). The 2012 Knight Capital incident — a deployment inconsistency that produced uncontrolled orders, later the
subject of an SEC order (2013) — is the canonical reminder that automation needs independent kill-switches. Saltzer & Schroeder
(1975)'s principles (least privilege, fail-safe defaults, economy of mechanism) are directly applicable.

**2.6 Cloud economics.** "Free" tiers are provider policy, not property (Armbrust et al. 2010 on elasticity and risk of
provider dependence). Oracle's Always Free page defines allowances and an idle-reclamation rule (§3.6).

**2.7 Law, regulation and ethics.** Kalshi operates as a CFTC-regulated exchange; automated access is governed by its terms and
by the user's jurisdiction. Lessig (1999) argues that code is a regulator; here, the bot's architecture *is* the compliance and
safety regime for its user. This thesis offers no legal advice.

---

## 3. Theory

### 3.1 Binary contracts and fee-adjusted edge
A contract pays 1 if the event occurs, else 0. Buying at price *a* with a taker fee *φ(C,a) = ⌈0.07·C·a(1−a)⌉ (rounded up to the
cent)* **[D — Kalshi fee schedule; coefficient assumed, configurable]** has effective per-contract cost *c = a + φ/C*. If your
probability is *p*, expected profit per contract is *p − c*; the bot requires it to exceed `minEdge` (3¢ default). Rounding
up to the cent makes small orders expensive: one contract at 60¢ pays 2¢ in fees; 100 contracts pay 1.68¢ each **[T,V]**.

### 3.2 Kelly sizing under estimation error
For a binary bet with net odds *b = (1−c)/c* the log-growth is *g(f) = p·ln(1+fb) + (1−p)·ln(1−f)*, maximised at
**f\* = (p − c)/(1 − c)** (equal to the README's generic form; tested **[V]**).
*Worked example [T, computed by the project's code].* Price 45¢, per-contract fee 1.8¢ ⇒ c = 0.468. A bettor *estimates* p̂ = 0.55:
f̂ = 15.4 % of bankroll. Suppose the truth is p = 0.50: the true optimum is f\* = 6.0 %, so f̂ is **2.56×** optimal, and
expected log-growth per bet is **−0.297 %** (a slow ruin), whereas quarter-Kelly (3.85 % = 0.64× optimal) earns **+0.179 %**
(the true optimum earns +0.205 %). *Moral:* the loss function is asymmetric — under-betting costs little, over-betting past ≈ 2× costs
everything — so fractional Kelly (`kellyScale = 0.25`) is not timidity but robust decision-making under model error. The code
additionally caps stake at 10 % of bankroll per position and 50 contracts per order, independent of Kelly.

### 3.3 Exact arbitrage in mutually exclusive events
Let an event have *k* markets of which at most one resolves YES: Σ Xᵢ ≤ 1, Xᵢ ∈ {0,1}. A NO contract on market *i* pays 1 − Xᵢ.
The basket of one NO per market pays **k − ΣXᵢ ≥ k − 1** in every state. Its cost is Σ (1 − bᵢ) where *bᵢ* is the best YES bid
(the NO ask is the complement of the opposing bid in a binary book). Hence profit per set ≥ **Σ bᵢ − 1 − F**, positive iff
**Σ bᵢ > 1 + F** **[T]**. No probability estimate is involved; *exhaustiveness is not needed* (any subset works). Example (3
markets, each YES bid 40¢): gross 20¢/set; fees 6¢ (1 contract/leg), 5.1¢ (10), 5.04¢ (100); net 14–15¢ **[T,V]**.
Residual risks are **execution** (legs fill independently — partial baskets), **specification** (the exchange's "mutually exclusive"
flag must be right), and **competition** (such gaps should be rare and short-lived; their frequency is an empirical question this
project cannot answer without order-book history).

### 3.4 Implication arbitrage
If A ⇒ B then X_A ≤ X_B. The pair {NO(A), YES(B)} pays (1−X_A)+X_B ≥ 1 in every state at cost (1−b_A)+a_B, so profit ≥
**b_A − a_B − F** **[T]**. The relation must be *declared by a human* from the contracts' rules; the program never infers it.

### 3.5 Cointegration on bounded prices
Engle-Granger presumes I(1) levels. Event-contract prices are confined to (0,1) and converge to {0,1} at expiry, so
non-stationarity is of a different kind; tests may reject or fail to reject for the wrong reasons. The strategy is therefore opt-in,
low-confidence and not auto-executed live **[design decision]**. The implementation is correct as a statistical routine **[V]**
(it flags a synthetic cointegrated pair and not independent walks), which says nothing about its trading value.

### 3.6 Reliability and policy
*Execution semantics.* Over a network, an order request has three outcomes: success, failure, **unknown**. Exactly-once cannot be
had; the system uses at-most-once submission (no blind POST retries) plus idempotency keys and later reconciliation
(`client_order_id`, 409 handling, exchange-vs-ledger comparison) **[V]**. On shutdown, reads are aborted but an in-flight order is
allowed to finish so that the ledger cannot orphan a live position **[V]**.
*Provider policy.* Oracle's page states an instance is idle if, over 7 days, CPU 95th percentile < 20 % **and** network < 20 %
**and** (A1) memory < 20 %, and that idle Always Free instances may be reclaimed **[D]**. Measured idle footprint of this bot ≈ 64 MB
RSS (Node 22, sandbox) — far below 20 % of 1 GB on CPU/network terms too. *A correctly lightweight service therefore meets the
provider's definition of abandonment.* Design response: treat the host as disposable (state small/atomic; daily archives; one-command
rebuild; absent-data alarm) rather than gaming the metric with synthetic load.

---

### 3.7 LLM-assisted stance estimation: a scoring-rule test and an injection bound
A news model is useful only if its judgement carries information *beyond the market price*. For an assessment with stance σ∈[−1,1], confidence c and relevance r, define the adjusted
probability p₁ = p₀ + s with **s = 0.10·σ·c·r** (|s| ≤ 0.10) and compare Brier scores against the 0/1 outcome y: **ΔB = (p₁−y)² − (p₀−y)² = s² + 2s(p₀−y)** **[T]**. ΔB < 0 on average means the model
improved on the market; the sign of the cross term is exactly "did the stance point toward the outcome". Assessments of one market share one outcome, so uncertainty is estimated with a **cluster
bootstrap over markets**, not rows (the project's `shadowReport`; on synthetic data it detects an informative model and does not flatter a noise model **[V]**). This test is necessary, not sufficient: fees,
spreads and execution must still be beaten.
*Injection bound.* Headlines are attacker-controllable text on a path to orders. Whatever the model emits is clamped, so a fully compromised answer can move a fair value by at most 0.10 and |ΔB| ≤ 0.01 + 0.2 = 0.21
per assessment **[T]**; a trade then still needs ≥ 2 independent sources, a net edge above fees, the position cap (10 % of bankroll), the stop-loss (5 % of cost) and the daily-loss breaker (2 % of bankroll). To first
order — *assuming stops fill; binary markets can gap* — the damage an adversary can induce before the breaker halts new entries is of the order of the breaker size, not of the bankroll. This is the
quantitative content of "bounded influence" and the reason the model runs in shadow mode first.

## 4. System design (method in practice)

Requirements: R1 fits 1 GB; R2 fails safe; R3 testable offline; R4 portable x64/arm64; R5 rebuildable; R6 honest about unknowns.
Decisions and the disciplines that justify them:

| Decision | Discipline | Rationale (full records: ARCHITECTURE) |
|---|---|---|
| One process, zero dependencies | systems, security | RAM; fewer IPC failures; no transitive code beside a private key |
| Signed requests (RSA-PSS/Ed25519), not bearer keys | security | what the exchange actually requires |
| Paper default; trading OFF after every start; ack for real money | safety engineering | fail-safe defaults (Saltzer–Schroeder) |
| Layered, independent risk controls | safety engineering | no single point of control failure (Leveson) |
| Fractional Kelly net of fees | decision theory | §3.2 |
| Exact-bound arbitrage as the only default strategy; heuristics off | economics, statistics | §2.2, §3.3–3.5 |
| Allowlist, setup mode, confirmations, replay guard | human factors, security | the chat is a remote control for money |
| Reconcile, don't auto-fix | operations | with real money a human resolves ambiguity |
| Per-mode state, atomic writes, quarantine of corrupt files | reliability | no mixed books; no silent loss |
| Rebuild-first operations | cloud economics | §3.6 |

---

## 5. Evaluation

### 5.1 What was verified [V]
92 offline tests (no external network): request signing for both key types **verified server-side** by a strict mock exchange (wrong key, wrong ID and a 10-minute clock skew are
rejected); both Kalshi field vintages normalise identically; fee formula; ledger accounting incl. restart; Kelly equality with the generic form; statistical routines on seeded
data; arbitrage detection and non-detection (non-exclusive events never traded); full trading cycles (entries, hold-to-settlement, stop-loss, daily-loss halt and `/resume`,
exchange halt, API outage and recovery, mismatch alerting, partial baskets, unknown order outcomes, persistence failure); Telegram authorisation matrix, also over real HTTP
against a mock Telegram; REST/WebSocket security and fuzzing; every unsafe configuration refused at startup; **whole-process runs** in paper mode (no order ever sent) and
live-demo mode (three signed IOC orders, clean reconciliation, an outside position flagged without any corrective order); the Qwen provider against a mock Ollama (schema,
caching, circuit breaker, timeouts, injection hygiene, shadow vs trade strategy, evaluation and shadow-report scripts); the dashboard script against the real API.
**Mutation check:** 20 deliberately broken versions of safety-critical code (allowlist, real-money gate, stop-loss, loss breaker, hold flag, auth, signature path, paper mode, sanitiser,
shadow mode, source-agreement rule, clamps, circuit breaker, CSP, key validation, socket reaping, response cap, autostart, innerHTML) — all 20 caught; the one that first survived led to a new test.

### 5.2 What was not [limits]
Any contact with the real Kalshi or Telegram APIs; an Oracle VM; systemd/SELinux behaviour; long soak; fuzzing; backtesting.
The smoke script (`smoke:demo`) is the designed bridge for the first.

### 5.3 Threats to validity
*Construct:* "passes tests" ≠ "correct against the exchange" (mocks encode my reading of the docs). *Internal:* self-audit
(author = reviewer). *External:* one exchange schema vintage (Nov 2026), one provider policy vintage (Jun 2026 page).
*Specification:* the upstream source was unreadable, so fidelity to upstream is unknown (PORT_MAP §3).

### 5.4 Defects as data
Twenty-eight defects were found by tests or review across two passes (AUDIT §4). Two are case studies.
*(a) The silent exit.* The heartbeat timer was `unref()`'d — a common micro-optimisation so timers don't hold a process open — which, with neither API nor Telegram active, emptied the event
loop and the program **exited with status 0**, a "success" that systemd's `Restart=on-failure` would not repair. It was found only by *measuring memory*, not by any functional test.
*(b) The quadratic parser.* The first RSS parser used lazy-quantifier regexes; on hostile input they are **O(n²)**: 37 s for 1 MB of unclosed tags, 76 s for 80 000 unclosed CDATA openers —
on the one thread that also runs stop-losses, Telegram polling and the API. Nothing in the functional tests would ever trigger it; a deliberate adversarial probe did. The fix (indexOf scans, caps,
streamed reads) takes milliseconds. Both bugs arise where a local convenience violates a global assumption ("this process runs forever", "inputs are polite"), and both are now regression-tested.

---

## 6. Interdisciplinary discussion

**Economics.** The defensible default hypothesis is *no net edge*. The only strategy class with an edge that doesn't rely on beliefs about
probabilities is exact-bound arbitrage, and its profitability depends on frequency and competition we could not measure. The sentiment and
volatility strategies are retained for parity with the original but are, in effect, hypotheses — and ship disabled.

**Statistics.** Strategy selection by trying variants on historical data invites backtest overfitting and multiple-testing error
(Bailey et al. 2014; Harvey & Liu 2015; López de Prado 2018). This project therefore ships *no* backtest and no tuned parameters; defaults are
conservative priors, and the evaluation agenda (§8) specifies pre-registered, out-of-sample tests.

**Safety and human factors.** The control plane (a chat app) is both the most usable and the most dangerous interface. Controls follow the
STAMP lens: constrain *who* may issue commands (allowlist), *when* (freshness), *what needs a second act* (confirmation buttons), and *what the
system does on its own* (halts). Alert fatigue is managed by de-duplication (errors, opportunities, position mismatches) and by reserving
🚨 for events needing a human.

**AI in the loop.** A language model reading news adds *capability* (stance, paraphrase, multilingual input — Qwen3 is trained on 100+ languages) and *attack surface* (prompt injection through
untrusted text, hallucination, latency). The design stance is "capability only after evidence, and bounded even then": local inference (no data leaves the host), shadow mode with an observer hook so data
accumulates at zero risk, schema-constrained output that is nevertheless re-validated and clamped, a background worker so a slow model can never stall exits, and a pre-registered-style evaluation (§3.7)
before `QWEN_TRADE` may be turned on. The honest limit: no real Qwen was run in the build environment (mock model only), and the multilingual strength is only partly realised because candidate pairing is lexical.

**Ethics and law.** Automation does not transfer responsibility. The artefact refuses to be dangerous by default, makes its own limits
legible (README banner, AUDIT), and avoids marketing claims ("institutional-quality", "sub-second") that it cannot support. Users must check
Kalshi's terms and local law; the software gives no advice.

**Cloud economics.** A free allowance is a revocable licence. The Ampere allowance now stated as 2 OCPU / 12 GB (Oracle's June 2026 page; widely quoted earlier figures were 4 / 24)
and the idle rule show that *policy drift* is a first-class operational risk; the design absorbs it through disposability, not optimism.

**Documentation as specification.** The upstream README told users to authenticate with a bearer key, which doesn't match the exchange's
signed-request scheme, and described "IP-based authentication" as access control. Documentation drifts from code and from reality; the response
here is a traceability table (README ↔ code ↔ deployment ↔ audit), a verified/unverified ledger in the manifest, and a smoke test that checks the
world rather than the docs.

---

## 7. Limitations
Self-audit; mock-based verification; assumed fee model; no market-data history; single-instance design; limited statistical power of the
heuristics; US-exchange specifics; no human-subject evaluation of the Telegram UX.

## 8. Future work and falsifiable evaluation agenda
1. **Close the verification gap:** run `smoke:demo`; record exchange rejections; update `broker.js`/`client.js` (one-file blast radius).
2. **Measure arbitrage frequency:** log, for ≥ 90 days, every exclusive event's Σ bids and net-of-fee edge at the top of book *without trading*; report
   frequency, size, and half-life. H₀: median net edge ≤ 0 after fees and depth.
3. **Calibrate before betting:** compute Brier/log scores (Brier 1950; Gneiting & Raftery 2007) of any probability model against resolved markets, out-of-sample,
   with pre-registered hypotheses and a multiple-testing correction. *The project now ships the instrument* (`npm run qwen:shadow-report`, §3.7): run it after 4–8 weeks of shadow logging.
4. **Execution quality:** compare paper vs demo vs live fill prices to estimate the optimism bound of paper P&L (F-02).
5. **Operations:** one quarter of uptime/reclamation data per shape; compare PAYG-upgraded vs free-only reclamation rates.
6. **Security:** independent review; fuzz the WebSocket parser; move secrets to OCI Vault.
7. **Human factors:** instrument notification volume and time-to-acknowledge for risk events.
8. **Real model, real labels:** run `qwen:eval` against a real Qwen on ≥ 300 human-labelled held-out headlines; measure latency on Ampere cores; replace lexical pairing with LLM- or embedding-based pairing (AUDIT F-29).
9. **Adversarial testing of the LLM path:** a red-team corpus of injection headlines against the real model, measuring how often stance/relevance move beyond what the text warrants.

## 9. Conclusion
Re-hosting the bot on a free 1 GB machine is feasible (RQ1) *because* the heavy parts of the original were the least defensible parts — a
transformer stack and three processes — while the safety-critical parts are small. When edge is unproven, the controls that matter most are the
ones that bound damage independently of the strategy (RQ2): fail-safe defaults, halts, fractional sizing, and a locked-down control plane. Exact-bound
arbitrage conditions exist and are simple (RQ3), but whether they are *available* is empirical. And a provider's idle rule turns a lightweight service into
a disposable one (RQ4). The deepest result is methodological: in systems that touch money, **believe your tests only as far as they touch the world**, and
build the bridge to the world (the smoke test, the reconciliation, the alarms) before building more strategy.

---

## References
*(Verify details before formal citation; see READING_LIST.md for books.)*

* Arrow, K. J., et al. (2008). The promise of prediction markets. *Science*, 320(5878), 877–878.
* Armbrust, M., et al. (2010). A view of cloud computing. *Communications of the ACM*, 53(4), 50–58.
* Bailey, D. H., Borwein, J. M., López de Prado, M., & Zhu, Q. J. (2014). Pseudo-mathematics and financial charlatanism. *Notices of the AMS*, 61(5), 458–471.
* Bollerslev, T. (1986). Generalized autoregressive conditional heteroskedasticity. *Journal of Econometrics*, 31(3), 307–327.
* Brier, G. W. (1950). Verification of forecasts expressed in terms of probability. *Monthly Weather Review*, 78(1), 1–3.
* Dekker, S. (2014). *The Field Guide to Understanding 'Human Error'* (3rd ed.). CRC Press.
* Dickey, D. A., & Fuller, W. A. (1979). Distribution of the estimators for autoregressive time series with a unit root. *JASA*, 74(366), 427–431.
* Engle, R. F. (1982). Autoregressive conditional heteroscedasticity with estimates of the variance of U.K. inflation. *Econometrica*, 50(4), 987–1007.
* Engle, R. F., & Granger, C. W. J. (1987). Co-integration and error correction. *Econometrica*, 55(2), 251–276.
* Fama, E. F. (1970). Efficient capital markets: a review of theory and empirical work. *Journal of Finance*, 25(2), 383–417.
* Gneiting, T., & Raftery, A. E. (2007). Strictly proper scoring rules, prediction, and estimation. *JASA*, 102(477), 359–378.
* Grossman, S. J., & Stiglitz, J. E. (1980). On the impossibility of informationally efficient markets. *American Economic Review*, 70(3), 393–408.
* Greshake, K., et al. (2023). Not what you've signed up for: compromising real-world LLM-integrated applications with indirect prompt injection. *Proceedings of the ACM Workshop on Artificial Intelligence and Security (AISec)*.
* Hamilton, J. D. (1994). *Time Series Analysis*. Princeton University Press.
* Hanson, R. (2003). Combinatorial information market design. *Information Systems Frontiers*, 5(1), 107–119.
* Hanson, R. (2007). Logarithmic market scoring rules for modular combinatorial information aggregation. *Journal of Prediction Markets*, 1(1), 3–15.
* Harvey, C. R., & Liu, Y. (2015). Backtesting. *Journal of Portfolio Management*, 42(1), 13–28.
* Kelly, J. L., Jr. (1956). A new interpretation of information rate. *Bell System Technical Journal*, 35(4), 917–926.
* Lessig, L. (1999). *Code and Other Laws of Cyberspace*. Basic Books.
* Leveson, N. G. (2011). *Engineering a Safer World*. MIT Press.
* Lo, A. W. (2017). *Adaptive Markets*. Princeton University Press.
* López de Prado, M. (2018). *Advances in Financial Machine Learning*. Wiley.
* MacKinnon, J. G. (2010). *Critical values for cointegration tests* (Queen's Economics Department Working Paper No. 1227).
* MacLean, L. C., Thorp, E. O., & Ziemba, W. T. (Eds.). (2011). *The Kelly Capital Growth Investment Criterion*. World Scientific.
* Manski, C. F. (2006). Interpreting the predictions of prediction markets. *Economics Letters*, 91(3), 425–429.
* Page, L., & Clemen, R. T. (2013). Do prediction markets produce well-calibrated probability forecasts? *Economic Journal*, 123(568), 491–513.
* Perez, F., & Ribeiro, I. (2022). Ignore previous prompt: attack techniques for language models. *NeurIPS ML Safety Workshop*.
* Perrow, C. (1984). *Normal Accidents*. Basic Books.
* Qwen Team (2025). *Qwen3 Technical Report*. arXiv:2505.09388.
* Reason, J. (1990). *Human Error*. Cambridge University Press.
* Saltzer, J. H., & Schroeder, M. D. (1975). The protection of information in computer systems. *Proceedings of the IEEE*, 63(9), 1278–1308.
* SEC (2013). *In the Matter of Knight Capital Americas LLC*, Exchange Act Release No. 70694.
* Snowberg, E., & Wolfers, J. (2010). Explaining the favorite–long shot bias. *Journal of Political Economy*, 118(4), 723–746.
* Thorp, E. O. (2006). The Kelly criterion in blackjack, sports betting, and the stock market. In *Handbook of Asset and Liability Management*. Elsevier.
* Tsay, R. S. (2010). *Analysis of Financial Time Series* (3rd ed.). Wiley.
* Wolfers, J., & Zitzewitz, E. (2004). Prediction markets. *Journal of Economic Perspectives*, 18(2), 107–126.
* Primary technical sources used: Kalshi API documentation (docs.kalshi.com — API keys, authenticated requests, create order, fixed-point migration, subpenny pricing), accessed Nov 2026;
  Oracle Cloud Infrastructure, *Always Free Resources* (docs.oracle.com), page revision 12 Jun 2026; upstream README of yllvar/Kalshi-Quant-TeleBot, accessed Nov 2026.
