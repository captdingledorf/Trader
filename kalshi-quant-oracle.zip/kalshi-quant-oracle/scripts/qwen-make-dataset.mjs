#!/usr/bin/env node
/**
 * @file scripts/qwen-make-dataset.mjs
 * Docs: docs/QWEN.md §"Fine-tuning (optional)"
 *
 * Turns labelled rows (same format as qwen-eval.mjs) into a chat-format SFT file — one JSON object per line with
 * {"messages":[system,user,assistant]} — ready for LoRA/QLoRA tooling (Unsloth, LLaMA-Factory, axolotl, TRL).
 * The assistant turn is the exact JSON the runtime validator expects. It never trains anything itself.
 *
 *   node scripts/qwen-make-dataset.mjs in.jsonl out.sft.jsonl [--split 0.9]   (writes out.sft.jsonl + out.val.jsonl)
 */
import { readFileSync, writeFileSync } from 'node:fs';
import { SYSTEM_PROMPT, sanitize } from '../src/ai/qwen.js';

const [inp, outp] = process.argv.slice(2).filter((a) => !a.startsWith('--'));
if (!inp || !outp) { console.error('usage: qwen-make-dataset.mjs in.jsonl out.sft.jsonl [--split 0.9]'); process.exit(2); }
const si = process.argv.indexOf('--split');
const split = si > -1 ? Number(process.argv[si + 1]) : 0.9;
const rows = readFileSync(inp, 'utf8').split('\n').filter(Boolean).map((l) => JSON.parse(l));
const example = (r) => {
  const relevant = r.relevant ?? true;
  const answer = { relevance: relevant ? 0.9 : 0.05, stance: relevant ? r.stance * 0.8 : 0, sentiment: r.sentiment ?? r.stance * 0.6, confidence: relevant ? 0.8 : 0.3, event_type: r.event_type ?? 'other', novelty: r.novelty ?? 'developing', language: r.lang ?? 'en', entities: r.entities ?? [], rationale: r.rationale ?? '' };
  const user = `<market>${sanitize(r.market, 220)}</market>\n<headline source="dataset">${sanitize(r.headline, 300)}${r.summary ? `\n${sanitize(r.summary, 500)}` : ''}</headline>\nAssess this headline for the market above. /no_think`;
  return { messages: [{ role: 'system', content: SYSTEM_PROMPT }, { role: 'user', content: user }, { role: 'assistant', content: JSON.stringify(answer) }] };
};
// deterministic shuffle so reruns give the same split
const order = rows.map((r, i) => [(Math.sin(i + 1) * 10000) % 1, r]).sort((a, b) => a[0] - b[0]).map((x) => x[1]);
const cut = Math.max(1, Math.floor(order.length * split));
writeFileSync(outp, order.slice(0, cut).map((r) => JSON.stringify(example(r))).join('\n') + '\n');
writeFileSync(outp.replace(/\.sft\.jsonl$|\.jsonl$/, '.val.jsonl'), order.slice(cut).map((r) => JSON.stringify(example(r))).join('\n') + '\n');
console.log(`wrote ${cut} train + ${order.length - cut} validation examples`);
