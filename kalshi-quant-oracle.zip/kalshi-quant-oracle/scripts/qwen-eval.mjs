#!/usr/bin/env node
/**
 * @file scripts/qwen-eval.mjs
 * Docs: docs/QWEN.md §"Evaluate before you trust" · docs/AUDIT.md F-21
 *
 * Scores the configured local Qwen model against a labelled JSONL file and compares it with the built-in lexicon scorer.
 * Row format:  {"market": "...", "headline": "...", "summary"?: "...", "stance": -1|0|1, "relevant"?: bool, "lang"?: "en"}
 * Metrics: JSON-validity rate, 3-class stance accuracy + macro-F1 + confusion matrix, stance MAE, relevance accuracy,
 *          per-language accuracy, latency p50/p95 — for Qwen AND for the lexicon baseline.
 *
 *   QWEN_URL=http://127.0.0.1:11434 QWEN_MODEL=qwen3:1.7b node scripts/qwen-eval.mjs [--data file] [--out report.json] [--limit N] [--deadzone 0.25]
 *
 * The seed file (data/qwen_eval_seed.jsonl) is 33 SYNTHETIC rows written for this project: enough to prove the pipeline and
 * catch gross failures — NOT a benchmark. Replace it with real, held-out, human-labelled headlines before drawing conclusions.
 */
import { readFileSync, writeFileSync } from 'node:fs';
import { loadDotEnv, loadConfig } from '../src/config.js';
import { QwenProvider } from '../src/ai/qwen.js';
import { scoreText, tokens, relevance } from '../src/data/news.js';

loadDotEnv(process.env.ENV_FILE ?? '.env');
const arg = (n, d) => { const i = process.argv.indexOf(`--${n}`); return i > -1 ? process.argv[i + 1] : d; };
const dataFile = arg('data', new URL('../data/qwen_eval_seed.jsonl', import.meta.url).pathname);
const out = arg('out', null);
const limit = Number(arg('limit', 1e9));
const dz = Number(arg('deadzone', 0.25));

const { cfg } = await loadConfig({ ...process.env, DATA_DIR: process.env.DATA_DIR ?? '/tmp/qwen-eval', QWEN_ENABLED: 'true' });
const qwen = new QwenProvider({ cfg: { ...cfg.qwen, enabled: true }, logger: null });
const health = await qwen.health();
if (!health.ok) { console.error(`Qwen endpoint ${cfg.qwen.url} is not reachable: ${health.error}`); process.exit(3); }
if (health.modelPresent === false) console.error(`warning: model "${cfg.qwen.model}" not listed by the server (found: ${health.models.join(', ') || 'none'})`);

const rows = readFileSync(dataFile, 'utf8').split('\n').filter(Boolean).map((l) => JSON.parse(l)).slice(0, limit);
const cls = (x) => (x > dz ? 1 : x < -dz ? -1 : 0);
const idx = (c) => c + 1;
const mat = () => [[0, 0, 0], [0, 0, 0], [0, 0, 0]];
const q = { cm: mat(), abs: 0, n: 0, relOk: 0, relN: 0, lat: [], invalid: 0, byLang: {} };
const l = { cm: mat(), abs: 0, n: 0, relOk: 0, relN: 0, byLang: {} };
const acc = (cm) => { const t = cm.flat().reduce((a, b) => a + b, 0); return t ? (cm[0][0] + cm[1][1] + cm[2][2]) / t : 0; };
const f1 = (cm) => { let s = 0; for (let c = 0; c < 3; c++) { const tp = cm[c][c]; const fp = cm[0][c] + cm[1][c] + cm[2][c] - tp; const fn = cm[c][0] + cm[c][1] + cm[c][2] - tp; s += tp ? (2 * tp) / (2 * tp + fp + fn) : 0; } return s / 3; };
const bump = (m, lang, ok) => { (m.byLang[lang] ??= [0, 0]); m.byLang[lang][1] += 1; if (ok) m.byLang[lang][0] += 1; };

let i = 0;
for (const r of rows) {
  i += 1;
  const market = { ticker: `EVAL-${i}`, title: r.market, subtitle: '' };
  const h = { title: r.headline, summary: r.summary ?? '', source: 'eval' };
  const res = await qwen.assess(market, h);
  const truth = idx(Math.sign(r.stance));
  if (res.ok) {
    q.n += 1; q.lat.push(res.ms ?? 0);
    q.cm[truth][idx(cls(res.value.stance))] += 1; q.abs += Math.abs(res.value.stance - r.stance);
    bump(q, r.lang ?? '?', cls(res.value.stance) === Math.sign(r.stance));
    if (typeof r.relevant === 'boolean') { q.relN += 1; if ((res.value.relevance >= 0.5) === r.relevant) q.relOk += 1; }
  } else q.invalid += 1;
  const s = scoreText(r.headline);
  l.n += 1; l.cm[truth][idx(cls(s))] += 1; l.abs += Math.abs(s - r.stance);
  bump(l, r.lang ?? '?', cls(s) === Math.sign(r.stance));
  if (typeof r.relevant === 'boolean') { l.relN += 1; if ((relevance(tokens(r.market), r.headline) > 0) === r.relevant) l.relOk += 1; }
}
const pct = (a, b) => (b ? +(100 * a / b).toFixed(1) : null);
const lat = [...q.lat].sort((a, b) => a - b);
const report = {
  model: cfg.qwen.model, backend: cfg.qwen.backend, rows: rows.length, deadzone: dz,
  qwen: { validJsonPct: pct(rows.length - q.invalid, rows.length), stanceAccuracyPct: +(100 * acc(q.cm)).toFixed(1), macroF1: +f1(q.cm).toFixed(3), stanceMAE: q.n ? +(q.abs / q.n).toFixed(3) : null, relevanceAccuracyPct: pct(q.relOk, q.relN), confusion: q.cm, latencyMs: { p50: lat[Math.floor(lat.length / 2)] ?? null, p95: lat[Math.floor(lat.length * 0.95)] ?? null, mean: lat.length ? Math.round(lat.reduce((a, b) => a + b, 0) / lat.length) : null }, accuracyByLanguagePct: Object.fromEntries(Object.entries(q.byLang).map(([k, [a, b]]) => [k, pct(a, b)])) },
  lexiconBaseline: { stanceAccuracyPct: +(100 * acc(l.cm)).toFixed(1), macroF1: +f1(l.cm).toFixed(3), stanceMAE: +(l.abs / l.n).toFixed(3), relevanceAccuracyPct: pct(l.relOk, l.relN), accuracyByLanguagePct: Object.fromEntries(Object.entries(l.byLang).map(([k, [a, b]]) => [k, pct(a, b)])) },
  note: 'Seed data is synthetic. Rows = confusion[true][predicted] with order [-1, 0, +1].',
};
console.log(JSON.stringify(report, null, 2));
if (out) writeFileSync(out, JSON.stringify(report, null, 2));
process.exit(0);
