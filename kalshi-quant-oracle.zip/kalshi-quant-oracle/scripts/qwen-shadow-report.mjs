#!/usr/bin/env node
/**
 * @file scripts/qwen-shadow-report.mjs
 * Docs: docs/QWEN.md §"Evaluate before you trust"
 * Joins DATA_DIR/qwen_assessments.jsonl (written in shadow mode) with the resolved outcomes of those markets (public Kalshi
 * endpoint, no key needed) and prints Brier scores of: market price vs Qwen-adjusted vs lexicon-adjusted, with a cluster-bootstrap CI.
 *   node scripts/qwen-shadow-report.mjs [--log path/to/qwen_assessments.jsonl] [--out report.json]
 */
import { readFileSync, writeFileSync, existsSync } from 'node:fs';
import path from 'node:path';
import { loadDotEnv, loadConfig } from '../src/config.js';
import { KalshiClient } from '../src/kalshi/client.js';
import { shadowReport } from '../src/ai/shadowReport.js';

loadDotEnv(process.env.ENV_FILE ?? '.env');
const arg = (n, d) => { const i = process.argv.indexOf(`--${n}`); return i > -1 ? process.argv[i + 1] : d; };
const { cfg } = await loadConfig(process.env);
const logFile = arg('log', path.join(cfg.dataDir, 'qwen_assessments.jsonl'));
if (!existsSync(logFile)) { console.error(`no assessment log at ${logFile} — enable QWEN_ENABLED=true (shadow mode) and let it run`); process.exit(3); }
const rows = readFileSync(logFile, 'utf8').split('\n').filter(Boolean).map((l) => JSON.parse(l));
const client = new KalshiClient({ baseUrl: cfg.baseUrl, readRps: 4 });
const outcomes = new Map();
for (const t of new Set(rows.map((r) => r.ticker))) {
  try {
    const m = await client.getMarket(t);
    if (['determined', 'finalized', 'settled'].includes(m.status) && (m.result === 'yes' || m.result === 'no')) outcomes.set(t, m.result === 'yes' ? 1 : 0);
  } catch { /* market gone or API hiccup: skipped, reported via resolvedMarkets */ }
}
const rep = { logRows: rows.length, tickers: new Set(rows.map((r) => r.ticker)).size, ...shadowReport(rows, outcomes) };
console.log(JSON.stringify(rep, null, 2));
if (arg('out')) writeFileSync(arg('out'), JSON.stringify(rep, null, 2));
