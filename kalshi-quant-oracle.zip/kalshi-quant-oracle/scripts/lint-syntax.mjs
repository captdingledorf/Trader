#!/usr/bin/env node
/**
 * @file scripts/lint-syntax.mjs
 * Docs: README.md §"Development" · docs/AUDIT.md §"Verification evidence"
 * `node --check` every .js/.mjs file (no dependencies, so no eslint). Exit 1 on any failure.
 */
import { readdirSync, statSync } from 'node:fs';
import { spawnSync } from 'node:child_process';
import path from 'node:path';

const root = path.resolve(import.meta.dirname, '..');
const files = [];
const walk = (d) => {
  for (const n of readdirSync(d)) {
    if (n === 'node_modules' || n.startsWith('.')) continue;
    const p = path.join(d, n);
    if (statSync(p).isDirectory()) walk(p);
    else if (/\.(m?js)$/.test(n)) files.push(p);
  }
};
for (const d of ['src', 'test', 'scripts']) walk(path.join(root, d));
let bad = 0;
for (const f of files) {
  const r = spawnSync(process.execPath, ['--check', f], { encoding: 'utf8' });
  if (r.status !== 0) {
    bad += 1;
    console.error(`✗ ${path.relative(root, f)}\n${r.stderr}`);
  }
}
console.log(`${files.length - bad}/${files.length} files pass the syntax check`);
process.exit(bad ? 1 : 0);
