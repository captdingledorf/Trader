#!/usr/bin/env bash
# scripts/backup.sh — compress the bot's state directory and keep the newest N archives.
# Docs: README.md §"State & persistence" · docs/DEPLOYMENT_ORACLE.md Step 12 (backups)
# The data dir holds the ledger, trade log, price history and settings — NOT secrets (the Kalshi key,
# Telegram token and API token live in /etc/kalshi-bot, which you back up separately and privately).
set -euo pipefail
DATA_DIR="${DATA_DIR:-/var/lib/kalshi-bot}"
DEST="${BACKUP_DIR:-/var/backups/kalshi-bot}"
KEEP="${KEEP:-14}"
[[ -d "$DATA_DIR" ]] || { echo "data dir not found: $DATA_DIR" >&2; exit 1; }
umask 077
mkdir -p "$DEST"
ts="$(date -u +%Y%m%dT%H%M%SZ)"
out="$DEST/kalshi-data-$ts.tgz"
tar -C "$(dirname "$DATA_DIR")" -czf "$out" "$(basename "$DATA_DIR")"
# prune: keep the newest $KEEP archives
ls -1t "$DEST"/kalshi-data-*.tgz 2>/dev/null | tail -n +"$((KEEP + 1))" | xargs -r rm -f --
echo "backup written: $out ($(du -h "$out" | cut -f1))"
