#!/usr/bin/env node
/**
 * @file scripts/build-manifest.mjs
 * Docs: README.md §"Project manifest" · docs/ARCHITECTURE.md §"Manifest"
 *
 * PROJECT_MANIFEST.json is the project's permanent memory/scope record. The HUMAN-EDITED sections
 * (scope, decisions, assumptions, verification, open_items, change_log) are preserved verbatim; this
 * script only refreshes the machine-generated `files` inventory (path, bytes, lines, sha256).
 *   node scripts/build-manifest.mjs [--check]     (--check exits 1 if the inventory is stale)
 */
import { readFileSync, writeFileSync, readdirSync, statSync, existsSync } from 'node:fs';
import crypto from 'node:crypto';
import path from 'node:path';

const root = path.resolve(import.meta.dirname, '..');
const file = path.join(root, 'PROJECT_MANIFEST.json');
const SKIP = new Set(['node_modules', '.git', 'PROJECT_MANIFEST.json']);
const inv = [];
const walk = (d) => {
  for (const n of readdirSync(d).sort()) {
    if (SKIP.has(n)) continue;
    const p = path.join(d, n);
    const st = statSync(p);
    if (st.isDirectory()) {
      if (path.basename(d) === 'data' && n !== 'x') continue;
      walk(p);
    } else {
      const buf = readFileSync(p);
      inv.push({ path: path.relative(root, p), bytes: buf.length, lines: buf.toString('utf8').split('\n').length, sha256: crypto.createHash('sha256').update(buf).digest('hex') });
    }
  }
};
walk(root);
const m = existsSync(file) ? JSON.parse(readFileSync(file, 'utf8')) : {};
const same = JSON.stringify(m.files) === JSON.stringify(inv);
if (process.argv.includes('--check')) {
  console.log(same ? 'manifest inventory is current' : 'manifest inventory is STALE — run: npm run manifest');
  process.exit(same ? 0 : 1);
}
m.generatedAt = new Date().toISOString();
m.files = inv;
writeFileSync(file, JSON.stringify(m, null, 2) + '\n');
console.log(`manifest refreshed: ${inv.length} files`);
