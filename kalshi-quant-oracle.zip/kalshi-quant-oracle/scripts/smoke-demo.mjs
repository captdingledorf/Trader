#!/usr/bin/env node
/**
 * @file scripts/smoke-demo.mjs
 * Docs: README.md §"Verify against Kalshi DEMO" · docs/DEPLOYMENT_ORACLE.md Step 8 · docs/AUDIT.md F-01
 *
 * WHY THIS EXISTS: the code was built in a sandbox with NO outbound network, so nothing here has talked
 * to Kalshi yet. This script is the one-command proof, run on YOUR machine/VM against the DEMO exchange:
 *   1. public  : GET /exchange/status, GET /events  → are the price/count fields parsed? (field-shape check)
 *   2. signed  : GET /portfolio/balance             → does request signing work for your key type?
 *   3. orders  : (--place-test-order) POST a 1-contract IOC buy at 1¢ on a liquid market — it should NOT
 *                fill — trying KALSHI_ORDER_FIELD_STYLE fixed → both → legacy and printing which one the
 *                exchange accepts, so you can set it in your env file.
 * It REFUSES to run against anything that is not a demo host.
 *
 *   node scripts/smoke-demo.mjs [--place-test-order]
 */
import { loadDotEnv } from '../src/config.js';
import { KalshiClient, scanEvents } from '../src/kalshi/client.js';
import { readPrivateKeyPem } from '../src/kalshi/auth.js';
import { KalshiBroker } from '../src/engine/broker.js';
import crypto from 'node:crypto';

loadDotEnv(process.env.ENV_FILE ?? '.env');
const baseUrl = (process.env.KALSHI_BASE_URL ?? 'https://demo-api.kalshi.co/trade-api/v2').replace(/\/+$/, '');
const host = new URL(baseUrl).hostname;
if (!/demo/.test(host) && !['127.0.0.1', 'localhost', '[::1]'].includes(host)) {
  console.error(`REFUSING: ${baseUrl} is not a demo host. The smoke test only runs against Kalshi DEMO.`);
  process.exit(2);
}
const keyId = process.env.KALSHI_API_KEY_ID ?? process.env.KALSHI_API_KEY ?? '';
const pem = readPrivateKeyPem();
const client = new KalshiClient({ baseUrl, keyId, privateKeyPem: pem || null });
const results = [];
const step = async (name, fn) => {
  try {
    const detail = await fn();
    results.push([name, 'PASS', detail ?? '']);
  } catch (e) {
    results.push([name, 'FAIL', e.message]);
  }
};

await step('public: exchange status', async () => JSON.stringify(await client.getExchangeStatus()));

let sample = null;
await step('public: events + market field parsing', async () => {
  const { markets } = await scanEvents(client, { maxPages: 1 });
  if (!markets.length) throw new Error('no open markets returned');
  const priced = markets.filter((m) => m.yesBid !== null && m.yesAsk !== null);
  if (!priced.length) throw new Error('markets returned but NO bid/ask parsed — Kalshi field names may have changed; open an issue with a raw /markets sample');
  sample = priced.find((m) => m.status === 'active' && m.yesAsk >= 0.05) ?? priced[0];
  return `${markets.length} markets, ${priced.length} with quotes; sample ${sample.ticker} bid ${sample.yesBid} ask ${sample.yesAsk}`;
});

if (client.canSign) {
  await step(`signed: balance (${client.signer.keyType} key)`, async () => `cash $${(await client.getBalance()).cash.toFixed(2)}`);
  await step('signed: positions', async () => `${(await client.getPositions()).length} open position(s)`);
} else results.push(['signed calls', 'SKIP', 'set KALSHI_API_KEY_ID and a private key (DEMO key from demo.kalshi.co)']);

if (process.argv.includes('--place-test-order')) {
  if (!client.canSign || !sample) results.push(['order payload styles', 'SKIP', 'needs credentials and a sample market']);
  else {
    let accepted = null;
    for (const style of ['fixed', 'both', 'legacy']) {
      const broker = new KalshiBroker({ client, fieldStyle: style });
      const body = broker.buildBody({ ticker: sample.ticker, side: 'yes', action: 'buy', count: 1, limitPrice: 0.01, clientOrderId: crypto.randomUUID() });
      try {
        const res = await client.createOrder(body);
        const o = res.order ?? res;
        accepted = style;
        if (o.status === 'resting' && o.order_id) await client.cancelOrder(o.order_id).catch(() => {});
        results.push([`order payload "${style}"`, 'PASS', `accepted, status=${o.status}`]);
        break;
      } catch (e) {
        results.push([`order payload "${style}"`, 'FAIL', e.message]);
      }
    }
    results.push(['recommended setting', accepted ? 'PASS' : 'FAIL', accepted ? `KALSHI_ORDER_FIELD_STYLE=${accepted}` : 'no payload style accepted — do NOT go live; check docs.kalshi.com create-order']);
  }
}

for (const [n, s, d] of results) console.log(`${s === 'PASS' ? '✅' : s === 'SKIP' ? '⏭ ' : '❌'} ${n}${d ? ` — ${d}` : ''}`);
process.exit(results.some((r) => r[1] === 'FAIL') ? 1 : 0);
