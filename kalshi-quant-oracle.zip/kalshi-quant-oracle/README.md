# kalshi-quant-telebot-node

A **Node.js 24, zero-dependency** re-implementation of the system described by
[yllvar/Kalshi-Quant-TeleBot](https://github.com/yllvar/Kalshi-Quant-TeleBot) — a Kalshi
prediction-market trading bot with a Telegram control plane — sized to run on **Oracle Cloud
Always Free** (1 GB RAM micro VM or Ampere A1).

> ### Read this first — status in one paragraph
> **Verified here (sandbox, no internet):** **92 automated tests** pass — including end-to-end runs of the *whole process* against a
> strict mock Kalshi server that **verifies request signatures** (RSA-PSS *and* Ed25519), a mock Telegram, and a mock Ollama; hostile-input,
> prompt-injection and failure-containment tests; and **20 deliberately broken “mutants” of safety-critical code that the tests all caught**.
> A second audit pass found and fixed 20+ further defects (see [docs/AUDIT.md](docs/AUDIT.md) §4). **NOT verified:** any call to the real
> Kalshi, Telegram, Ollama/Qwen or Oracle, and **the dashboard has never been opened in a real browser** (it is exercised through a DOM
> shim and the real API). So your first steps are `npm run smoke:demo` (deployment Step 8) and a look at the dashboard.
> **Not a money machine:** no strategy here has demonstrated profitability. The bot defaults to **paper mode**, trading **OFF** after every
> restart, real-money mode is hard-gated, and the optional Qwen model runs in **shadow mode** (assess + log, never trade) until you have evidence.

---

## Table of contents
1. [Quick start (local, paper mode)](#quick-start-local-paper-mode)
2. [What changed vs the original](#what-changed-vs-the-original)
3. [Architecture](#architecture)
4. [Configuration](#configuration)
5. [Usage](#usage)
6. [Dashboard (graphical UI)](#dashboard-graphical-ui)
7. [Telegram Bot Interface](#telegram-bot-interface)
8. [API Documentation](#api-documentation)
9. [Trading Strategies](#trading-strategies)
10. [Qwen news intelligence](#qwen-news-intelligence)
11. [Risk Management](#risk-management)
12. [Data Ingestion](#data-ingestion)
13. [State & persistence](#state--persistence)
14. [Kalshi API compatibility](#kalshi-api-compatibility)
15. [Obtaining API Keys](#obtaining-api-keys)
16. [Verify against Kalshi DEMO](#verify-against-kalshi-demo)
17. [Monitoring and Logging](#monitoring-and-logging)
18. [Deployment](#deployment)
19. [Development](#development)
20. [Project manifest](#project-manifest)
21. [Code ↔ docs traceability](#code--docs-traceability)
22. [Troubleshooting](#troubleshooting)
23. [Disclaimer & licence](#disclaimer--licence)

---

## Quick start (local, paper mode)

Requires Node ≥ 24 (the code also runs on Node 22, which is what it was tested on here). No `npm install` —
there are no dependencies.

```bash
cp .env.example .env          # defaults: TRADING_MODE=paper, KALSHI_ENV=demo
npm run check-config          # validates config, prints the safety banner, exits
npm test                      # 92 tests, no network needed
npm start                     # paper mode; public Kalshi market data needs no key
# dashboard: set API_TOKEN (>=24 chars) in .env, restart, open http://127.0.0.1:3001 and paste the token
# no bot yet? preview the UI with synthetic data:  open http://127.0.0.1:3001/?demo
```

With no `TELEGRAM_BOT_TOKEN` and no `API_TOKEN` the bot still runs, but you have no way to start trading
(it boots with trading **OFF**). Set `AUTOSTART_TRADING=true` for an unattended paper run, or configure
Telegram ([Step 6–7](docs/DEPLOYMENT_ORACLE.md)).

## What changed vs the original

The full mapping is in [docs/PORT_MAP.md](docs/PORT_MAP.md). The decisions that matter:

| Original | This port | Why |
|---|---|---|
| Python engine + 2 Node processes (supervisor, WebSocket, Telegram) | **One Node 24 process** | 1 GB RAM; fewer failure modes than inter-process glue |
| pandas / numpy / scikit-learn / transformers | ~150 lines of audited maths (`src/util/stats.js`) | no 400 MB ML stack; no supply-chain exposure for a money-handling bot |
| `Authorization: Bearer <KALSHI_API_KEY>` | **Signed requests** (RSA-PSS or Ed25519) | that is how Kalshi's API actually authenticates (see [Kalshi API compatibility](#kalshi-api-compatibility)) |
| "IP-based authentication" for local API | **Bearer token + loopback bind + SSH tunnel** | IP checks are not authentication on a cloud VM |
| Anyone with the bot link could issue commands (no allowlist described) | **Numeric-user-ID allowlist**, private chats only, replay guard, confirmation buttons | a trading bot is a remote control for your money |
| Railway/Heroku (`Procfile`, `railway.toml`) | **systemd unit + installer for Oracle** (Docker optional) | the target platform |
| Telegram + REST/WS only | **Graphical dashboard** (single self-contained page, strict CSP, SVG charts) | see what the bot is doing without reading logs |
| Transformer NLP for news (impossible in 1 GB) | lexicon by default; **optional local Qwen model** (shadow-first, schema-constrained, injection-hardened) | capability where the hardware allows it, evidence before trust |
| Live by default after configuration | **Paper by default; TRADING OFF after every start; real money needs an explicit env acknowledgement** | fail safe |

> **Important provenance note.** GitHub would only serve the repository's landing page (README + file list)
> to the build tooling; the files under `src/` and `telegram_ui/` could **not** be read. This port is therefore
> a faithful implementation of the *documented* behaviour, not a line-by-line translation, and it does **not**
> reproduce claims the README makes that cannot run on a 1 GB VM (transformer NLP, "sub-second" latency). See
> [NOTICE](NOTICE) and [AUDIT F-03](docs/AUDIT.md).

## Architecture

```
                         ┌────────────────────────── one Node 24 process ──────────────────────────┐
  Kalshi REST ◀─signed──▶│ KalshiClient ─▶ MarketScanner ─▶ Strategies ─▶ Trader ─▶ Broker          │
  (demo / prod)          │  (retry, rate   (events+quotes,   arbitrage     │  cycle    paper | kalshi │
                         │   limit, sign)   price history)   volatility    │  exits         │        │
                         │                                   sentiment     ▼                ▼        │
  Telegram Bot API ◀────▶│ TelegramBot (allowlist) ◀── events ── Ledger (cash, positions, P&L)      │
  you, on your phone     │ REST+WS API (bearer, loopback) ◀──────────┘   state.<mode>.json, trades.jsonl
                         └──────────────────────────────────────────────────────────────────────────┘
```

Core trading engine ([`src/engine/trader.js`](src/engine/trader.js)) cycle, in order:
**exchange status → (live) sync cash → scan → settle → mark-to-market → halt check → exits → entries → persist**.
Design rationale and rejected alternatives: [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md).

## Configuration

All settings are environment variables; [`.env.example`](.env.example) documents every one. Two classes:

* **Static / secret** (restart required): mode, Kalshi env + credentials, Telegram token + allowlist, API token,
  paths. On Oracle these live in `/etc/kalshi-bot/kalshi-bot.env` (`root:root 600`).
* **Runtime-tunable** (Telegram `/set`, `POST /api/config`; persisted to `bot_settings.json`, which wins over env
  after a restart): `bankroll`, `tradeInterval`, `maxPositionSize`, `stopLoss`, `newsSentimentThreshold`,
  `statArbitrageThreshold`, `volatilityThreshold`, `maxDailyLoss`, `maxOpenPositions`, `correlationLimit`,
  `kellyScale`, `maxOrderContracts`, `maxDrawdown`, `minEdge`. Every value is range-validated.

**Safety gates** (implemented in [`src/config.js`](src/config.js), unit-tested):

| `TRADING_MODE` | `KALSHI_ENV` | Effect |
|---|---|---|
| `paper` (default) | any | simulated fills; **never** sends an order |
| `live` | `demo` | orders go to Kalshi's demo exchange (play money) |
| `live` | `prod` | **real money** — startup aborts unless `I_UNDERSTAND_LIVE_TRADING_RISK=yes`; REST cannot start it (Telegram confirmation button only) |

**Strict parsing:** an explicitly set but invalid value (e.g. `AUTOSTART_TRADING=ture`, `SCAN_MAX_PAGES=three`, `STOP_LOSS_PERCENTAGE=5`) aborts startup with the variable named — it never silently becomes a default. `AUTOSTART_TRADING=true` is refused with real money.

Also refused at startup: non-Kalshi hosts in `KALSHI_BASE_URL` (loopback is allowed for local mocks), `API_TOKEN` < 24 chars, non-loopback `API_HOST`
without a token, `live` without credentials.

## Usage

```bash
node src/index.js            # run
node src/index.js --check    # validate configuration and exit (used in deployment Step 8)
```

After **every** start trading is OFF. Turn it on from Telegram (`/start_trading`), `POST /api/start-trading`
(paper/demo only), or set `AUTOSTART_TRADING=true`. The recommended progression is in
[Step 13 of the deployment guide](docs/DEPLOYMENT_ORACLE.md#step-13--going-live-checklist): weeks of paper →
demo exchange → tiny real size.

## Dashboard (graphical UI)

`http://127.0.0.1:3001/` — one self-contained page (`src/ui/index.html`, ≈ 24 KB, no external requests, no dependencies) served by the bot itself
when `API_TOKEN` is set. The page is public; **every data call needs the bearer token**, which you type into the page and which lives only in the
tab’s `sessionStorage`. Reach it through the SSH tunnel (`ssh -L 3001:127.0.0.1:3001 …`, deployment Step 11); no inbound port is opened.

| Widget | Shows |
|---|---|
| Header | mode badge (PAPER / LIVE·DEMO / **LIVE·REAL MONEY**), trading ON/OFF, pulsing API-connected dot, Start/Stop |
| KPI cards | equity + sparkline, today’s P&L, win rate/Sharpe, positions vs limit |
| **Equity curve** | area chart, dashed running peak, shaded drawdown, hover/touch crosshair with tooltip |
| **Risk gauges** | daily-loss used, drawdown vs limit, position slots — green → amber → red |
| Positions | side badges, qty, entry/now, P&L with diverging bar |
| **Closed-trade P&L** | win/loss bars + cumulative line |
| **Arbitrage radar** | Σ YES bids per mutually exclusive event; right of the 1.00 line = overround (green when above your threshold) |
| **Market heat map** | top-volume markets as tiles coloured by probability (blue → red) |
| Signals | what the strategies proposed and what happened (executed / alert / skipped) |
| **News intelligence** | headline, Qwen stance bar (opacity = confidence), lexicon tick, novelty/language; shadow / trading / model-down pill |
| Live log | recent log lines, warnings/errors coloured |

Real-money trading **cannot** be started from the page (the API refuses; use Telegram’s confirmation button). Add `?demo` (or open the page where no
API exists) for a clearly-labelled **demo-data preview**. Hardening: strict CSP by hash (no `unsafe-inline`, same-origin fetches only), all dynamic text via
`textContent`, charts built from numbers only — tests feed hostile strings through every widget. Light/dark theme follows the OS (toggle ◐), respects reduced motion.

## Telegram Bot Interface

Create a bot with @BotFather, put the token in `TELEGRAM_BOT_TOKEN`, then find your numeric user ID
(deployment Step 7) and put it in `TELEGRAM_CHAT_ID`. **Only listed IDs are served, only in private chats**;
everyone else is silently ignored and logged. With the allowlist empty the bot is in *setup mode*: it answers
only `/id` and executes nothing.

### Command Reference

| Command | What it does |
|---|---|
| `/start` | main menu (inline buttons) |
| `/status` | trading flag, halt state, API connectivity, strategies, positions, uptime, last cycle |
| `/balance` | available cash, equity, unrealised and today's P&L |
| `/positions` | open positions with entry/current price and P&L |
| `/performance` | return, Sharpe (needs ≥ 5 days), max drawdown, win rate, best/worst trade |
| `/start_trading` | begin trading (paper/demo immediately; **real money asks for a confirmation button, 60 s, single-use**) |
| `/stop_trading` | stop all trading activity (positions untouched) |
| `/resume` | clear a risk halt (daily-loss / drawdown) |
| `/close_all` | close every open position at market (confirmation button) |
| `/settings` | list settings with allowed ranges |
| `/set <key> <value>` | change a runtime setting (validated) |
| `/strategy <arbitrage\|volatility\|sentiment> on\|off` | toggle a strategy |
| `/help` | command list |

Notifications pushed to you: entries, exits, settlements, baskets, **risk events** (halts, partial baskets,
exchange/ledger position mismatches), unexecuted arbitrage opportunities, and de-duplicated errors.

## API Documentation

Started only if `API_TOKEN` is set. Binds `127.0.0.1:3001` by default. **No inbound firewall port is opened on
Oracle** — use an SSH tunnel (`ssh -L 3001:127.0.0.1:3001 …`, deployment Step 11).

All endpoints except `/api/health` need `Authorization: Bearer <API_TOKEN>`. Bodies are JSON, max 16 KB.
Rate limit: 120 requests/min per IP.

| Method | Path | Response (same shape as the original project) |
|---|---|---|
| GET | `/api/health` | `{status, timestamp, engine}` (no auth) |
| GET | `/api/status` | `{trading, halted, haltReason, mode, kalshiEnv, lastUpdate, uptime, apiConnected, activeStrategies, tradesCount, openPositions, cycle, reconcile, risk, version}` |
| GET | `/api/positions` | `[{eventName, eventId, ticker, side, quantity, entryPrice, currentPrice, pnl, timestamp}]` |
| GET | `/api/balance` | `{available, totalEquity, unrealizedPnL, todayPnL, mode, timestamp}` |
| GET | `/api/performance` | `{totalReturn, sharpeRatio, maxDrawdown, winRate, totalTrades, avgTrade, bestTrade, worstTrade, timestamp}` |
| POST | `/api/start-trading` · `/api/stop-trading` | `{success, message}` (start is refused for real money) |
| GET/POST | `/api/config` | camelCase settings above (POST validates and persists; non-object bodies → 400) |
| GET | `/api/equity` · `/api/trades` · `/api/markets` · `/api/signals` · `/api/sentiment` · `/api/logs` | dashboard feeds (equity curve, last 100 closed trades, scanner snapshot + exclusive-event overrounds, recent signals with outcomes, Qwen/lexicon assessments, last 150 log lines) |
| GET | `/` · `/ui` | the dashboard page (public; data calls need the token) |

### WebSocket API
`ws://127.0.0.1:3001/ws?token=<API_TOKEN>` (browsers cannot set headers on WebSockets, so the token may be a query
parameter; keep this on the SSH tunnel). Send `{"type":"subscribe"}`; receive
`{type, data, timestamp}` with `type` ∈ `status | trade_executed | bot_error | risk_event | config_updated | bot_output`.
Limits: 10 clients, single-frame text messages ≤ 64 KiB, client frames must be masked.

## Trading Strategies

All three emit *signals*; the trader applies sizing, caps and fees. **None has demonstrated profitability** —
see [AUDIT F-10](docs/AUDIT.md) and [docs/THESIS.md](docs/THESIS.md) §6.

### Statistical Arbitrage Strategy (`arbitrage`, **on by default**)
1. **Exclusive-event NO-basket** — if an event is flagged `mutually_exclusive`, at most one market resolves YES, so
   NO in *k* of its markets pays ≥ (k−1) dollars per set. When `Σ NO-ask < (k−1) − fees − threshold` the profit is
   locked in (*execution risk remains*). Needs exclusivity only, not exhaustiveness.
2. **Declared implications** (`relations.json`) — "A ⇒ B" means P(A) ≤ P(B); buy NO(A)+YES(B) when bid(A) > ask(B) + fees.
3. **Cointegrated pairs** (`relations.json`, opt-in, *not riskless*) — Engle-Granger on mid-price history.

Live mode **announces** baskets instead of trading them unless `ARBITRAGE_AUTOEXEC=true`; legs of riskless baskets
are held to settlement and exempt from stop-loss. Partial fills raise a `risk_event`.

### Volatility-Based Strategy (`volatility`, off)
GARCH(1,1) on logit returns gates a mean-reversion fade of deviations from the 20-sample EMA.

### News Sentiment Analysis Strategy (`sentiment`, off)
RSS/Atom headlines → relevance to the market title → tone (lexicon) **or** stance (optional local Qwen) → at most ±10 points of probability shift.
Replaces the original’s transformer NLP, which cannot run in 1 GB. Feeds are parsed by a linear-time parser with byte/item/field caps (a hostile 1 MB
feed used to freeze the loop for 76 s; now milliseconds — regression-tested).

## Qwen news intelligence

Optional, **off by default**, needs the A1 shape (not the 1 GB micro). A local Qwen model (via Ollama or any OpenAI-compatible server) returns, per
(market, headline) pair, schema-constrained JSON: relevance, **stance toward YES**, tone, confidence, novelty, language, entities. Three modes: lexicon only ·
**shadow** (default: assess + log beside the lexicon and the market price, never trade) · trade. Controls against prompt injection, a hung model and a wrong
model are described in [docs/QWEN.md](docs/QWEN.md), together with install (`deploy/qwen/`), the evaluation harness (`npm run qwen:eval`), the falsifiable
**shadow report** (`npm run qwen:shadow-report`: Brier score of market vs Qwen-adjusted vs lexicon-adjusted with a cluster bootstrap) and the optional
fine-tuning data pipeline (`npm run qwen:dataset`). **No model was trained and no weights are shipped**; verified against a mock only.

## Risk Management

Layers, outermost first (each independent): **L0** mode gate → **L1** daily-loss and drawdown halts (new entries
blocked until `/resume`) → **L2** max open positions, per-event concentration, return-correlation limit →
**L3** fractional-Kelly sizing net of fees, capped by `maxPositionSize` and `maxOrderContracts` →
**L4** stop-loss, trailing stop, optional time stop.

Kelly for a binary contract bought at effective cost *c* (price + fee) with fair probability *p*:
`f* = (p − c)/(1 − c)`; scaled by `kellyScale` (default ¼). Worked example (p=0.55, price 0.45 ⇒ c≈0.468):
full Kelly 15.4 % of bankroll, quarter-Kelly 3.85 % — and if the true p were only 0.50, full Kelly would be
2.56× the true optimum and have *negative* expected growth, which is why we never use it
([THESIS §3.2](docs/THESIS.md)).

## Data Ingestion

`MarketScanner` pulls open events with nested markets (`GET /events`, up to `SCAN_MAX_PAGES`×200), normalises
prices to dollars, filters (status, spread ≤ `SCAN_MAX_SPREAD`, mid 3–97 ¢, time to close), and records one mid-price
per cycle for the top-volume + held tickers into bounded ring buffers (needed by the volatility/cointegration
strategies, which therefore need a warm-up period). News: `NEWS_FEEDS` (default BBC + NPR RSS) cached 10 minutes.

## State & persistence

`DATA_DIR` (systemd: `/var/lib/kalshi-bot`, mode 700): `state.<mode>.json` (cash, positions, closed trades, equity curve),
`trades.<mode>.jsonl` (append-only fill log), `price_history.json`, `bot_settings.json`, `telegram_offset.json`.
Writes are atomic (temp file + rename); an unreadable file is moved aside, never deleted. State is **per mode**
(`paper`, `live-demo`, `live-prod`) so switching modes can never mix books. A daily backup timer is installed
(Step 12). **Secrets are never in `DATA_DIR`.**

## Kalshi API compatibility

Built against docs.kalshi.com as of **Nov 2026**:

* **Auth:** headers `KALSHI-ACCESS-KEY`, `KALSHI-ACCESS-TIMESTAMP` (ms), `KALSHI-ACCESS-SIGNATURE` =
  base64 signature of `timestamp + METHOD + path` (path without query). RSA-PSS/SHA-256 (salt = digest length) for RSA
  keys, Ed25519 for Ed25519 keys — detected automatically. Keep the clock synced (signatures embed the timestamp).
* **Units:** Kalshi’s current “Fixed-Point Representation” page (read Nov 2026) documents `*_dollars` strings (up to 4 dp) and `*_fp` counts (0–2 dp on input;
  where both integer and `_fp` fields are sent they must match); earlier notices scheduled the legacy integer cents/counts for removal in early 2026. Every reader
  prefers the new fields and falls back to the legacy ones ([`src/util/money.js`](src/util/money.js)); order payload style is switchable (`KALSHI_ORDER_FIELD_STYLE`).
  Fills can be fractional on fractional-enabled markets — the ledger handles fractional quantities.
* **Price grid:** each market has its own tick structure (`price_ranges`); **whole-cent prices are valid on every grid** (per the same page), so orders snap to whole cents and are
  clamped to [0.01, 0.99].
* **Hosts:** prod `https://api.elections.kalshi.com/trade-api/v2`, demo `https://demo-api.kalshi.co/trade-api/v2`
  (both documented as supported; override with `KALSHI_BASE_URL`).
* **Orders:** IOC (`immediate_or_cancel`) limit orders with an idempotency `client_order_id`; POST is never auto-retried;
  a 409 is reconciled by looking the order up.
* **Fees:** `ceil_cent(0.07·C·P·(1−P))` assumed for takers (`FEE_COEFFICIENT`) — **verify against Kalshi's current fee schedule**.
* **Rate limits:** conservative defaults (8 reads/s, 4 writes/s) below every tier; token-bucket + `Retry-After`.

## Obtaining API Keys

Kalshi → account/profile settings → **API Keys** → create a key; you receive a **Key ID** and a **private key (PEM)
shown once**. Use a **demo** account/key (demo.kalshi.co — a separate sign-up) first. Guide:
<https://docs.kalshi.com/getting_started/api_keys>. Put the Key ID in `KALSHI_API_KEY_ID`; on Oracle place the PEM at
`/etc/kalshi-bot/kalshi_private_key.pem` (systemd hands it to the service as a credential; it never enters the
environment). Never commit it.

## Verify against Kalshi DEMO

```bash
npm run smoke:demo                      # public: exchange status + market-field parsing; signed: balance/positions
npm run smoke:demo -- --place-test-order   # also tries 1-contract IOC @ 1¢ and prints the KALSHI_ORDER_FIELD_STYLE to use
```
Refuses to run against a non-demo host. Do not trade real money until this passes on your instance.

## Monitoring and Logging

stdout → journald (`journalctl -u kalshi-bot -f`); secrets (PEM blocks, bot tokens, bearer tokens, signature headers)
are redacted from every line. `LOG_JSON=true` for structured logs. `/status` shows API connectivity, last-cycle
duration/errors and the exchange-vs-ledger reconciliation result. Deployment Step 10 covers journald limits and OCI
alarms.

## Deployment

**→ [docs/DEPLOYMENT_ORACLE.md](docs/DEPLOYMENT_ORACLE.md)** — account, VM, installer, secrets, Telegram, demo
verification, systemd, SSH-tunnelled API, backups, go-live checklist, Docker appendix, troubleshooting. Short form
(after you own a VM and have uploaded the ZIP):

```bash
sudo bash deploy/oracle/bootstrap.sh     # Node 24 (checksum-verified), user, dirs, systemd — starts nothing
sudo nano /etc/kalshi-bot/kalshi-bot.env # secrets + mode
sudo systemctl start kalshi-bot && sudo journalctl -u kalshi-bot -f
```

## Development

```bash
npm test               # node --test "test/*.test.js"  (92 tests, no network; ~35 s incl. whole-process e2e)
npm run lint:syntax    # node --check on every file (no eslint — no dependencies)
npm run manifest       # refresh PROJECT_MANIFEST.json file inventory (hashes)
npm run qwen:eval      # Qwen vs lexicon on a labelled JSONL (needs a running model)
npm run qwen:shadow-report   # did Qwen beat the market price? (needs weeks of shadow logs)
```
Conventions: ES modules, JSDoc, no dependencies, every module header cites the README section and deployment step it
belongs to and records the reasoning/alternatives behind it. Money is plain numbers in **dollars**; strings only at the
request edge.

## Project manifest

[`PROJECT_MANIFEST.json`](PROJECT_MANIFEST.json) is the project's persistent memory and scope across work sessions:
scope (in/out), decisions with rationale, assumptions, constraints, a verified-vs-unverified ledger, open items, change
log and a hashed file inventory. Hand-edit the narrative sections as scope changes; `npm run manifest` refreshes the
inventory and `node scripts/build-manifest.mjs --check` tells you if it is stale. Hand it back to your assistant at the
start of the next session.

## Code ↔ docs traceability

| Code | README § | Deployment step | Audit |
|---|---|---|---|
| `src/config.js`, `.env.example` | Configuration | 6 | F-05 |
| `src/kalshi/auth.js` | Obtaining API Keys, Kalshi API compatibility | 6 | F-01, F-18 |
| `src/kalshi/client.js`, `src/util/money.js` | Kalshi API compatibility | 8 | F-01, F-07, F-08, F-09 |
| `src/engine/broker.js` | Usage | 8 | F-02, F-08, F-12 |
| `src/engine/ledger.js`, `src/util/atomic.js` | State & persistence | 12 | F-12 |
| `src/engine/risk.js` | Risk Management | 11, 13 | F-05 |
| `src/engine/trader.js` | Architecture, Usage | 11 | F-12 |
| `src/strategies/*`, `src/data/*`, `src/util/stats.js` | Trading Strategies, Data Ingestion | 6, 13 | F-10 |
| `src/telegram/bot.js` | Telegram Bot Interface | 7 | F-04 |
| `src/api/server.js`, `src/util/wsHub.js` | API Documentation | 11 | F-04 |
| `src/logger.js` | Monitoring and Logging | 10 | F-04 |
| `deploy/systemd/*`, `deploy/oracle/bootstrap.sh` | Deployment | 5, 9, 12 | F-06, F-14 |
| `scripts/smoke-demo.mjs` | Verify against Kalshi DEMO | 8 | F-01 |
| `src/ai/*`, `src/strategies/sentiment.js`, `scripts/qwen-*.mjs`, `deploy/qwen/*` | Qwen news intelligence | App. E | F-21, F-29 |
| `src/ui/index.html`, UI endpoints in `src/api/server.js` | Dashboard | 11 | F-22 |
| `src/util/http.js`, `src/data/news.js` | Data Ingestion | 6 | F-20 |

## Troubleshooting

| Symptom | Likely cause → fix |
|---|---|
| `CONFIG ERROR: REAL-MONEY MODE BLOCKED` | you set `live`+`prod` without `I_UNDERSTAND_LIVE_TRADING_RISK=yes` — intended |
| `HTTP 401` on signed calls | wrong key ID/PEM pair, **demo key used on prod (or vice-versa)**, or clock skew (`timedatectl`) |
| smoke test: "no bid/ask parsed" | Kalshi changed field names — send a raw `/markets` sample; adjust `normalizeMarket` |
| smoke test: all order styles rejected | Kalshi changed the order schema — do not go live; see docs.kalshi.com create-order |
| Telegram silent | your numeric ID missing from `TELEGRAM_CHAT_ID`; or a group chat (ignored); check `journalctl` for "unauthorised user" |
| `cycle failed: … network error` | outbound HTTPS blocked/DNS down; the bot retries next cycle |
| bot exits right after start | check `journalctl -u kalshi-bot` — usually a `CONFIG ERROR` (exit code 2); an invalid value is named in the message |
| dashboard asks for a token again | wrong `API_TOKEN`, or a new browser tab (the token lives only in that tab’s session storage) |
| dashboard shows “DEMO DATA” | the page could not reach `/api/health` (opened from a file / hosted preview / bot not running) |
| Qwen pill says “model down” | circuit breaker after 3 failures (self-heals in 5 min); see [docs/QWEN.md](docs/QWEN.md) §11 |

More in [docs/DEPLOYMENT_ORACLE.md](docs/DEPLOYMENT_ORACLE.md#appendix-b--troubleshooting).

## Disclaimer & licence

MIT ([LICENSE](LICENSE)); upstream attribution and a licensing caveat in [NOTICE](NOTICE). This software can place
orders on a real-money exchange. Nothing here is financial, legal or tax advice, and no strategy in it is
claimed to be profitable. Check Kalshi's terms for automated trading and the rules in your jurisdiction.
