#!/usr/bin/env bash
# deploy/qwen/install-ollama.sh — OPTIONAL: install Ollama + a Qwen model on an Always Free A1 VM (aarch64 or x86_64, ≥ 6 GB RAM).
# Docs: docs/QWEN.md §"Install on an Always Free A1 VM"
# NOT executed by the author (sandbox had no network/cloud). It refuses to run on the 1 GB micro shape.
# Provenance note: Ollama's official installer is a `curl | sh` script run as root. Read it first (https://ollama.com/install.sh) or
# install manually from https://github.com/ollama/ollama/releases — your call.
set -euo pipefail
MODEL_BASE="${QWEN_BASE_MODEL:-qwen3:1.7b}"
die() { printf '\033[1;31m[qwen] ERROR:\033[0m %s\n' "$*" >&2; exit 1; }
[[ $EUID -eq 0 ]] || die "run as root: sudo bash deploy/qwen/install-ollama.sh"
SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
mem_kb="$(awk '/^MemTotal:/ {print $2}' /proc/meminfo)"
[[ "$mem_kb" -ge 6000000 ]] || die "only $((mem_kb/1024)) MB RAM: a Qwen model needs the A1 shape (≥ 6 GB). Keep QWEN_ENABLED=false on the micro VM."
if ! command -v ollama >/dev/null 2>&1; then
  echo "[qwen] installing Ollama with the official installer (https://ollama.com/install.sh)"
  curl -fsSL https://ollama.com/install.sh | sh
fi
install -d /etc/systemd/system/ollama.service.d
install -m 644 "$SRC_DIR/deploy/qwen/ollama-override.conf" /etc/systemd/system/ollama.service.d/override.conf
systemctl daemon-reload
systemctl enable --now ollama
for i in $(seq 1 30); do curl -fsS http://127.0.0.1:11434/api/tags >/dev/null 2>&1 && break; sleep 1; done
curl -fsS http://127.0.0.1:11434/api/tags >/dev/null || die "Ollama did not come up on 127.0.0.1:11434 (journalctl -u ollama)"
echo "[qwen] pulling $MODEL_BASE (≈1.4 GB for qwen3:1.7b)"
ollama pull "$MODEL_BASE"
sed "s|^FROM .*|FROM ${MODEL_BASE}|" "$SRC_DIR/deploy/qwen/Modelfile" > /tmp/Modelfile.kalshi-news
ollama create kalshi-news -f /tmp/Modelfile.kalshi-news && rm -f /tmp/Modelfile.kalshi-news
printf '\n\033[1;32m✔ done.\033[0m Add to /etc/kalshi-bot/kalshi-bot.env:\n  QWEN_ENABLED=true\n  QWEN_MODEL=kalshi-news\n  (shadow mode is the default — leave QWEN_TRADE unset until docs/QWEN.md §"Evaluate before you trust" says otherwise)\nthen: sudo systemctl restart kalshi-bot\n'
