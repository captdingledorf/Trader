#!/usr/bin/env bash
# ═══════════════════════════════════════════════════════════════════════════
# deploy/oracle/bootstrap.sh — idempotent installer for an Oracle Cloud Always Free VM
# Docs: docs/DEPLOYMENT_ORACLE.md Step 5 (run this) · README.md §Deployment
#
# Supports: Ubuntu 22.04/24.04 and Oracle Linux 8/9 · x86_64 (E2.1.Micro) and aarch64 (A1.Flex)
# Run from the UNZIPPED project directory on the VM:   sudo bash deploy/oracle/bootstrap.sh
#
# WHAT IT DOES (in order — each step is safe to re-run)
#   1. prerequisites           curl, xz, ca-certificates
#   2. swap (RAM < 2 GB)       1 GiB swap file so a memory spike cannot freeze the 1 GB micro VM
#   3. Node.js 24              OFFICIAL tarball from nodejs.org, SHA-256 verified (no third-party repo)
#   4. service user            `kalshi` — no shell, no home
#   5. application             /opt/kalshi-bot  (root-owned, read-only to the service)
#   6. secrets scaffolding     /etc/kalshi-bot/{kalshi-bot.env,kalshi_private_key.pem}  (root:root 600)
#   7. systemd units           kalshi-bot.service (+ daily backup timer); enabled but NOT started
# It never overwrites an existing env file or key, never opens a firewall port, never starts trading.
# NOT executed on real OCI hardware by the author (sandbox had no cloud access) — see docs/AUDIT.md F-01.
# ═══════════════════════════════════════════════════════════════════════════
set -euo pipefail

NODE_MAJOR="${NODE_MAJOR:-24}"
APP_DIR=/opt/kalshi-bot
ETC_DIR=/etc/kalshi-bot
STATE_DIR=/var/lib/kalshi-bot
SVC_USER=kalshi
SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"

log() { printf '\033[1;34m[bootstrap]\033[0m %s\n' "$*"; }
die() { printf '\033[1;31m[bootstrap] ERROR:\033[0m %s\n' "$*" >&2; exit 1; }

[[ $EUID -eq 0 ]] || die "run as root:  sudo bash deploy/oracle/bootstrap.sh"
[[ -f "$SRC_DIR/package.json" && -d "$SRC_DIR/src" ]] || die "package.json/src not found in $SRC_DIR — run from the unzipped project"

# shellcheck disable=SC1091
. /etc/os-release
case "${ID:-}" in
  ubuntu|debian)                     FAMILY=deb ;;
  ol|rhel|centos|rocky|almalinux)    FAMILY=rpm ;;
  *) die "unsupported OS '${ID:-unknown}' — use Ubuntu 22.04/24.04 or Oracle Linux 8/9" ;;
esac

# ── 1. prerequisites ───────────────────────────────────────────────────────
log "installing prerequisites ($FAMILY)"
if [[ $FAMILY == deb ]]; then
  export DEBIAN_FRONTEND=noninteractive
  apt-get update -y
  apt-get install -y --no-install-recommends ca-certificates curl xz-utils tar coreutils
else
  # Oracle Linux 9 images ship curl-minimal, which conflicts with the full curl package — only install what is missing.
  command -v curl >/dev/null 2>&1 || dnf install -y curl
  command -v xz   >/dev/null 2>&1 || dnf install -y xz
  command -v tar  >/dev/null 2>&1 || dnf install -y tar
  dnf install -y ca-certificates || true
fi

# ── 2. swap on small machines ──────────────────────────────────────────────
mem_kb="$(awk '/^MemTotal:/ {print $2}' /proc/meminfo)"
if [[ "${SKIP_SWAP:-0}" != 1 && "$mem_kb" -lt 2000000 && -z "$(swapon --show --noheadings 2>/dev/null)" ]]; then
  log "RAM < 2 GB and no swap: creating a 1 GiB swap file"
  dd if=/dev/zero of=/swapfile bs=1M count=1024 status=none
  chmod 600 /swapfile
  mkswap /swapfile >/dev/null
  swapon /swapfile
  grep -q '^/swapfile ' /etc/fstab || echo '/swapfile none swap sw 0 0' >> /etc/fstab
fi

# ── 3. Node.js (official tarball, checksum-verified) ───────────────────────
node_ok() { command -v node >/dev/null 2>&1 && [[ "$(node -p 'process.versions.node.split(".")[0]')" -ge "$NODE_MAJOR" ]]; }
if node_ok; then
  log "Node $(node -v) already satisfies >= $NODE_MAJOR"
else
  case "$(uname -m)" in
    x86_64)        NODE_ARCH=x64 ;;
    aarch64|arm64) NODE_ARCH=arm64 ;;
    *) die "unsupported CPU architecture $(uname -m)" ;;
  esac
  base="https://nodejs.org/dist/latest-v${NODE_MAJOR}.x"
  tmp="$(mktemp -d)"; trap 'rm -rf "$tmp"' EXIT
  log "resolving Node ${NODE_MAJOR}.x for ${NODE_ARCH} from nodejs.org"
  curl -fsSL "$base/SHASUMS256.txt" -o "$tmp/SHASUMS256.txt"
  file="$(awk -v re="node-v${NODE_MAJOR}\\\\.[0-9]+\\\\.[0-9]+-linux-${NODE_ARCH}\\\\.tar\\\\.xz\$" '$2 ~ re {print $2; exit}' "$tmp/SHASUMS256.txt")"
  [[ -n "$file" ]] || die "no Node ${NODE_MAJOR} linux-${NODE_ARCH} tarball listed in SHASUMS256.txt"
  curl -fsSL "$base/$file" -o "$tmp/$file"
  (cd "$tmp" && grep " ${file}\$" SHASUMS256.txt | sha256sum -c -) || die "SHA-256 mismatch for $file — aborting"
  mkdir -p /opt/node
  tar -xJf "$tmp/$file" -C /opt/node
  ln -sfn "/opt/node/${file%.tar.xz}/bin/node" /usr/local/bin/node
  ln -sfn "/opt/node/${file%.tar.xz}/bin/npm"  /usr/local/bin/npm
  # SELinux (Oracle Linux): make the binary executable by services started from systemd
  if command -v getenforce >/dev/null 2>&1 && [[ "$(getenforce)" == "Enforcing" ]]; then
    log "SELinux enforcing: labelling /opt/node as bin_t"
    if command -v semanage >/dev/null 2>&1; then
      semanage fcontext -a -t bin_t '/opt/node(/.*)?' 2>/dev/null || true
      restorecon -R /opt/node
    else
      chcon -R -t bin_t /opt/node
    fi
  fi
  log "installed Node $(/usr/local/bin/node -v)"
fi
node_ok || die "Node >= $NODE_MAJOR is not available after install"
NODE_BIN="$(command -v node)"

# ── 4. service user ────────────────────────────────────────────────────────
getent group "$SVC_USER" >/dev/null || groupadd --system "$SVC_USER"
if ! id -u "$SVC_USER" >/dev/null 2>&1; then
  useradd --system --gid "$SVC_USER" --home-dir "$STATE_DIR" --no-create-home \
          --shell "$(command -v nologin || echo /usr/sbin/nologin)" "$SVC_USER"
fi

# ── 5. application (root-owned: the service cannot modify its own code) ────
log "installing application into $APP_DIR"
install -d -m 755 "$APP_DIR"
rm -rf "$APP_DIR/src" "$APP_DIR/scripts" "$APP_DIR/docs"
cp -a "$SRC_DIR/src" "$APP_DIR/src"
cp -a "$SRC_DIR/scripts" "$APP_DIR/scripts"
[[ -d "$SRC_DIR/docs" ]] && cp -a "$SRC_DIR/docs" "$APP_DIR/docs"
for f in package.json README.md LICENSE NOTICE PROJECT_MANIFEST.json .env.example; do
  [[ -f "$SRC_DIR/$f" ]] && cp -a "$SRC_DIR/$f" "$APP_DIR/$f"
done
chown -R root:root "$APP_DIR"; chmod -R go-w "$APP_DIR"; chmod 755 "$APP_DIR"/scripts/*.sh

# ── 6. secrets scaffolding (never overwrites) ──────────────────────────────
install -d -m 750 -o root -g root "$ETC_DIR"
if [[ ! -f "$ETC_DIR/kalshi-bot.env" ]]; then
  install -m 600 -o root -g root "$SRC_DIR/.env.example" "$ETC_DIR/kalshi-bot.env"
  log "created $ETC_DIR/kalshi-bot.env (edit it — Step 6)"
fi
if [[ ! -f "$ETC_DIR/kalshi_private_key.pem" ]]; then
  : > "$ETC_DIR/kalshi_private_key.pem"; chmod 600 "$ETC_DIR/kalshi_private_key.pem"; chown root:root "$ETC_DIR/kalshi_private_key.pem"   # empty placeholder = paper mode
  log "created empty $ETC_DIR/kalshi_private_key.pem (paste your key there for demo/live — Step 6)"
fi
install -d -m 700 -o "$SVC_USER" -g "$SVC_USER" "$STATE_DIR"
[[ -f "$SRC_DIR/data/relations.example.json" ]] && install -m 600 -o "$SVC_USER" -g "$SVC_USER" "$SRC_DIR/data/relations.example.json" "$STATE_DIR/relations.example.json"

# ── 7. systemd ─────────────────────────────────────────────────────────────
sed "s|/usr/local/bin/node|${NODE_BIN}|g" "$SRC_DIR/deploy/systemd/kalshi-bot.service" > /etc/systemd/system/kalshi-bot.service
install -m 644 "$SRC_DIR/deploy/systemd/kalshi-bot-backup.service" /etc/systemd/system/kalshi-bot-backup.service
install -m 644 "$SRC_DIR/deploy/systemd/kalshi-bot-backup.timer"   /etc/systemd/system/kalshi-bot-backup.timer
systemctl daemon-reload
systemctl enable kalshi-bot.service kalshi-bot-backup.timer >/dev/null
systemctl start kalshi-bot-backup.timer

printf '\n\033[1;32m✔ bootstrap complete.\033[0m  Nothing is running yet. Next (docs/DEPLOYMENT_ORACLE.md):\n'
cat <<MSG
  Step 6  edit secrets:      sudo nano $ETC_DIR/kalshi-bot.env      (and paste your key into $ETC_DIR/kalshi_private_key.pem)
  Step 8  validate config:   sudo systemd-run --quiet --wait --pipe -p User=$SVC_USER -p EnvironmentFile=$ETC_DIR/kalshi-bot.env \\
                               -p Environment=DATA_DIR=$STATE_DIR -p LoadCredential=kalshi_key:$ETC_DIR/kalshi_private_key.pem \\
                               $NODE_BIN $APP_DIR/src/index.js --check
  Step 9  start the service: sudo systemctl start kalshi-bot && sudo journalctl -u kalshi-bot -f
MSG
